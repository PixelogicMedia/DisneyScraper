import os, json, uuid, subprocess, shlex
from decimal import Decimal

def get_media_info(input, tempDir, frame_det_duration = 0, cmds_url = ''):
    output = ''
    try:
        output = os.path.join(tempDir, os.path.basename(input) + str(uuid.uuid1()) + '_ffprobe.json')
        cmd = 'ffprobe -v quiet'
        if frame_det_duration > 0:
            cmd += f' -read_intervals 0%{frame_det_duration} -show_frames'
        cmd += f' -print_format json -show_format -show_streams {shlex.quote(input)}'
        print('running ffprobe: ' + cmd)
        if cmds_url:
            from .celery_call import submit_and_check
            cmd += f' > {shlex.quote(output)}'
            cmd_res = submit_and_check(cmds_url, {'args': [['mkdir', '-p', tempDir], [cmd], ['cat', output]]})
            if cmd_res.get('state') != 'SUCCESS':
                raise Exception('cannot grab media info remotely', cmd_res.get('result'), cmd_res.get('exception'))
            return json.loads(cmd_res['result'][2].split(f'cat {output}')[-1])
        else:
            os.makedirs(tempDir, exist_ok=True)
            return subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
    except Exception as e:
        return {'success': False, 'result_message': 'failed to probe source: ' + str(e)}

def get_media_info_qm(input, frame_det_duration = 0):
    cmd = ['ffprobe', '-v', 'quiet']
    if frame_det_duration > 0:
        cmd += ['-read_intervals', f"0%{frame_det_duration}", '-show_frames']
    cmd += ['-print_format', 'json', '-show_format', '-show_streams', input]
    print(f'running ffprobe: {cmd}')
    from .qm import QueueManager
    output = QueueManager().mediatools_cmd(cmd, is_sync=True)
    try: return json.loads(output)
    except: return output
    
def get_audio_stream_count(json):
    audioStreams = list(filter(lambda s: 'audio' == s['codec_type'], json['streams']))
    count = len(audioStreams)
    print('audio streams: ' + str(count))
    return count

def get_stream_count(json, codec_type):
    streams = list(filter(lambda s: codec_type == s['codec_type'], json['streams']))
    count = len(streams)
    print(f'{codec_type} streams: {count}')
    return count

def get_bitrate_float(input, data): # bitrate in Mbps
    try:
        dur = float(get_duration(data))
    except:
        raise ValueError('failed to get duration: ' + json.dumps(data))

    fsize = os.path.getsize(input)
    print(input + ' = duration: ' + str(dur) + ', size: ' + str(fsize))
    return fsize * 8 / dur / 1000000;

def get_bframe_ratio(json):
    dur = get_duration(json)
    video_frames = list(filter(lambda x:x['media_type']=='video',json['frames']))
    total = len(video_frames)
    if total == 0:
        raise Exception('bframe check: no video frame info found in mediainfo')
    bframes = len(list(filter(lambda x:x['pict_type']=='B',video_frames)))
    return bframes/total


def get_framerate_string(json):
    if 'streams' not in json:
        raise ValueError('video source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s:
            if s['codec_type'] == 'video':
                return s['r_frame_rate']
    raise ValueError('video source does not contain a video stream')

def get_framerate_float(json):
    if 'streams' not in json:
        raise ValueError('video source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s:
            if s['codec_type'] == 'video':
                fields = s['r_frame_rate'].split('/')
                fr = float(fields[0]) / float(fields[1])
                return round(fr, 3)
    raise ValueError('video source does not contain a video stream')

# def get_audio_stream_count(json):
#     count = 0
#     if 'streams' not in json:
#         raise ValueError('video source does not contain any streams')
#     for s in json['streams']:
#         if 'codec_type' in s:
#             if s['codec_type'] == 'audio':
#                 count = count + 1
#     return count

def get_audio_channel_count(json):
    count = 0
    if 'streams' not in json:
        raise ValueError('video source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s:
            if s['codec_type'] == 'audio':
                try:
                    count = count + s['channels']
                except:
                    count = count + 1
    return count
    print('audio streams: ' + str(count))

def get_codec(json):
    if 'streams' not in json:
        raise ValueError('video source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s:
            if s['codec_type'] == 'video':
                return s['codec_name']
    raise ValueError('video source does not contain a video stream')

def get_framerate(json):
    if 'streams' not in json:
        raise ValueError('video source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s:
            if s['codec_type'] == 'video':
                return s['r_frame_rate']
    raise ValueError('video source does not contain a video stream')

def get_resolution(json):
    if 'streams' not in json:
        raise ValueError('video source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s:
            if s['codec_type'] == 'video':
                return str(s['width']) + 'x' + str(s['height'])
    raise ValueError('video source does not contain a video stream')

def get_width(json):
    if 'streams' not in json:
        raise ValueError('video source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s:
            if s['codec_type'] == 'video':
                return str(s['width'])
    raise ValueError('video source does not contain a video stream')

def get_height(json):
    if 'streams' not in json:
        raise ValueError('video source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s:
            if s['codec_type'] == 'video':
                return str(s['height'])
    raise ValueError('video source does not contain a video stream')

def get_pixfmt(json):
    if 'streams' not in json:
        raise ValueError('video source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s:
            if s['codec_type'] == 'video':
                return str(s['pix_fmt'])
    raise ValueError('video source does not contain a video stream')

def get_duration(json):
    if 'format' in json:
        if 'duration' in json['format']:
            return Decimal(json['format']['duration'])
    raise ValueError('source does not include duration information')

def get_duration_ts(json):
    if 'format' in json:
        if 'duration_ts' in json['format']:
            return int(json['format']['duration_ts'])
    raise ValueError('source does not include duration information')


def get_codec_name(json):
    if 'streams' not in json:
        raise ValueError('video source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s:
            if s['codec_type'] == 'video':
                if 'codec_name' in s:
                    return s['codec_name']
    raise ValueError('video source does not contain a codec name')

def get_timecode_track(json):
    if 'streams' not in json:
        raise ValueError('source does not contain any streams')
    for s in json['streams']:
        if 'codec_type' in s and s['codec_type'] == 'data':
            if 'codec_tag_string' in s and s['codec_tag_string'] == 'tmcd':
                return s['tags']["timecode"]
    raise ValueError('source does not contain a timecode track')

def get_is_dropframe(json):
    timecode = get_timecode_track(json)
    return ';' in timecode

def get_maxcll(ffmpeg_script, ffmpeg, input_file, cmd_url):
    from .celery_call import submit_and_check
    cmd_res = submit_and_check(cmd_url, {'args': ['python3', ffmpeg_script, '-f', ffmpeg, '-i', input_file]})
    if cmd_res.get('state') != 'SUCCESS':
        raise Exception('Cannot Grab MaxCLL remotely', cmd_res.get('result'), cmd_res.get('exception'))
    jstart = '|JSTART|'
    jsonobj = cmd_res['result']
    jsonobj = jsonobj[(jsonobj.index(jstart) + len(jstart)):jsonobj.index('|JEND|')].strip()
    return json.loads(jsonobj)

def get_maxcll_qm(ffmpeg_script, ffmpeg, input_file, cmd_url):
    from .qm import QueueManager
    output = QueueManager().mediatools_cmd(['python3', ffmpeg_script, '-f', ffmpeg, '-i', input_file])
    jsonobj = output.split('|JSTART|')[-1].split('|JEND|')[0].strip()
    return json.loads(jsonobj)

if __name__ == '__main__':
    print("Debug ...")
    p = '/mnt/localization/Tools/_tmp/tho/AmrDMnhVd-E0002_OV_V30484765_FP_DPO_ProXQ_UHD-HDR_23_PTB-200_PTB-5120_TVMJT9J4E_proxy.mp4'
    temp = '/mnt/localization/Tools/_tmp/tho'
    media_info = get_media_info(p, temp)
    print(json.dumps(media_info))
    count = get_stream_count(media_info, 'data')
    print(count)