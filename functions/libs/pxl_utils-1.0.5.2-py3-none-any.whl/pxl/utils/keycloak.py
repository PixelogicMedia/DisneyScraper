import os

# sso-dev
__base_auth_url = os.environ.get('FLOWER_OAUTH2_KEYCLOAK_BASE_URL') or 'https://amazon-pixelprint-jumpbox.pixelogicmedia.com:8443/auth/realms/phelix'

# sso-staging
#__base_auth_url = os.environ.get('FLOWER_OAUTH2_KEYCLOAK_BASE_URL', 'https://sso-disney.pixelogicmedia.co/auth/realms/phelix')

__server_url, __realm_name = __base_auth_url.split('realms/')

keycloak_sso = {
    'server_url': __server_url,
    'client_id': os.environ.get('FLOWER_OAUTH2_KEY') or 'aws-pxl-print',
    'realm_name': __realm_name,
    'client_secret_key':  os.environ.get('FLOWER_OAUTH2_SECRET') or 'CBRfHHfRjoqLC4aXghJIZB55wWIZTlfS',
    #sso-staging
    #'client_secret_key': os.environ.get('FLOWER_OAUTH2_SECRET', '0fe3e280-77a7-48aa-acfa-d5fa1df5c7e9'),
}