from __future__ import absolute_import

import logging
import logging.handlers 
import datetime
import os, sys, socket

#logger.info('msg')
#logger.warning('msg')
#logger.error('msg')
#logger.critical('msg')
#logger.exception('msg')

class Logger(logging.Logger):
    def __init__(self, name, add_date = False, customLogFolder = None):
        if add_date:
            name += datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        if not name:
            name = 'common'
            
        logging.Logger.__init__(self, name)
        self.setLevel(logging.DEBUG)

        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

        ch = logging.StreamHandler(sys.stdout)
        ch.setFormatter(formatter)
        ch.setLevel(logging.DEBUG)
        self.addHandler(ch)

        is_cloud = os.getenv("AWS_DEPLOYMENT") == '1' or 'AWS_EXECUTION_ENV' in os.environ or os.getenv('LOG_TO_CONSOLE_ONLY') in [True, 'true', '1']
        
        # env = os.getenv("AWS_DEPLOYMENT", False)
        # env = env != None and env == '1'
        if not is_cloud:
            host_name = socket.gethostname() 
            logfolder = f'logs/{host_name}/{name}'

            lognetworkfolders = [
                '/mnt/aws-pixelprint-code/Celery/_Temp', # AWS log
                '/mnt/prodstor1/_Tools/Celery/_Temp',
                '/mnt/PXL_HDS_fs01/_Tools/Celery/_Temp',
                '/mnt/pxl-odfs05/Celery/_Temp',
            ]
            for networkfolder in lognetworkfolders:            
                if os.path.exists(networkfolder):
                    logfolder = os.path.join(networkfolder, logfolder)
                    break
                    
            if customLogFolder:
                _tmp = os.path.join(customLogFolder, name)
                try: os.makedirs(_tmp)
                except: pass
                if os.path.isdir(_tmp):
                    logfolder = _tmp
            try: os.makedirs(logfolder)
            except: pass

            if os.path.isdir(logfolder):
                rh = logging.handlers.RotatingFileHandler(logfolder + '/' + name + '.log', mode='a', maxBytes=5*1024*1024, backupCount=10)
                rh.setFormatter(formatter)
                rh.setLevel(logging.DEBUG)
                self.addHandler(rh)
            else:
                self.error('Cannot create log folder: ' + logfolder)

        
        self.info('### Start Logging ... ' + name)

def is_running_in_aws():
    # Check for AWS Lambda
    if os.getenv('AWS_LAMBDA_FUNCTION_NAME'):
        return True
    # Check for AWS Batch
    if os.getenv('AWS_BATCH_JOB_ID'):
        return True
    # Check for AWS EC2
    try:
        import requests
        response = requests.get('http://169.254.169.254/latest/meta-data/', timeout=1)
        if response.status_code == 200:
            return True
    except Exception as e:
        pass
    return False

class Logger2(logging.Logger):
    def __init__(self, name='', add_date = False, log_folder = '', log_level = logging.DEBUG):
        if not name:
            name = 'common'
        if add_date:
            name += datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            
        logging.Logger.__init__(self, name)
        self.setLevel(log_level)

        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

        # console handler
        ch = logging.StreamHandler(sys.stdout)
        ch.setFormatter(formatter)
        ch.setLevel(log_level)
        self.addHandler(ch)

        if not is_running_in_aws():
            # add file handler
            if log_folder:
                log_folder = os.path.join(log_folder, name)
            else:
                log_network_folders = [
                    '/mnt/prodstor1/_Tools/Celery/_Temp',
                    '/mnt/PXL_HDS_fs01/_Tools/Celery/_Temp',
                    '/mnt/pxl-odfs05/Celery/_Temp'
                ]
                for network_folder in log_network_folders:            
                    if os.path.exists(network_folder):
                        log_folder = network_folder
                        break
                log_folder = os.path.join(log_folder, 'logs', str(socket.gethostname()), name)

            try: os.makedirs(log_folder)
            except: pass

            # make sure folder exists or created
            if os.path.isdir(log_folder):
                log_file = os.path.join(log_folder, name + '.log')
                rh = logging.handlers.RotatingFileHandler(log_file, mode='a', maxBytes=5*1024*1024, backupCount=10)
                rh.setFormatter(formatter)
                rh.setLevel(log_level)
                self.addHandler(rh)
            else:
                self.error('Cannot create log folder: ' + log_folder)

        
        self.info('### Start Logging ... ' + name)


if __name__ == '__main__':
    log_levels = [logging.CRITICAL, logging.ERROR, logging.WARNING, logging.INFO, logging.DEBUG]
    for l in log_levels:
        log = Logger2(log_level=l)
        log.log(l, f'log level: {l}')
        log.debug(f'This is PXL common debug log ... ')
        log.info(f'This is PXL common info log ... ')
        log.warn(f'This is PXL common warn log ... ')
        log.error(f'This is PXL common error log ... ')
        log.exception(f'This is PXL common exception log ... ')
        log.critical(f'This is PXL common critical log ... ')

        print('#############')
    