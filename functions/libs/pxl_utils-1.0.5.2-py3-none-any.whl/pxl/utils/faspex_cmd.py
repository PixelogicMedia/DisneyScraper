from __future__ import absolute_import, with_statement

import datetime, json, re, os, requests, time, copy
import xml.etree.ElementTree as ET


from .logger import Logger
from .misc import parseErr, fixEmailsArr, fixEmailsStr, generatePassphrase, getHostNameIP, cmd_check_output

try:
    from ..secrets.service_setup import faspexcmd_username, faspexcmd_password, faspexcmd_clientId, faspexcmd_clientSecret, fasp5username, fasp5password, faspex_user, faspex_apikey, fasp2username, fasp2password, faspexcmd_cbsusername, faspexcmd_cbspassword, faspexcmd_disneyusername, faspexcmd_disneypassword
except:
    pass


DEBUG = False

log = Logger('faspex_cmd')

limit_tasks = 3
tmp_path = '/tmp/faspex_cmd'

email_template = '''
<h1>Faspex Package - ##title## </h1>
<p>File(s) Sent: <br /> ##filename##</p>
<pre> ##note#</pre>
<pre>Passphrase - ##password##</pre>
'''

default_options = {
    'aspera_path': '/home/pixelogic/.aspera/cli/bin/aspera',
    #'aspera_path': '/root/.aspera/cli/bin/aspera', #uk
    'aspera_opts': {
        'host': 'bur-p-fasp03.pixelogicmedia.com', #burbank
        'insecure': 'yes',
        'username': faspexcmd_username,
        'password': faspexcmd_password,
        'ascp-path': '/home/pixelogic/.aspera/cli/bin/ascp',
        'sdk-folder': '/home/pixelogic/.aspera/ascli/sdk'
    },
    'ascli_path': '/usr/local/bin/ascli',    
    'clients_config': '/mnt/pxl-vault02/_Data_IO_/Faspex_Client_Onboarding/creds.json',
    'clients': {
        'faspex2': {
            'host': 'faspex2.pixelogicmedia.com',
            'username': fasp2username,
            'password': fasp2password
        },
        'faspex3': {
            'host': 'faspex3.pixelogicmedia.com',
            'username': fasp2username,
            'password': fasp2password
        },
        'faspex4': {
            'host': 'faspex4.pixelogicmedia.com',
            'username': fasp2username,
            'password': fasp2password
        },
        'cbs': {
            'host': 'ny-asperafaspex.cwd.cbs.com',
            'username': faspexcmd_cbsusername,
            'password': faspexcmd_cbspassword
        },
        'paramount': {
            'host': 'faspex.paramount.com',
            'username': '',
            'password': ''
        },
        'disney': {
            'host': 'charles.studio.disney.com',
            'username': faspexcmd_disneyusername,
            'password': faspexcmd_disneypassword
        },
        'dmz':{
            'host': '172.16.255.93',
            'username': fasp5username,
            'password': fasp5password
        }
    },
    'supportsFaspex5': [
        'dmz',
        '172.16.255.93'
    ],
    #'jobs': {},
    # 'sample_jobs': {
    #     '1': {
    #         'title': 'email title',
    #         'sender': 'sender emails', #reserved
    #         'link_emails': 'link recipient emails',  # required
    #         'pw_emails': 'pw emails',
    #         'file': 'file path',  # requires file or files,
    #         'files': [],  # requires file or files,
    #         'note': 'note sent with email',
    #     }
    # },
    'admin_emails': 'automated.notifications@pixelogicmedia.com',

    'email_template_path': '/mnt/localization/Tools/templates/faspex_pw_email.html',

    'tmp': 'faspex_cmd'
}

class FaspexCmd:
    def __init__(self, opts):
        self.options = copy.deepcopy(default_options)
        self.__initOption()
        if opts: self.options.update(opts)

        if os.system('which aspera') == 0:
            self.options['aspera_path'] = 'aspera'
        elif os.system('which "' + self.options.get('aspera_path').strip('"').strip("'") + '"') != 0:
            raise Exception('Invalid aspera path', self.options['aspera_path'])
        
        try: os.makedirs(tmp_path)
        except: pass

        try:
            if 'clients_config' in self.options and os.path.isfile(self.options['clients_config']):
                with open(self.options['clients_config'], 'r') as f:
                    clients = json.load(f)
                self.options['clients'].update(clients)
        except Exception as err:
            log.exception(err)

    def __initOption(self):
        host, ip = getHostNameIP()
        if ip.startswith('10.100.'):
            self.options['aspera_opts']['host'] = 'bur-p-fasp03.pixelogicmedia.com'
        elif ip.startswith('172.16.') or 'DMZ' in host:
            self.options['aspera_opts']['host'] = 'faspex4.pixelogicmedia.com'
        elif ip.startswith('10.200.130'):
            self.options['aspera_opts']['host'] = 'faspex3.pixelogicmedia.com'
        elif ip.startswith('10.200.110'):
            self.options['aspera_opts']['host'] = 'faspex3.pixelogicmedia.com'
        elif ip.startswith('10.200.'):
            self.options['aspera_opts']['host'] = 'faspex3.pixelogicmedia.com'
        elif ip.startswith('10.200.111') or host.startswith('LA-P'):
            self.options['aspera_opts']['host'] = 'faspex3.pixelogicmedia.com'
        elif ip.startswith('10.110.'):
            self.options['aspera_opts']['host'] = 'faspexuk.pixelogicmedia.com'
        elif ip.startswith('10.130.'):
            self.options['aspera_opts']['host'] = 'faspexuk.pixelogicmedia.com'
        else:
            self.options['aspera_opts']['host'] = ''            

    def createFaspex5Payload(self, job, filepaths):
        #send request
        cmd = [self.options['ascli_path'], 'faspex5', 'package', 'send']
        for opt in self.options['aspera_opts']:
            val=self.options['aspera_opts'][opt]
            if opt == 'host':
                cmd.append(f'--url=https://{val}/aspera/faspex')
            else:
                if val and val != '' and val != True:
                    cmd.append(f'--{opt}={val}')
                else:
                    cmd.append(f'--{opt}')
                
        cmd.append('--auth=jwt')
        cmd.append('--private-key=@file:/root/.ssh/id_rsa')
        cmd.append(f'--client-id={faspexcmd_clientId}')
        cmd.append(f'--client-secret={faspexcmd_clientSecret}')

        link_emails = [{"name": email, "recipient_type": "external_user"} for email in list(set(fixEmailsArr(job['link_emails'])))]
        delivery_info = {"title": job["title"], "note":job["note"], "recipient_types":"user", "recipients": link_emails, "bcc_recipients": self.options['admin_emails']}
        
        cmd += [f'--value=@json:{json.dumps(delivery_info)}']
        cmd += filepaths
        return cmd

    def createFaspex4Payload(self, job, filepaths):
        #send request
        cmd = [self.options['ascli_path'], 'faspex', 'package', 'send']
        for opt in self.options['aspera_opts']:
            val=self.options['aspera_opts'][opt]
            if opt == 'host':
                cmd.append(f'--url=https://{val}/aspera/faspex')
            else:
                if val and val != '' and val != True:
                    cmd.append(f'--{opt}={val}')
                else:
                    cmd.append(f'--{opt}')
                
        link_emails = fixEmailsArr(job['link_emails'])
        delivery_info = {"title": job["title"], "note":job["note"], "recipients": link_emails}
        
        cmd += [f'--delivery-info=@json:{json.dumps(delivery_info)}']
        cmd += filepaths
        return cmd

    def delivery(self, job):
        try:
            log.info(self.options)
            if job.get('aspera_opts'):
                self.options['aspera_opts'].update(job['aspera_opts'])
            client = job.get('client')
            if client and client in self.options['clients']:
                self.options['aspera_opts'].update(self.options['clients'][client])
                log.info(self.options['aspera_opts'])
            if not self.options['aspera_opts']['host']:
                raise Exception('No client or wrong faspex server')
            if not job.get('file') and not job.get('files'):
                raise Exception('Invalid file(s)')
            filepaths = []
            if job.get('file'):
                filepaths = [job.get('file')] #[path_detection(job.get('file'))[0]['mnt_full']]
            if job.get('files'):
                for fp in job.get('files'):
                    filepaths.append(fp) #path_detection(fp)[0]['mnt_full'])
            if not filepaths:
                raise Exception(f'Invalid file(s): {str(job.get("file"))} - {str(job.get("files"))}')

            for fp in filepaths:
                if not os.path.exists(fp):
                    raise Exception('File not found:' + fp)
            
            if not job.get('link_emails'):
                raise Exception('Invalid recipient emails')
            dt = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            job['title'] += ' ' + dt

            is_no_pw = job.get('no_passphrase')
            if is_no_pw:
                job['passphrase'] = ''
            else:
                pw = generatePassphrase()
                job['passphrase'] = pw

            job['link_emails'] += ',' + self.options['admin_emails']
            # if not (self.options['aspera_opts']['host'] in self.options['supportsFaspex5']):
            #     job['link_emails'] += ',' + self.options['admin_emails']
            cmd = self.createFaspex5Payload(job, filepaths=filepaths) if self.options['aspera_opts']['host'] in self.options['supportsFaspex5'] else self.createFaspex4Payload(job, filepaths=filepaths)

            log.info(cmd)
            job['faspex_cmd'] = ' '.join(cmd)            
            #save tmp
            try:
                tmpfile = re.sub(r'[^\w\-_\. ]', '_', job["title"])
                with open(f'/tmp/{tmpfile}_faspexcmd_{dt}.log', 'w') as f:
                    json.dump([job['faspex_cmd'], pw], f)
            except: pass
            cmd_env = {} 
            if not is_no_pw:
                cpjson = json.dumps({"content_protection":"encrypt", "content_protection_password": pw})
                cmd += [f'--ts=@json:{cpjson}'] 
 
            retries = 5
            while retries > 0:
                try:
                    job['result'] = cmd_check_output(cmd, cmd_env)
                    break
                except Exception as cmd_err:
                    log.exception(cmd_err)
                    retries -= 1
                    if 'Error: Unauthorized' not in str(cmd_err) or retries <= 0:
                        raise cmd_err
                    time.sleep(15)
            if not job.get('result'):
                raise Exception('unknown error')
            log.info(job)
            #email pw
            if job['passphrase']:
                if job.get('pw_emails'):
                    job['pw_emails'] += ',' + self.options['admin_emails']
                else:
                    job['pw_emails'] = self.options['admin_emails']
                file_list = [os.path.basename(fp) for fp in filepaths]
                job['pw_emails_sent'] = self.email_pw(job['title'], file_list, job['note'], pw, job['pw_emails'])
            return job
        except Exception as err:
            log.exception(err)
            raise Exception(parseErr(str(err), [self.options['aspera_opts']['username'], self.options['aspera_opts']['password']]))

    def email_pw(self, title, file_list, note, pw, to_emails):
        pw_emails=fixEmailsStr(to_emails)
        email_body = '<h1>Faspex Package - ' + title + '</h1>'
        email_body += '<p>File(s) Sent:' + '<br />'.join(file_list) + '</p>'
        email_body += f'<pre>{note}</pre>'
        email_body += f'<pre>Passphrase - {pw}</pre>'

        # try using NotificationService
        try:
            from .notification import NotificationService
            ns = NotificationService()
            return ns.send_notification(pw_emails, title, email_body)
        except Exception as e:
            log.exception(e)
        
        log.info('NotificationService failed, using Email')
        from .send_email import Email
        email = Email()
        return email.send(pw_emails, title, email_body)
    

default_options_download = {
    'aspera_opts': {
        'insecure': '',
        'overwrite': 'always'
    },

    '#job': {
        'package_url': 'https://faspex2.pixelogicmedia.com/aspera/faspex/received/####',
        'destination': '/tmp/test',
        'passphrase': '',
        'client': 'test',
        'aspera_opts': {
            'host': 'faspex2.pixelogicmedia.com',
            'username': 'tho',
            'password': 'pixel.2020'
        }
    },
}

class FaspexCmdDownload:
    def __init__(self, opts):
        self.options = copy.deepcopy(default_options)
        self.options.update(default_options_download)
        self.__initOption()
        if opts:
            self.options.update(opts)
        # if not os.path.isfile(self.options.get('aspera_path')):
        #     raise Exception('Invalid aspera path: ' + self.options.get('aspera_path'))
        if os.system('"' + self.options.get('aspera_path').strip('"').strip("'") + '"') != 0:
            raise Exception('Invalid aspera path')
        try: os.makedirs(tmp_path)
        except: pass

        try:
            if 'clients_config' in self.options and os.path.isfile(self.options['clients_config']):
                with open(self.options['clients_config'], 'r') as f:
                    clients = json.load(f)
                self.options['clients'].update(clients)
        except Exception as err:
            log.exception(err)

    def __initOption(self):
        host, ip = getHostNameIP()
        if ip.startswith('10.100.'):
            self.options['aspera_path'] = '/home/pixelogic/.aspera/cli/bin/aspera'
            self.options['aspera_opts']['host'] = 'bur-p-fasp03.pixelogicmedia.com'
        elif ip.startswith('10.200.110'):
            self.options['aspera_path'] = '/home/pixelogic/.aspera/cli/bin/aspera'
            self.options['aspera_opts']['host'] = 'faspex3.pixelogicmedia.com'
        elif ip.startswith('10.200.111') or host.startswith('LA-P'):
            self.options['aspera_path'] = '/home/celery/.aspera/cli/bin/aspera'
            self.options['aspera_opts']['host'] = 'faspex3.pixelogicmedia.com'
        elif ip.startswith('10.110.'):
            self.options['aspera_path'] = '/root/.aspera/cli/bin/aspera'
            self.options['aspera_opts']['host'] = 'faspexuk.pixelogicmedia.com'
        else:
            self.options['aspera_path'] = 'aspera'
            self.options['aspera_opts']['host'] = ''

    def createFaspex5Payload(self, job, faspe):
        #send request
        cmd = [self.options['ascli_path'], 'faspex5', 'package', 'receive', faspe]
        for opt in self.options['aspera_opts']:
            val=self.options['aspera_opts'][opt]
            if opt == 'host':
                cmd.append(f'--url=https://{val}/aspera/faspex')
            else:
                if val and val != '' and val != True:
                    cmd.append(f'--{opt}={val}')
                else:
                    cmd.append(f'--{opt}')
                
        cmd.append('--auth=jwt')
        cmd.append('--private-key=@file:/root/.ssh/id_rsa.pem')
        cmd.append(f'--client-id={faspexcmd_clientId}')
        cmd.append(f'--client-secret={faspexcmd_clientSecret}')
        cmd.append(f'--to-folder={job["destination"]}')
        
        if  job.get('passphrase'):
            cpjson = json.dumps({"content_protection":"decrypt", "content_protection_password": job['passphrase']})
            cmd += [f'--ts=@json:{cpjson}'] 

        return cmd
    
    def createOldFaspexPayload(self, job, faspe):        
        cmd = [self.options['aspera_path'], 'faspex', 'get']
        for opt in self.options['aspera_opts']:
            arg='--'+opt
            val=self.options['aspera_opts'][opt]
            #if ' ' in val:
                #val = '"' + val.replace('"', '\\"') + '"'
            if val == '' or val == True:
                cmd.append(arg)
            elif val:
                cmd += [arg, val]
        if '--content-protect-password' not in cmd and job.get('passphrase'):
            cmd += ['--content-protect-password', job['passphrase']]
        
        cmd += ['--file', job['destination']]

        cmd += ['--url', faspe]

    def download(self, job):
        try:
            if job.get('aspera_opts'):
                self.options['aspera_opts'].update(job['aspera_opts'])
            if job.get('client'):
                self.options['aspera_opts'].update(self.options['clients'][job.get('client')])
            package_url = job.get('package_url')
            host = package_url.split('//',1)[-1].split('/', 1)[0]
            self.options['aspera_opts']['host'] = host

            if not package_url:
                raise Exception('invalid package url')
            
            res = requests.get(package_url, auth=requests.auth.HTTPBasicAuth(self.options['aspera_opts']['username'], self.options['aspera_opts']['password']), headers={'Accept': 'application/xml'}, verify=False)
            xml_content = res.content
            xml = ET.fromstring(xml_content)
            if xml.tag  == 'error':
                raise Exception(ET.tostring(xml))
            # link_ele = xml.find('./link[@rel="package"]')
            # log.info(ET.tostring(link_ele))
            # if not link_ele:
            #     raise Exception('Invalid package: ' + package_url)
            
            # faspe = html.unescape(link_ele.attrib['href'])
            print('xml:')
            print(xml_content)
            faspe = xml.find('./link[@rel="package"]').get('href')

            cmd = self.createFaspex5Payload(job, faspe) if self.options['aspera_opts']['host'] in self.options['supportsFaspex5'] else self.createOldFaspexPayload(job, faspe)

            try: os.makedirs(job['destination'])
            except: pass

            log.info(cmd)
            job['result'] = cmd_check_output(cmd)
            return job
        except Exception as err:
            log.exception(err)
            raise Exception(parseErr(str(err), [self.options['aspera_opts']['username'], self.options['aspera_opts']['password']]))

    

### end faspex+cmd ###

if __name__ == '__main__':
    files = '''/mnt/pxl-pfs02/_moas/2115/VX-10578055/DBSuper_JP_ep01_20FRE_2398_test_20240301.mp4
/mnt/pxl-odfs05/Celery/_Temp/Spectre/_avaps_/recipe/2448dbdf-31b7-4d66-a633-73a4d87508ae.xml
/mnt/pxl-odfs05/Celery/_Temp/Spectre/_avaps_/recipe/2448dbdf-31b7-4d66-a633-73a4d87508ae.js'''
    note = '''**********************************************************
AVAPS
Log started: 2 Mar 2024 7:37:10pm
 
Verbose Mode On
Running Dialog Intelligence perComp:-1.0
Analyzing Audio perComp:1.0
Analyzing Audio perComp:5.0
Analyzing Audio perComp:10.0
Analyzing Audio perComp:15.0
Analyzing Audio perComp:20.0
Analyzing Audio perComp:25.0
Analyzing Audio perComp:30.0
Analyzing Audio perComp:35.0
Analyzing Audio perComp:40.0
Analyzing Audio perComp:45.0
Analyzing Audio perComp:50.0
Analyzing Audio perComp:55.0
Analyzing Audio perComp:60.0
Analyzing Audio perComp:65.0
Analyzing Audio perComp:70.0
Analyzing Audio perComp:75.0
Analyzing Audio perComp:80.0
Analyzing Audio perComp:85.0
Analyzing Audio perComp:90.0
Analyzing Audio perComp:95.0
Starved For Audio Data!!!!!!
**** ERROR ****
Error Reading From File
It took :35273.7  ms'''
    to_emails = 'darren.winslow@pixelogicmedia.com'
    job = {
            'title': 'debug data for IQC Verifier Language Detection error',
            'sender': '',
            'link_emails': to_emails,
            'pw_emails': to_emails,
            'files': files.split(), # ['/mnt/localization/Temp/Thanh/for_Darren/DBSuper_JP_ep01_20FRE_2398_test_20240301.mp4.avaps.debug.zip'],
            'note': note,
        }
    faspex = FaspexCmd({})
    result = faspex.delivery(job)
    print(result)

