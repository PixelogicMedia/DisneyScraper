import boto3, json, base64, os
from botocore.exceptions import ClientError


def get_secret(secret_name, region_name=None):
    region_name = region_name or os.getenv('AWS_REGION')
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )        
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return json.loads(secret)
        else:
            return json.loads(base64.b64decode(get_secret_value_response['SecretBinary']))

    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            raise e
        
def update_secret(secret_name, region_name, new_values):
    region_name = region_name or os.get('AWS_REGION')
    # get original secrets
    secret_values = get_secret(secret_name, region_name)
    session = boto3.session.Session() #might need to add your personal profile
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,        
    )
    # update secrets
    secret_values.update(new_values)
    client.update_secret(SecretId=secret_name, SecretString=json.dumps(secret_values))


def get_env_secret(env_secret_name=''):
    env_secret_name = env_secret_name or 'SECRET_NAME'
    aws_secret_name = os.getenv(env_secret_name) or ''
    aws_region = os.getenv('AWS_REGION') or ''

    try:
        return get_secret(aws_secret_name, aws_region) or {}
    except:
        return {}
    