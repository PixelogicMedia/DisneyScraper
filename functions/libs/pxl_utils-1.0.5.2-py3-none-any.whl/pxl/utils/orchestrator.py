from __future__ import absolute_import

from .logger import Logger

try:
    from ..secrets.service_setup import orchestrator_login, orchestrator_api_key
except:
    orchestrator_login = ''
    orchestrator_api_key = ''

import requests
import copy, time, sys, json


DEBUG = False


log = Logger('orchestrator')


class Orchestrator:
    options = {
        '#baseurl': 'https://10.220.110.163',
        'baseurl': 'https://orchestrator.pixelogicmedia.com',
        'auth': {'login': orchestrator_login, 'api_key': orchestrator_api_key},
        
        'timeout': 7200,
    }

    def __init__(self, opts = {}):
        if opts:
            self.options.update(opts)
        if not self.options.get('baseurl') or not self.options.get('auth'):
            raise Exception('Invalid options')

    def run(self, job, submit_only = False):
        log.info(job)
        if not job.get('workflow_id'):
            raise Exception('No workflow_id', job)
        job['submit'] = self.__submit(job)
        if submit_only:
            return job
        id = str(job['submit']['work_order']['id'])
        job['job_url'] = self.options['baseurl'] + '/work_orders/' + id
        log.info(job)

        #check
        status = self.__check(id)
        log.info('status: ' + status['work_order']['status'])
        job['result'] = status
        log.info(job)

        if job['result']['work_order']['status'] != 'Complete':
            raise Exception(str(job))

        return job

    def __submit(self, job):
        log.info('submit job to Orch ... ')
        params = copy.deepcopy(self.options['auth'])
        for arg in job.get('args') or []:
            if arg.startswith('external_parameters['):
                params[arg] = job['args'][arg]
            else:
                params[f'external_parameters[{arg}]'] = job['args'][arg]
        log.info(params)
        raw_post_body = job.get('Raw_post_body')
        log.info(raw_post_body)
        
        
        count = 5
        err = 'unknown'
        while count>0:
            if raw_post_body:
                res = requests.post(self.options['baseurl'] + '/api/initiate/' + str(job['workflow_id']) + '.json', params=params, data=raw_post_body, verify=False)
            else:
                res = requests.get(self.options['baseurl'] + '/api/initiate/' + str(job['workflow_id']) + '.json', params=params, verify=False)
            if res.status_code == 200:
                return res.json()
            err = f'code: {res.status_code} - {str(res.content)}'
            log.info(err)
            count-=1
            time.sleep(10)
        raise Exception(err)

    def __check(self, id):
        log.info('Checking status for ... ' + id)
        params = copy.deepcopy(self.options['auth'])
        url = self.options['baseurl'] + '/api/work_order_status/' + id + '.json'
        timeout = time.time() + (self.options.get('timeout') or 3600)
        result = {}
        while timeout > time.time():
            time.sleep(30)
            res = requests.get(url, params=params, verify=False)
            if res.status_code == 200:
                result = res.json() 
                if result['work_order']['status'] in ['Failed', 'Error', 'Complete']:
                    return result
        cancel_result = self.__cancel(id)
        raise Exception('timeout', result, cancel_result)

    def __cancel(self, id):
        #http://Orchestrator_IP_address/aspera/orchestrator/api/work_order_cancel/work_order_id?login=admin&password=aspera
        log.info('cancelling status for ... ' + id)
        params = copy.deepcopy(self.options['auth'])
        url = self.options['baseurl'] + '/api/work_order_cancel/' + id + '.json'
        res = requests.get(url, params=params, verify=False)
        res.raise_for_status()
        return res.json()
    
    def workflow_stat(self, workflow_id=0):
        log.info(f'Checking workflow stat for ... {workflow_id}')
        params = copy.deepcopy(self.options['auth'])
        url = f"{self.options['baseurl']}/api/workflows_status/{workflow_id}.json"
        res = requests.get(url, params=params, verify=False)
        res.raise_for_status()
        return res.json()
    
    #http://Orchestrator_IP_address/aspera/orchestrator/api/ workflow_details/workflow_id?login=admin
    def workflow_details(self, workflow_id=0):
        log.info(f'Checking workflow details for ... {workflow_id}')
        params = copy.deepcopy(self.options['auth'])
        url = f"{self.options['baseurl']}/api/workflow_details/{workflow_id}.json"
        res = requests.get(url, params=params, verify=False)
        res.raise_for_status()
        return res.json()
    
    def monitor_snapshot(self):
        #http://Orchestrator_IP_address/aspera/orchestrator/api/monitor_snapshot/all.json
        log.info('Checking monitor_snapshot for ...')
        params = copy.deepcopy(self.options['auth'])
        url = f"{self.options['baseurl']}/api/monitor_snapshot/all.json"
        res = requests.get(url, params=params, verify=False)
        res.raise_for_status()
        return res.json()

if __name__ == '__main__':
    if sys.argv[1] != 'debug':
        print('For debug only')
        exit(1)
    result = Orchestrator({}).workflow_details(394)

    log.info(json.dumps(result))
    

### end ###
