from __future__ import absolute_import

from .logger import Logger

try:
    from ..secrets.service_setup import orchestrator4_login, orchestrator4_api_key
except:
    orchestrator4_login = ''
    orchestrator4_api_key = ''

import requests, json
import copy, time, sys


DEBUG = False


log = Logger('orchestrator')


class Orchestrator:
    options = {
        'baseurl': 'https://orchestrator-4-prod.pixelogicmedia.com/aspera/orchestrator',
        'auth': {'login': orchestrator4_login, 'api_key': orchestrator4_api_key},
        
        'timeout': 7200,
    }

    def __init__(self, opts = {}):
        if opts:
            self.options.update(opts)
        if not self.options.get('baseurl') or not self.options.get('auth'):
            raise Exception('Invalid options')

    def run(self, job, submit_only = False):
        log.info(job)
        if not job.get('workflow_id'):
            raise Exception('No workflow_id', job)
        job['submit'] = self.__submit(job)
        if submit_only:
            return job
        id = str(job['submit']['work_order']['id'])
        job['job_url'] = self.options['baseurl'] + '/work_orders/' + id
        log.info(job)

        #check
        status = self.__check(id)
        log.info('status: ' + status['work_order']['status'])
        job['result'] = status
        log.info(job)

        if job['result']['work_order']['status'] != 'Complete':
            raise Exception(str(job))

        return job

    def __submit(self, job):
        log.info('submit job to Orch ... ')
        params = copy.deepcopy(self.options['auth'])
        for arg in job.get('args') or []:
            if arg.startswith('external_parameters['):
                params[arg] = job['args'][arg]
            else:
                params[f'external_parameters[{arg}]'] = job['args'][arg]
        log.info(params)
        raw_post_body = job.get('Raw_post_body')
        
        count = 5
        err = 'unknown'
        while count>0:
            if raw_post_body:
                log.info("posting ...")
                res = requests.post(self.options['baseurl'] + '/api/initiate/' + str(job['workflow_id']) + '.json', params=params, data=raw_post_body, verify=False)
            else:
                log.info("getting ...")
                res = requests.get(self.options['baseurl'] + '/api/initiate/' + str(job['workflow_id']) + '.json', params=params, verify=False)
            if res.status_code == 200:
                return res.json()
            err = f'code: {res.status_code} - {str(res.content)}'
            log.info(err)
            count-=1
            time.sleep(10)
        raise Exception(err)

    def __check(self, id):
        log.info('Checking status for ... ' + id)
        params = copy.deepcopy(self.options['auth'])
        url = self.options['baseurl'] + '/api/work_order_status/' + id + '.json'
        timeout = time.time() + (self.options.get('timeout') or 3600)
        result = {}
        while timeout > time.time():
            time.sleep(30)
            res = requests.get(url, params=params, verify=False)
            if res.status_code == 200:
                result = res.json() 
                if result['work_order']['status'] in ['Failed', 'Error', 'Complete']:
                    return result
        cancel_result = self.__cancel(id)
        raise Exception('timeout', result, cancel_result)

    def __cancel(self, id):
        #http://Orchestrator_IP_address/aspera/orchestrator/api/work_order_cancel/work_order_id?login=admin&password=aspera
        log.info('cancelling status for ... ' + id)
        params = copy.deepcopy(self.options['auth'])
        url = self.options['baseurl'] + '/api/work_order_cancel/' + id + '.json'
        res = requests.get(url, params=params, verify=False)
        return res.json()
    
    def workflow_stat(self, workflow_id=0):
        log.info(f'Checking workflow stat for ... {workflow_id}')
        params = copy.deepcopy(self.options['auth'])
        url = f"{self.options['baseurl']}/api/workflows_status/{workflow_id}.json"
        res = requests.get(url, params=params, verify=False)
        res.raise_for_status()
        return res.json()
    
    #http://Orchestrator_IP_address/aspera/orchestrator/api/ workflow_details/workflow_id?login=admin
    def workflow_details(self, workflow_id=0):
        log.info(f'Checking workflow details for ... {workflow_id}')
        params = copy.deepcopy(self.options['auth'])
        url = f"{self.options['baseurl']}/api/workflow_details/{workflow_id}.json"
        res = requests.get(url, params=params, verify=False)
        res.raise_for_status()
        return res.json()
    
    def monitor_snapshot(self):
        #http://Orchestrator_IP_address/aspera/orchestrator/api/monitor_snapshot/all.json
        log.info('Checking monitor_snapshot for ...')
        params = copy.deepcopy(self.options['auth'])
        url = f"{self.options['baseurl']}/api/monitor_snapshot/all.json"
        res = requests.get(url, params=params, verify=False)
        res.raise_for_status()
        return res.json()

if __name__ == '__main__':
    if sys.argv[1] != 'debug':
        print('For debug only')
        exit(1)
    result = Orchestrator({}).workflow_details(96)

    log.info(json.dumps(result))

    # item_to_transfer1 = '''/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_AR_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_CMNHANS_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_CMNHANT_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_DA_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_DE_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_EL_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_ES419_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_ESES_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_ET_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_FI_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_FRCA_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_FRFR_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_HE_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_HI_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_HU_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_ID_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_IT_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_KO_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_LV_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_MS_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_NO_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_PL_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_PT_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_RU_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_SK_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_SL_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_SV_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_TA_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_TE_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_UK_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_VI_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf,,/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/ALULA_MESSISWORLDCUP_S1_TRAILER_ORIGINAL_BONUS_ANCDOC_YUEHANT_DOWNLOAD_FINAL_A0119001PRO4_PFMORG_LOC_REPORT.pdf'''
    
    # item_to_transfer0 = '/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48'
    
    # result = Orchestrator({}).run({
    #     # "workflow_id": "170",
    #     # "args": {
    #     #     "str_arg": "/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/_Staging_Archive/2023/2023_12_31/AO/1326454.itmsp_2023-12-31_07-34-48/1326454.itmsp/"
    #     # }
    #     'workflow_id': '173',
    #     'args': {
    #         'debug': 'true',
    #         # 'item_to_transfer': item_to_transfer0,
    #         # 'remoteRoot': '/Alula_test'
    #     },
    #     'Raw_post_body': json.dumps({
    #         'xml_content': open('/mnt/PXL-MPFS01/MOT-DDM/10_Delivery_Staging/Premiere - Alula/Alula/2024_02_21/EC/1356157.itmsp_2024-02-21_15-29-44/1356157.itmsp/metadata.xml', 'r').read(),
    #         'item_to_transfer': item_to_transfer1,
    #         'redeliver': 'true',
    #         'remoteRoot': '/Alula_test'
    #     }),
    # })

    # log.info(result)
    

### end ###
