import requests, copy, os, time
from urllib.parse import urlencode
from .sso import getSSOToken

sec={}
try:
    from ..secrets.service_setup import om_sso_client_id, om_sso_client_secret, coredb_base_url as base_url
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    om_sso_client_id = sec.get('sso_client_id') or os.getenv('SSO_CLIENT_ID') or ''
    om_sso_client_secret = sec.get('sso_client_secret') or os.getenv('SSO_CLIENT_SECRET') or ''
    base_url = sec.get('coredb_base_url') or os.getenv('COREDB_BASE_URL') or ''


from .logger import Logger
log = Logger('cordb')

default_options = {
    # https://coredb.pixelogicmedia.com/api/v1
    'base_url': base_url,
    'sso_opt': {
        'grant_type': 'client_credentials',
        'client_id': om_sso_client_id,
        'client_secret': om_sso_client_secret,
    },
}

class CoreDbWrapper:
    def __init__(self, opts=None):
        self.options = copy.deepcopy(default_options)
        if opts: self.options.update(opts)
        self.__base_url = self.options['base_url']
        self.__access_token = ''
        self.__token_expiration = None
        self.__refresh_headers()

    def __refresh_headers(self):
        if not self.__access_token or time.time() > self.__token_expiration:
            token_data = getSSOToken(self.options['sso_opt'])
            self.__token_expiration = time.time() + token_data['expires_in'] - 10
            self.__access_token = token_data['access_token']

        return {
            'Authorization': 'Bearer ' + self.__access_token
        }

    def __api_url(self, path, query_params=''):
        if not path.startswith(self.__base_url):
            path = self.__base_url.strip('/') + '/' + path.lstrip('/')
        path = path.replace('/api/v1/api/v1/', '/api/v1/')
        
        if type(query_params) == dict:
            query_params = urlencode({k:v for k,v in query_params.items() if v})
        query_params = '' if not query_params else f"?{query_params.strip('?')}"

        return path.lstrip('/') + query_params
        
    def call_api(self, url, method='GET', data=None, query_params=None, headers={}):
        log.debug(f"Calling COREDB API [{method}] {url} with data: {data} and query_params: {query_params}")
        if query_params or not url.startswith(self.__base_url):
            url = self.__api_url(url, query_params)
        headers.update(self.__refresh_headers())
        if type(data) in [dict, list] and 'Content-Type' not in headers:
            response = requests.request(method, self.__api_url(url), headers=headers, json=data)
        else:
            response = requests.request(method, self.__api_url(url), headers=headers, data=data)
        log.debug(f"COREDB API response: {response.status_code} / {response.content}")
        response.raise_for_status()
        try: return response.json()
        except: return response.content
    
    # general AM API call
    def get_api(self, url, query_params=None, headers={}):
        return self.call_api(url, query_params=query_params, headers=headers)

    def post_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='POST', data=data, query_params=query_params, headers=headers)

    def put_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='PUT', data=data, query_params=query_params, headers=headers)
    
    
    def get_titles(self, title_id):
        return self.get_api(f'/admin/titles/{title_id}')

    def get_title_from_titles(self, titles):        
        try:
            title = titles['shortTitle'] or ''
            if len(titles['shortTitle']) <= 0:
                return titles['tvSeason']['tvShow']['shortTitle'] or 'XXXTITLEXXX'
            else:
                return title
        except: 
            pass
        return ''
    
    def get_alphas(self, alpha_id):
        return self.get_api(f'/admin/alphas/{alpha_id}')
        
if __name__ == '__main__':

    log.info('### DEBUG ###')
    import json
    cdb = CoreDbWrapper()
    res = cdb.get_titles('PXTL-62424')
    log.info(json.dumps(res))
    log.info('### DONE ###')
