import requests, copy, os, time, json
from urllib.parse import urlencode

from .sso import getSSOToken
from .am import AMWrapper
from .vidispine import VidispineWrapper
from .boto3_wrapper import Boto3Wrapper

sec = {}
try:
    from ..secrets.service_setup import om_sso_client_id as client_id, om_sso_client_secret as client_secret, om_api_token, om_base_url as base_url
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    client_id = sec.get('sso_client_id') or os.getenv('SSO_CLIENT_ID') or ''
    client_secret = sec.get('sso_client_secret') or os.getenv('SSO_CLIENT_SECRET') or ''
    om_api_token = sec.get('om_api_token') or sec.get('x-api-token') or os.getenv('OM_API_TOKEN') or os.getenv('X-API-TOKEN') or ''
    base_url = sec.get('om_base_url') or os.getenv('OM_BASE_URL') or ''


from .logger import Logger
log = Logger('om')

default_options = {
    # https://phelix-api-v2.pixelogicmedia.com/apis/v1
    'base_url': base_url,
    
    'sso_opt': {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
    },
    'api-token': om_api_token

    # 'payload': {
    #     "service": "Orchestrator",
    #     "requestId": "",
    #     "asset": {
    #         "id": 0,
    #         "versionId": 0
    #     },
    #     "attachments": [

    #     ],
    #     "comment": {
    #         "body": "",
    #         "visibility": "pixelogic"
    #     }
    # }
}

class OMWrapper:
    def __init__(self, opts=None):
        self.options = copy.deepcopy(default_options)
        if opts: self.options.update(opts)
        self.__base_url = self.options['base_url']
        self.__access_token = ''
        self.__token_expiration = None
        self.__refresh_headers()
    
    def __refresh_headers(self):
        if not self.__access_token or time.time() > self.__token_expiration:
            token_data = getSSOToken(self.options['sso_opt'])
            self.__token_expiration = time.time() + token_data['expires_in'] - 10
            self.__access_token = token_data['access_token']

        return {
            'Authorization': 'Bearer ' + self.__access_token
        }
    
    def __api_url(self, path, query_params=''):
        if not path.startswith(self.__base_url):
            path = self.__base_url.strip('/') + '/' + path.lstrip('/')
        path = path.replace('/apis/v1/apis/v1/', '/apis/v1/')
        
        if type(query_params) == dict:
            query_params = urlencode({k:v for k,v in query_params.items() if v})
        query_params = '' if not query_params else f"?{query_params.strip('?')}"

        return path.lstrip('/') + query_params
    
    # general API call

    def call_api(self, url, method='GET', data=None, query_params=None, headers={}):
        log.debug(f"Calling OM API [{method}] {url} with data: {data} and query_params: {query_params}")
        if query_params or not url.startswith(self.__base_url):
            url = self.__api_url(url, query_params)
        headers.update(self.__refresh_headers())
        if type(data) in [dict, list] and (('Content-Type' not in headers) or (headers['Content-Type'].lower() == 'text/plain')):
            response = requests.request(method, self.__api_url(url), headers=headers, json=data)
        else:
            response = requests.request(method, self.__api_url(url), headers=headers, data=data)
        log.debug(f"OM API response: {response.status_code} / {response.content}")
        response.raise_for_status()
        try: return response.json()
        except: return response.content

    def get_api(self, url, query_params=None, headers={}):
        return self.call_api(url, query_params=query_params, headers=headers)

    def post_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='POST', data=data, query_params=query_params, headers=headers)

    def put_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='PUT', data=data, query_params=query_params, headers=headers)
    
    # SQS notification
    def sendOmSqs(self, request_id, queue_name, status_code, message='', extrainfo={}, responsedata={}, progress=0):
        if not queue_name:
            queue_name = 'operation-manager-v2-orchestrator-reporting-production'
        if status_code is None:
            status_code = 1  # failed
        
        payload = {
            "requestId": request_id,
            "statusCode": status_code,
            "message": message,
            "extrainfo": extrainfo,
            "responsedata": responsedata
        }

        if progress > 0:
            payload['progress'] = progress

        retries = 5
        retry_interval = 5

        err = ''
        while retries > 0:
            try:
                # Create SQS client
                sqs = Boto3Wrapper().get_client("sqs")
                queue_url = sqs.get_queue_url(QueueName=queue_name)['QueueUrl']
                response = sqs.send_message(
                    QueueUrl=queue_url,
                    MessageBody = json.dumps(payload)
                )
                print(response['MessageId'])
                return response
            except Exception as e:
                print(str(e))
                err = str(e)
                time.sleep(retry_interval)
                retries -= 1

        if retries > 0:
            print('notification sent to sqs queue: ' + queue_name)
        else:
            print('failed to send notification to sqs queue ' + queue_name)
            raise Exception('failed to send notification to sqs queue ' + queue_name + '; error: ' + err)
    
    def sendOmSqsProgress(self, request_id, queue_name, message='', extrainfo={}, responsedata={}, progress=5):
        if not request_id: return None
        try:
            # do not block processing if failed to send message
            return self.sendOmSqs(request_id, queue_name, 200, message, extrainfo, responsedata, progress)
        except:
            return None

    def sendOmSqsSuccess(self, request_id, queue_name, message='Success', extrainfo={}, responsedata={}):
        return self.sendOmSqs(request_id, queue_name, 0, message, extrainfo, responsedata, 100)

    def sendOmSqsFailed(self, request_id, queue_name, erro_message='OM task failed.', extrainfo={}, responsedata={}):
        return self.sendOmSqs(request_id, queue_name, 1, erro_message, extrainfo, responsedata)

    def getTaskInfo(self, task_id, subcommand=''):
        url = f'/tasks/{task_id}'
        if subcommand:
            url += '/' + subcommand
        return self.get_api(url)
        
    def taskInfo(self, task_id, subcommand='', payload={}):
        url = f'/tasks/{task_id}'
        if subcommand:
            url += '/' + subcommand
        return self.post_api(url, payload)
        
    def getJobInfo(self, job_id, subcommand=''):
        url = f'/jobs/{job_id}'
        if subcommand:
            url += '/' + subcommand
        return self.get_api(url)
    
    def jobInfo(self, job_id, subcommand='', payload={}):
        url = f'/jobs/{job_id}'
        if subcommand:
            url += '/' + subcommand
        return self.post_api(url, payload)
        
    def duplicateJob(self, payload):
        headers = {
            'X-API-TOKEN': self.options['api-token'],
            'Content-Type': 'text/plain'
        }
        return self.post_api(f'/lamda/duplicate-job', payload, headers=headers)

    def attach_report(self, request_id, asset_id, asset_version_id, qc_type_id, qc_status, qc_variant, qc_comment, s3_key_prefix='', filename=''):
        payload = {
            "service": "MediaTools",
            "requestId": request_id,
            "asset": {
                "id": asset_id,
                "versionId": asset_version_id
            },
            "qc": {
                "typeId": qc_type_id,
                "status": qc_status,  # PASSED, REVIEW, REJECTED
                "variant": qc_variant
            },
            "comment": qc_comment
        }
        if s3_key_prefix and filename:
            payload['attachment'] = {
                "s3Key": f"{s3_key_prefix}/{filename}",
                "filename": filename
            }
        return self.post_api('/external/services/assets/update-asset-version-qc', payload)
    
    def add_asset_version_comment(self, request_id, asset_id, asset_version_id, qc_comment, s3_key_prefix, filename):
        payload = {
            "service": "MediaTools",
            "requestId": request_id,
            "asset": {
                "id": asset_id,
                "versionId": asset_version_id
            },
            "attachments": [
                {
                "s3Key": f"{s3_key_prefix}/{filename}",
                "filename": filename
                }
            ],
            "comment": {
                "body": qc_comment,
                "visibility": "pixelogic"
            }
        }
        return self.post_api('/external/services/assets/add-asset-version-comment', payload)
        
    def get_asset_qc_attachments(self, assetId):
        return self.get_api(f'/assets/{assetId}/qc/attachments')
        
    def get_asset_details(self, om_id, om_version_id=''):
        url = f'/assets/{om_id}'
        if om_version_id:
            url += f'/versions/{om_version_id}'
        return self.get_api(url)

    def get_latest_version_id(self, om_id, version_name = None):
        query_params = {
            'assetVersionName': version_name
        } if version_name else {}
        return self.get_api(f'/external/services/assets/{om_id}/versions/first-unfulfilled', query_params=query_params)
        
    def get_asset_tags(self, om_version_id):
        return self.get_api(f'/asset-versions/{om_version_id}/asset-tag-definitions')
        
    def update_asset_tags(self, om_version_id, tags=[]):
        previous = [x['id'] for x in self.get_asset_tags(om_version_id)]
        tags = list(set(previous + tags))
        log.info(f"sending {json.dumps(tags)}")
        headers = {
            'X-API-TOKEN': self.options['api-token'],
            "Content-Type": "application/json"
        }
        payload = {
            "type": "SYSTEM",
            "assetTagIds": tags
        }
        return self.post_api(f'/asset-versions/{om_version_id}/update-asset-version-tag-definitions', payload, headers=headers)
        
    def fulfill(self, asset_path, asset_type, om_id, om_version_id = '', auto_version_up=True, return_version_id=False):
        log.info(f"Fulfill asset to am and om ... [{asset_path}/{asset_type}] -> [{om_id}/{om_version_id}]")
        om_details = self.get_asset_details(om_id, om_version_id)
        if auto_version_up or not om_version_id:
            latest_version = self.get_latest_version_id(om_id, om_details['versionName'])
            om_id = latest_version['assetId']
            om_version_id = latest_version['assetVersionId']
            log.info(f"Latest version  ... [{om_id}/{om_version_id}]")

        log.info(f"alpha/title ... {om_details['titleId']} / {om_details['alphaId']}")

        am = AMWrapper(self.options.get('am_options') or {})
        am_res = am.ingest(asset_path, asset_type)
        log.info(f'am_res ... {am_res}')
        import_job_ids = [job['jobId'] for job in ((am_res.get('ingestResponseDto') or {}).get('importJobs') or [])]        
        log.info(f'import_job_id ... {json.dumps(import_job_ids)}')
        am_id = ((am_res.get('ingestResponseDto') or {}).get('placeholderItems') or [{}])[0].get('itemId')
        log.info(f'am_id ... {am_id}')
        is_dcp = 'dcp' in str(asset_type)
        if (not am_id or is_dcp) and import_job_ids:
            # poll vidispine if not done
            vd = VidispineWrapper(self.options.get('vidispine_options') or {})
            for import_job_id in import_job_ids:
                vidis_res = vd.poll_vidispine(import_job_id)
                if not am_id:
                    am_id = vidis_res['data'][0]['value']
                
        res = am.fulfill(am_id, om_id, om_version_id, om_details['titleId'], om_details['alphaId'])
        log.info(f"Fulfill asset [{am_id}] succeeded.")
        if return_version_id:
            return am_id, om_version_id
        return am_id
    
    