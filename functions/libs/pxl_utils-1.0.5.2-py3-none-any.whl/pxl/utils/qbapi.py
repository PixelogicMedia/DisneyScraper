from __future__ import absolute_import

import requests, datetime, base64, os, html, json, time, random, urllib.parse, sys
import xml.etree.ElementTree as ET

app_name = 'qbapi'
version = '1.1.0'

try:
    # import from pxl specialized services
    from .logger import Logger
except:
    try:
        # import from pxl general services
        from apps.utils.logger import Logger
    except:
        try: 
            # import from pxl-utils libs
            from pxl.utils.logger import Logger
        except:
            try:
                # import from local path
                sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'utils'))
                from logger import Logger
            except:
                print('Cannot import pxl logging ...')

try: log = Logger(app_name)
except:
    print('Use system logging ...')
    import logging
    logging.basicConfig(
        level=logging.INFO,  # Set the log level to INFO
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',  # Define the log format
        handlers=[logging.StreamHandler(sys.stdout)]  # Output to console
    )
    log = logging.getLogger(app_name)



class qbapi:
    __udata = 'PXL_QB_API'
    __base_url = 'https://api.quickbase.com/v1'
    __update_url = __base_url + '/records'
    __query_url = __base_url + '/records/query'
    __files_url = __base_url + '/files'
    __reports_url = __base_url + '/reports'

    __base_url0 = 'https://radius60.quickbase.com'
    
    def __init__(self, tbl: str, utoken: str, atoken: str, host: str = 'radius60.quickbase.com'):
        self.tbl = tbl
        self.atoken = atoken
        self.utoken = utoken
        self.host = host
        self.headers = {
            'QB-Realm-Hostname': self.host,
            'QB-App-Token': atoken,
            'Authorization': 'QB-USER-TOKEN ' + utoken,
            'User-Agent': self.__udata,
        }
        log.info(self.headers)

    def delete(self, where: str):
        payload = {
            "from": self.tbl,
            'where': where
        }
        Retry = 5
        sleep = 5
        while (Retry > 0):
            try:
                res = requests.delete(self.__update_url, headers = self.headers, json = payload, timeout=(10,20))
                return res.json()
            except requests.exceptions.Timeout as rerr:
                Retry = Retry -1
                time.sleep(random.uniform(sleep, sleep + 1))
                if Retry == 0:
                    raise

    
    def query(self, select: list, where: str):
        top = 5000
        payload = {
            'from': self.tbl,
            'select': ['a'],
            'where': '',
            "options": {
                "skip": 0,
                "top": top
            }
        }
        if select:
            payload['select'] = select
            if '3' not in payload['select']:
                payload['select'].append('3')
        if where: payload['where'] = where
        log.info(self.__query_url)
        log.info(self.headers)
        log.info(payload)

        result = {'data': [], 'metadata': {}}
        Retry = 5
        sleep = 5
        while True:
            try:
                res = requests.post(self.__query_url, headers = self.headers, json = payload, timeout=(10,20))
            except requests.exceptions.Timeout as rerr:
                Retry = Retry -1
                time.sleep(random.uniform(sleep, sleep + 1))
                if Retry == 0:
                    raise
                continue

            res.raise_for_status()
            tmp = res.json()
            if not tmp.get('data'):
                log.info('No QB data ' + str(self.tbl) + ' -- ' + str(res.content))
                tmp['data'] = []
            result['data'] += tmp['data']
            result['metadata'].update(tmp['metadata'])
            if tmp['metadata']['numRecords'] < top:
                break
            payload['options']['skip'] += top
        log.info(result)
        return result

    def update_single(self, rid: str, data: dict, mergeFieldId: int = -1, fieldsToReturn: list = []):
        rid_fid = '3'
        if mergeFieldId >0: rid_fid = mergeFieldId
        item = {rid_fid: {'value': rid}}
        item.update(data)
        return self.update([item], mergeFieldId, fieldsToReturn)

    def update_multi(self, rids: list, data: dict, mergeFieldId: int = -1, fieldsToReturn: list = []):
        items = []
        rid_fid = '3'
        if mergeFieldId >0: rid_fid = mergeFieldId
        for rid in rids:
            item = {rid_fid: {'value': rid}}
            item.update(data)
            items.append(item)
        return self.update(items, mergeFieldId, fieldsToReturn)
    
    def update(self, data: list, mergeFieldId: int = -1, fieldsToReturn: list = []):
        chunk_size = 1000
        payload = {
            'to': self.tbl,
            #'data': data
        }
        if fieldsToReturn: payload['fieldsToReturn'] = fieldsToReturn
        if mergeFieldId>0: payload['mergeFieldId'] = mergeFieldId
        log.info(payload)
        result = {}

        Retry = 5
        sleep = 5


        for i in range(0, len(data), chunk_size):
            payload['data'] = data[i:i+chunk_size]
            res = None
            while True:
                try:
                    res = requests.post(self.__update_url, headers = self.headers, json = payload, timeout=(10,20))
                    break
                except requests.exceptions.Timeout as rerr:
                    Retry = Retry -1
                    time.sleep(random.uniform(sleep, sleep + 1))
                    if Retry == 0:
                        raise
                    continue
            log.info(str(res.content))
            result.update(res.json())
        return result

    def download(self, rid, fid, output: str):
        return self.__downloadurl(f'{self.__files_url}/{self.tbl}/{rid}/{fid}/0', output)

    def __downloadurl(self, url, output: str):
        if not output:
            raise Exception('invalid output.')
        log.info(url)

        Retry = 5
        sleep = 5
        res = None
        while True:
            try:
                res = requests.get(url, headers = self.headers, timeout=(10,20))
                break
            except requests.exceptions.Timeout as rerr:
                Retry = Retry -1
                time.sleep(random.uniform(sleep, sleep + 1))
                if Retry == 0:
                    raise
                continue

        output_file = output
        if res.status_code == 200:
            # assume output is folder when ending with /
            if output.endswith('/') and not os.path.isdir(output):
                try: os.makedirs(output, exist_ok=True)
                except: pass

            if os.path.isdir(output):
                if 'Content-Disposition' in res.headers:
                    d = res.headers['Content-Disposition']
                    fname = urllib.parse.unquote(d.split('filename', 1)[1].replace("*=utf-8''", "").strip('=').strip('"'))
                    output_file = os.path.join(output, fname)
                else:
                    output_file = os.path.join(output, f'downloadfile_{datetime.datetime.now().strftime("%Y%m%d%H%M%S")}.qb')
            else:
                # try to create parent folder if not exist
                try: os.makedirs(os.path.dirname(output_file), exist_ok=True)
                except: pass
            with open(output_file, 'wb') as f:
                f.write(base64.decodebytes(res.content))
            return output_file
        return ''

    def runreport(self, id: str):
        Retry = 5
        sleep = 5
        res = None
        while True:
            try:
                res = requests.post(f'{self.__reports_url}/{id}/run?tableId={self.tbl}', headers = self.headers, timeout=(10,20))
                break
            except requests.exceptions.Timeout as rerr:
                Retry = Retry -1
                time.sleep(random.uniform(sleep, sleep + 1))
                if Retry == 0:
                    raise
                continue
        log.info(str(res))
        return res.json()

    def delete_file(self, rid: str, fid: str, vid: str):
        Retry = 5
        sleep = 5
        res = None
        while True:
            try:
                res = requests.delete(f'{self.__files_url}/{self.tbl}/{rid}/{fid}/{vid}', headers = self.headers,timeout=(10,20))
                break
            except requests.exceptions.Timeout as rerr:
                Retry = Retry -1
                time.sleep(random.uniform(sleep, sleep + 1))
                if Retry == 0:
                    raise
                continue

        log.info(str(res))
        return res.json()

    def backup(self, output_file, options):
        date_from = str(options.get('date_from') or '')
        date_to = str(options.get('date_to') or '')
        id_from = str(options.get('id_from') or '')
        id_to = str(options.get('id_to') or '')
        
        where = []
        if id_from:
            where.append('{3.GTE.' + id_from + '}')
        if id_to:
            where.append('{3.LTE.' + id_to + '}')
        if date_from:
            where.append('{1.OAF.' + date_from + '}')
        if date_to:
            where.append('{1.OBF.' + date_to + '}')

        if not where:
            raise Exception('There is no condition for backup (date, id)')

        log.info(where)
        
        res = self.query([], 'AND'.join(where))
        res['backup_info'] = {'where':where, 'date':str(datetime.datetime.now())}
        with open(output_file, 'w') as f:
            json.dump(res,f)
        
        if options.get('include_attachment') == True:
            _files = os.path.splitext(output_file)[0] + '_files'
            log.info(f'downloading attachments to ... {_files}')
            try: os.makedirs(_files)
            except: pass
            for record in res['data']:
                for fid in record:
                    item = record[fid]
                    if item.get('value') and type(item['value']) is dict and item['value'].get('url') and item['value'].get('versions'):
                        rid = record['3']['value']
                        f = self.download(rid, fid, _files)
                        log.info('downloaded: ' + f)
        
        return output_file


    # XML
    def uploadXML(self, rid, fid_paths):
        headers = {
            'Content-Type': 'application/text+xml',
            'QUICKBASE-ACTION': 'API_UploadFile'
        }
        qdbapi = ET.fromstring(
            '<qdbapi><udata>Lorentz</udata><usertoken></usertoken><apptoken></apptoken><rid></rid></qdbapi>')
        qdbapi.find('udata').text = self.__udata
        qdbapi.find('usertoken').text = self.utoken
        qdbapi.find('apptoken').text = self.atoken
        qdbapi.find('rid').text = str(rid)
        for fid in fid_paths:
            el = ET.Element('field', {'fid': fid, 'filename': os.path.basename(fid_paths[fid])})
            el.text = base64.b64encode(open(fid_paths[fid], "rb").read()).decode('utf-8')
            qdbapi.append(el)

        Retry = 5
        sleep = 5
        res = None
        while True:
            try:
                res = requests.post(f'{self.__base_url0}/db/{self.tbl}', headers=headers, data=ET.tostring(qdbapi), timeout=(10,600))
                break
            except requests.exceptions.Timeout as rerr:
                Retry = Retry -1
                time.sleep(random.uniform(sleep, sleep + 1))
                if Retry == 0:
                    raise
                continue

        if res.status_code != 200:
            log.error('upload failed: ' + res.text)
            return ''

        qbxml = ET.fromstring(res.text)  # return qdbapi ele
        if qbxml.find('errcode').text != '0':
            log.error('upload failed: ' + qbxml.find('errtext').text)
            return ''
        log.info('uploaded: ' + res.text)
        return qbxml.find('file_fields/field/url').text

    def updateXML(self, rid, fids_vals: dict, fid_file=None):
        headers = {
            'Content-Type': 'application/text+xml',
            'QUICKBASE-ACTION': 'API_AddRecord'
        }
        qdbapi = ET.fromstring(
            '<qdbapi><udata>Lorentz</udata><usertoken></usertoken><apptoken></apptoken></qdbapi>')
        qdbapi.find('udata').text = self.__udata
        qdbapi.find('usertoken').text = self.utoken
        qdbapi.find('apptoken').text = self.atoken
        if rid:
            headers['QUICKBASE-ACTION'] = 'API_EditRecord'
            el = ET.Element('rid')
            el.text = str(rid)
            qdbapi.append(el)
        for fid in fids_vals:
            el = ET.Element('field', {'fid': fid})
            el.text = fids_vals[fid]
            qdbapi.append(el)
        if fid_file:
            if 'fid' not in fid_file:
                for fid in fid_file:
                    fp = fid_file[fid]
                    el = ET.Element('field', {'fid': fid, 'filename': os.path.basename(fp)})
                    with open(fp, "rb") as f:
                        el.text = base64.b64encode(f.read()).decode('utf-8')
                    qdbapi.append(el)
            else:
                el = ET.Element('field', {'fid': fid_file['fid'], 'filename': fid_file['filename']})
                el.text = fid_file['content']
                qdbapi.append(el)
        log.info(str(qdbapi))

        Retry = 5
        sleep = 5
        res = None
        while True:
            try:
                res = requests.post(f'{self.__base_url0}/db/{self.tbl}', headers=headers, data=ET.tostring(qdbapi), timeout=(10, 600))
                break
            except requests.exceptions.Timeout as rerr:
                Retry = Retry -1
                time.sleep(random.uniform(sleep, sleep + 1))
                if Retry == 0:
                    raise
                continue

        if res.status_code != 200:
            log.error('add/update failed: ' + res.text)
            return ''

        qbxml = ET.fromstring(res.text)  # return qdbapi ele
        if qbxml.find('errcode').text != '0':
            log.error('add/update failed: ' + qbxml.find('errtext').text)
            return ''
        log.info('added/updated: ' + res.text)
        return qbxml.find('rid').text

    ### static ###
    @staticmethod
    def v2_to_v1_result(data: list):
        records = {}
        for item in data:
            rec = {}
            for fid in item:
                value = item[fid]['value']
                if type(value) in [str, int, float]:
                    rec[fid] = str(value)
                elif type(value) == list:
                    rec[fid] = ';'.join(value)
                elif type(value) == dict:
                    for type in ['url', 'email']:
                        if type in value:
                            rec[fid] = value[type]
                            break
            records[str(item['3']['value'])] = rec
        return records
    
    @staticmethod
    def v1_to_v2_update_data(items):
        v2_items = []
        for item in items:
            v2_item = {}
            for fid in item:
                val = item[fid]
                v2_item[fid] = {
                    'value': val
                }
            v2_items.append(v2_item)
        return v2_items

    @staticmethod
    def qb_richtext(s):
        return s.encode('ascii', 'xmlcharrefreplace').decode()

    @staticmethod
    def qb_richtext_decode(s):
        return html.unescape(s)


def parse_json_args(args):
    try:
        if type(args) is str:
            return json.loads(args)
        return args
    except Exception as err:
        log.error(f'Cannot parse json args {args}')
        log.exception(err)
    return {}

def __base64decode(base64_message, encoding='ascii'):
    binary_content = base64_message if isinstance(base64_message, bytes) else str(base64_message).encode(encoding)
    return base64.b64decode(binary_content).decode(encoding, errors='replace')

def parse_b64_args(args):
    try:
        return parse_json_args(__base64decode(args))
    except Exception as err:
        log.error(f'Cannot parse b64 json args {args}')
        log.exception(err)
    return {}
    
if __name__ == '__main__':
    log.info(f"{app_name} v{version} ...")
    
    import argparse

    parser = argparse.ArgumentParser(description=app_name)
    parser.add_argument('--debug', '-d', action='store_true', default=False, help='Debug flag')
    parser.add_argument('--base64', type=parse_b64_args, default={}, help='base64 encoded payload')
    parser.add_argument('--payload', type=parse_json_args, default={}, help='json string payload')

    parser.add_argument('--table', type=str, default='', help='qb table')
    parser.add_argument('--utoken', type=str, default='', help='qb utoken')
    parser.add_argument('--atoken', type=str, default='', help='qb atoken')
    parser.add_argument('--host', type=str, default='radius60.quickbase.com', help='qb host')
    
    parser.add_argument('--function', '-f', default='', help='function to run')
    parser.add_argument('--kwargs', '-k', type=parse_json_args, default={}, help='function kwargs')
    
    args = parser.parse_args()
    opts = vars(args)
    opts.update(opts.get('base64') or {})
    opts.update(opts.get('payload') or {})
    log.info(f"opts: {opts}")
    DEBUG = opts.get('debug') or False
    log.info(f"Debug mode: {DEBUG}")

    function = opts.get('function')
    if not hasattr(qbapi, function):
        raise AttributeError(f"Function [{function}] not found")
    
    tbl = opts.get('table')
    utoken = opts.get('utoken')
    atoken = opts.get('atoken')
    host = opts.get('host')
    if not tbl or not utoken or not atoken:
        raise Exception("Invalid QB parameters")
    
    qb = qbapi(tbl, utoken, atoken, host)
    func = getattr(qb, function)
    res = func(**opts.get('kwargs'))
    
    log.info(f"<OUTPUT>{json.dumps(res)}</OUTPUT>")

        



### end qbapi ###
