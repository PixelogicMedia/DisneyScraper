from __future__ import absolute_import
import csv, os, json

def __getlangcodes():
    langcodes = {}
    with open(os.path.dirname(os.path.realpath(__file__)) + '/langcodes.json', 'r') as f:
       langcodes = json.load(f)
    return langcodes

def convert(code, output_type='alpha3b'):
    if not code:
        return ''
    langcodes = __getlangcodes()
    for lang in langcodes:
        for t in lang:
            if lang[t] and lang[t] == code:
                return lang[output_type]
    return code

def to_alpha2(code):
    return convert(code, 'alpha2')

def to_alpha3b(code):
    return convert(code, 'alpha3-b')

def to_alpha3t(code):
    return convert(code, 'alpha3-t')

def to_EnglishName(code):
    return convert(code, 'English')

def to_FrenchName(code):
    return convert(code, 'French')
