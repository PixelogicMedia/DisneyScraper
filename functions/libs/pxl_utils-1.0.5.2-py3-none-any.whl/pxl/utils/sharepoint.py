from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.user_credential import UserCredential

sec={}
try:
    from ..secrets.service_setup import o365_host, o365_username, o365_password
except:
    try:
        import os
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    o365_host = sec.get('o365_host') or os.getenv('O365_HOST') or ''
    o365_username = sec.get('o365_username') or os.getenv('O365_USERNAME') or ''
    o365_password = sec.get('o365_password') or os.getenv('O365_PASSWORD') or ''
    
class SharepointTransfer:
    def __init__(self, username='', password='', host = ''):
        self.__host = host or o365_host or 'https://o365pixelogicmedia.sharepoint.com'
        self.__username = username or o365_username
        self.__password = password or o365_password
        self.__size_chunk = 10*1024*1024

    def uploadFiles(self, local_paths, site_name, destination_folder):
        return [self.uploadFile(local_path, site_name, destination_folder) for local_path in local_paths]
        
    def uploadFile(self, local_path, site_name, destination_folder):
        team_site = f'{self.__host}/sites/{site_name}'
        ctx = ClientContext(team_site).with_credentials(UserCredential(self.__username, self.__password))

        target_url = f"/sites/{site_name}/{destination_folder}"
        target_folder = ctx.web.get_folder_by_server_relative_url(target_url)
        
        uploaded_file = target_folder.files.create_upload_session(local_path, self.__size_chunk).execute_query()
        return self.__host + uploaded_file.serverRelativeUrl

