import argparse, json, sys
from redis import Redis, ConnectionPool

truthy = [True, 'true', 1, '1']

class RedisLock:
    def __init__(self, lock_id, lock_prefix = 'redis_lock', host='localhost', port=6378, db=15) -> None:
        if not lock_id:
            raise Exception('No lock_id provided.')
        self.__lock_prefix = lock_prefix
        self.__lock_id = f'{lock_prefix}_{lock_id}'

        pool = ConnectionPool(host=host, port=port, db=db)
        self.__redis_client = Redis(connection_pool=pool)

    def get_lock(self):
        return self.__redis_client.get(self.__lock_id)

    def list_locks(self):
        lock_pattern = f'{self.__lock_prefix}_*' if self.__lock_prefix else '*'
        return self.__redis_client.keys(lock_pattern)
    
    def set_lock(self):
        return self.__redis_client.set(self.__lock_id, 1)

    def remove_lock(self):
        try:
            return self.__redis_client.delete(self.__lock_id)
        except Exception as err:
            print('remove_lock', self.__lock_id, err)

    def is_lock(self, set_lock = False) -> bool:
        try:
            result = self.__redis_client.get(self.__lock_id) != None
            if not result and set_lock in truthy:
                print('set_lock', self.__lock_id)
                self.__redis_client.set(self.__lock_id, 1)
            print('is_lock', result, self.__lock_id)
            return result
        except Exception as err:
            print('is_lock', self.__lock_id, err)
        
        return False

    def clear_lock_by_pattern(self, lock_pattern):
        try:
            locks = { lock_id: self.__redis_client.delete(lock_id) for lock_id in self.__redis_client.scan_iter(f"{self.__lock_prefix}*{lock_pattern}*") }
            print('clearing ...', locks)
        except Exception as err:
            print('clear_lock_by_pattern', lock_pattern, err)

if __name__ == '__main__':
    # sample command to remove lock manually:
    # <lock_id> is depend on service. Usually "<service_name>_<om_task_id>". Ex: ndtvtranscode_service_123456
    # <redis db number> -> where is the lock stored. Usually it is service db number. Ex: --db 3 for ndtv
    # python3 /mnt/localization/Tools/celery/pxl_services_specialized/apps/utils/redis_lock.py -c remove_lock -l <lock_id> --db <redis db number>
    # python3 /mnt/localization/Tools/celery/pxl_services_specialized/apps/utils/redis_lock.py -c remove_lock -l ndtvtranscode_service_123456 --db 3

    # get all locks (default prefix `redis_lock`):
    # python3 /mnt/localization/Tools/celery/pxl_services_specialized/apps/utils/redis_lock.py -c list_locks -l tmp

    parser = argparse.ArgumentParser(description='Redis lock tool.')
    parser.add_argument('--command', '-c', default='', type=str, help='lock command')
    parser.add_argument('--lock_id', '-l', default='', type=str, help='lock id')
    parser.add_argument('--lock_prefix', default='redis_lock', type=str, help='lock prefix')
    parser.add_argument('--args', '-a', default=[], nargs='+', type=str, help='command args')
    parser.add_argument('--debug', '-d', default=False, help='Debug mode')
    parser.add_argument('--host', default='localhost', type=str, help='Redis host')
    parser.add_argument('--port', default=6378, type=int, help='Redis port')
    parser.add_argument('--db', default=15, type=int, help='Redis DB number')

    args = parser.parse_args()
    
    print(vars(args))

    r = RedisLock(args.lock_id)

    result = getattr(r, args.command)(*args.args)
    print(result)

    
