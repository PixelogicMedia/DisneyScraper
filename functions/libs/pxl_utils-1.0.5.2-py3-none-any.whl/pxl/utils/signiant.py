# -*- coding: utf-8 -*-
import os

from .logger import Logger
# from .misc import path_detection, get_exist_path_detection
from .qm import QueueManager

sec = {}
try:
    from ..secrets.service_setup import signiant_username as username, signiant_password as password, signiant_host as host
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    
    username = sec.get('signiant_username') or os.getenv('SIGNIANT_USERNAME') or ''
    password = sec.get('signiant_password') or os.getenv('SIGNIANT_PASSWORD') or ''
    host = sec.get('signiant_host') or os.getenv('SIGNIANT_HOST') or ''

import requests
import copy, os, time, datetime


DEBUG = False


log = Logger('signiant')


class Signiant:
    options = {
        'url': host + '/signiant/spring/admin/v1.0/jobs',
        'headers': {
            'username': username,
            'password': password
        },

        'path_adjustment': {
            '/localization/': '/Localization/',
            '/PXL-QFS00/': '/pxl-qfs00/',
            '/PXL-QFS01/': '/pxl-qfs01/',
            '/PXL-QFS02/': '/pxl-qfs02/',
            '/pxl-vault02/': '/pxl-vault2/',            
            '/mnt/PXL-MPFS01/': '/mmfs1/data/PXL-MPFS01/',            
        },

        'agents': {
            'dmz': 'pxl-sigrlyagt01.pixelogicmedia.com',
            'prod' :'pxl-sigtfragt03.pixelogicmedia.com',
            'prod-london' : 'lon-p-sigag01.prod.pixelogicmedia.com',
            'prod-motor' : 'mot-sigtfragt001.pixelogicmedia.com',
            'prod-cairo' : 'cai-p-sigag01.pixelogicmedia.com' 
        },

        # payload = [{"job": {}}]
        'temp_job': {
            #"jobName": "",
            "fields": {
                "jobGroupName": "MediaDistributor",
                "jobTemplateLibraryName": "Media_Mover_Workflows",
                "jobTemplateName": "MediaDistributor",
                "jobArgs": {
                    #"MediaDistributor.Source.SourceAgent": "",
                    #"MediaDistributor.Source.SourceData": "",
                    "MediaDistributor.Source.skipSourceFileNotFoundOnSend": "yes",
                    "MediaDistributor.Source.skipTopLevelFolders": "no",
                    #"MediaDistributor.Target.TargetAgents": "",
                    #"MediaDistributor.Target.TargetDirectory": "",
                    "MediaDistributor.Schedule._sp_frequency": "once",
                    "MediaDistributor.Options.verifyifsourcedirectoryexists": "yes",
                    "MediaDistributor.Options.followSymbolicLinks": "yes"
                }
            }
        },

    }

    def __init__(self, opts = {}):
        self.options.update(opts)

    def __fixPath(self, p):
        for term in self.options['path_adjustment']:
            p = p.replace(term, self.options['path_adjustment'][term])
        return p

    '''
    job = {'files': [], 'folders': [], 'destination': ''}
    '''
    def transfer(self, job):
        submit_job = copy.deepcopy(self.options['temp_job'])
        submit_job['jobName'] = submit_job.get('jobName', f'CeleryUpload_{datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")}')
        if not job.get('destination'):
            raise Exception('No destination folder', job)

        destination_di = QueueManager().path_detection(job['destination'])
        if len(destination_di)<1:
            raise Exception('cannot detect destination path', job)

        location = QueueManager().path_detection(job['destination'])[0]['location']

        targetagent = self.options['agents']['prod']
        if location == 'cairo':
            targetagent = self.options['agents']['prod-cairo']
        elif location == 'london':
            targetagent = self.options['agents']['prod-london']
        elif location == 'motor':
            targetagent = self.options['agents']['prod-motor']
        elif location == 'dmz':
            targetagent = self.options['agents']['dmz']

        sourceagent = self.options['agents']['prod']
        if job.get('files') and len(job['files']) > 0:
            location = QueueManager().get_exist_path_detection(job['files'][0])['location']
        else:
            location = QueueManager().get_exist_path_detection(job['folders'][0])['location']

        if location == 'cairo':
            sourceagent = self.options['agents']['prod-cairo']
        elif location == 'london':
            sourceagent = self.options['agents']['prod-london']
        elif location == 'motor':
            sourceagent = self.options['agents']['prod-motor']
        elif location == 'dmz':
            sourceagent = self.options['agents']['dmz']

        submit_job['fields']['jobArgs']['MediaDistributor.Source.SourceAgent'] = sourceagent
        submit_job['fields']['jobArgs']['MediaDistributor.Target.TargetAgents'] = targetagent

        submit_job['fields']['jobArgs']['MediaDistributor.Target.TargetDirectory'] = self.__fixPath(destination_di[0]['mnt_full'])

        sourceData = []
        for fp in job.get('files', []):
            _fp = self.__fixPath(QueueManager().get_exist_path_detection(fp)['mnt_full'])
            sourceData.append( f'<el v="{_fp}" t="f"></el>' )
        for fp in job.get('folders', []):
            _fp = self.__fixPath(QueueManager().get_exist_path_detection(fp)['mnt_full'])
            sourceData.append( f'<el v="{_fp}" t="d"></el>' )
        sourceDataStr = '<siglist type="filedir">' + ''.join(sourceData) + '</siglist>'
        submit_job['fields']['jobArgs']['MediaDistributor.Source.SourceData'] = sourceDataStr.replace('<', '\u003c').replace('>', '\u003e')


        # submit
        log.info(submit_job)
        submit_res = requests.post(self.options['url'], json=[{'job': submit_job}], headers=self.options['headers'], verify=False)
        #submit_res.raise_for_status()
        job['submit'] = submit_res.json()
        log.info(job['submit'])
        job_id = job['submit']['jobs'][0]['id']

        # check
        timeout = time.time() + (self.options.get('timeout') or 3600*5)
        while timeout > time.time():
            try:
                check_res = requests.get(self.options['url'] + f'/{job_id}', headers=self.options['headers'], verify=False, timeout=(5,10))
                check_res.raise_for_status()
                job['check'] = check_res.json()
            except requests.exceptions.Timeout as rerr:
                continue
            except:
                raise
            scheduledState = job['check'][0]['job']['fields']['scheduledState']
            activeState = job['check'][0]['job']['fields']['activeState']
            lastExitCode = job['check'][0]['job']['fields']['lastExitCode']
            if 'DORMANT' in scheduledState and 'IDLE' in activeState: 
                if lastExitCode == 0:
                    break
                elif lastExitCode != -1:
                    raise Exception('Signiant job failed. _Code:', lastExitCode, job['check'][0]['job']['fields']['lastActiveStatusMessage'])            
            time.sleep(30)
            
        if lastExitCode != 0:
            raise Exception('Signiant job failed. __Code:', lastExitCode, job['check'][0]['job']['fields']['lastActiveStatusMessage'])

        return job


### end ###
'''


submit post https://pxl-sigmgr01.pixelogicmedia.com/signiant/spring/admin/v1.0/jobs
app/json
username
password
payload
[{"job":{"jobName":"ClientUpload_6680_00f82a3f053848e4a264e42d65eed1bc","fields":{"jobGroupName":"MediaDistributor","jobTemplateLibraryName":"Media_Mover_Workflows","jobTemplateName":"MediaDistributor","jobArgs":{"MediaDistributor.Source.SourceAgent":"pxl-sigtfragt01.pixelogicmedia.com","MediaDistributor.Source.SourceData":"\u003csiglist type=\"filedir\"\u003e\u003cel v=\"/mnt/pxl-qfs01/Disney+/Video_Hub/DL_Videos/Premise_The/S01/Episodes/F003/03_Dub_Refs/Final/PremiseThe_103_2398_Final_Caaliope_LAS_210927.mov\" t=\"f\"\u003e\u003c/el\u003e\u003c/siglist\u003e","MediaDistributor.Source.skipSourceFileNotFoundOnSend":"yes","MediaDistributor.Source.skipTopLevelFolders":"yes","MediaDistributor.Target.TargetAgents":"pxl-sigrlyagt01.pixelogicmedia.com","MediaDistributor.Target.TargetDirectory":"/mnt/pxl-vault2/Aspera/_Client_Faspex_Staging/6680/00f82a3f-0538-48e4-a264-e42d65eed1bc","MediaDistributor.Schedule._sp_frequency":"once","MediaDistributor.Options.verifyifsourcedirectoryexists":"yes","MediaDistributor.Options.followSymbolicLinks":"yes"}}}}]

submit_res
{"creator":"pxl-orchestrator","jobs":[{"id":59882483,"jobName":"ClientUpload_6680_00f82a3f053848e4a264e42d65eed1bc"}]}


check_res get https://pxl-sigmgr01.pixelogicmedia.com/signiant/spring/admin/v1.0/jobs/<%=jobID%>
username
password
[{"job":{"id":59882483,"jobName":"ClientUpload_6680_00f82a3f053848e4a264e42d65eed1bc","fields":{"jobGroupName":"MediaDistributor","jobTemplateLibraryName":"Media_Mover_Workflows","jobTemplateName":"MediaDistributor","createdBy":"pxl-orchestrator","createdOn":"2021-10-01T13:20:44","activeState":"IDLE","scheduledState":"DORMANT","percentComplete":"100%","totalRuns":1,"lastExitCode":0,"lastActiveStatusMessage":"","activeFilename":"","timeZone":"America/Los_Angeles","jobArgs":{"MediaDistributor.Source.skipTopLevelFolders":"yes","MediaDistributor.Source.skipSourceFileNotFoundOnSend":"yes","MediaDistributor.Options.IncrementalTransfer":"no","MediaDistributor.Transport.BandwidthThrottleByTimeOfDay":"00:00;00:00;YYYYYYY;0;","MediaDistributor.Options._sp_encryption":"off","MediaDistributor.sNMPProperties.sNMPTrapCommunityString":"","MediaDistributor.Source.sourceDeletionsAfterSuccessfulTransfer":"none","MediaDistributor.Source.headerCheckDelay":"","MediaDistributor.Source.sourceFileDate":"","MediaDistributor.Options.verifyifsourcedirectoryexists":"yes","MediaDistributor.Target.removeExpiredDirectoriesonTarget":"no","MediaDistributor.Source.ExcludeSubdirectories":"None","MediaDistributor.Target.maximumJobDateTimeDirectories":"10","MediaDistributor.NotificationAndLogging.EmailCondition":"Never","MediaDistributor.Transport.wANAcceleratorAggressiveness":"medium","MediaDistributor.Options.followSymbolicLinks":"yes","MediaDistributor.sNMPProperties.sNMPTrapTypes":"","MediaDistributor.Transport._sp_udp":"no","MediaDistributor.Target.RemoveTargetFiles":"no","MediaDistributor.Options.deliveryMode":"unsigned","MediaDistributor.Source.SourceData":"<siglist type=\"filedir\"><el v=\"/mnt/pxl-qfs01/Disney+/Video_Hub/DL_Videos/Premise_The/S01/Episodes/F003/03_Dub_Refs/Final/PremiseThe_103_2398_Final_Caaliope_LAS_210927.mov\" t=\"f\"></el></siglist>","MediaDistributor.Options.verifyforsufficientdiskspacebeforeJobtransfersstart":"no","MediaDistributor.Source.SourceAgent":"pxl-sigtfragt01.pixelogicmedia.com","MediaDistributor.Source.filenamescontainingunsafeWindowscharacters":"ignore","MediaDistributor.Source.ExcludeSubDirList":"","MediaDistributor.Schedule._sp_start_at":"","MediaDistributor.Options.transientFileNamingMode":"default","MediaDistributor.Source.IncludeFiles":"*","MediaDistributor.Options.verifytargetdirectoryexists":"no","MediaDistributor.Options.respectTransferCheckTypeWhenStreamingGrowingFiles":"no","MediaDistributor.NotificationAndLogging._sp_log_severity":"Info","MediaDistributor.NotificationAndLogging.EmailBcc":"","MediaDistributor.Source.FileReadinessCheckDelay":"10","MediaDistributor.Schedule.timezone":"","MediaDistributor.Source.sourceDataLocationAfterSuccessfulTransfer":"","MediaDistributor.NotificationAndLogging.numberofconsecutivefailures":"1","MediaDistributor.Options.transferTemporaryFiles":"no","MediaDistributor.Target.PathMappingOptions":"","MediaDistributor.Target.TargetDirectory":"/mnt/pxl-vault2/Aspera/_Client_Faspex_Staging/6680/00f82a3f-0538-48e4-a264-e42d65eed1bc","MediaDistributor.Source.FileReadinessCheckType":"None","MediaDistributor.Schedule._sp_frequency":"once","MediaDistributor.Options.transferCheckType":"timesize","MediaDistributor.Transport.UseWANAccelerator":"yes","MediaDistributor.Schedule.finishBefore":"","MediaDistributor.Target.expirationPeriod":"30","MediaDistributor.NotificationAndLogging.emailJobFailureReportTo":"","MediaDistributor.NotificationAndLogging.EmailTo":"","MediaDistributor.Source.skipFilesWith0BytesSize":"no","MediaDistributor.sNMPProperties.sNMPTrapReceivers":"","MediaDistributor.Transport.BandwidthFloor":"0","MediaDistributor.Source.ExcludeFiles":"","MediaDistributor.NotificationAndLogging.EmailCc":"","MediaDistributor.Target.flattenDirectoryStructure":"no","MediaDistributor.Source.sourceDirectoriestoExcludefromDeletionScan":"","MediaDistributor.Schedule._sp_interrupt_on_failure":"no","MediaDistributor.Transport.BandwidthCeiling":"0","MediaDistributor.Options.CompressFiles":"no","MediaDistributor.Target.TargetAgents":"pxl-sigrlyagt01.pixelogicmedia.com","MediaDistributor.Schedule.priority":"Medium","MediaDistributor.Transport.simultaneousTransferStreams":"1","MediaDistributor.Source.headerRewriteSize":"","notes":null}}}}]
'''
