from __future__ import absolute_import

import json, os, shutil, uuid, subprocess, datetime, time

def is_file_being_copied_to(path):
    if not os.path.exists(path):
        return False
    st1 = os.stat(path)
    time.sleep(5) # check again after 5 sec
    st2 = os.stat(path)
    if st1.st_mode == st2.st_mode and st1.st_ino == st2.st_ino and st1.st_dev == st2.st_dev and st1.st_nlink == st2.st_nlink \
        and st1.st_size == st2.st_size and st1.st_mtime == st2.st_mtime and st1.st_ctime == st2.st_ctime:
        return False
    return True

def is_file_stale(source, target):
    if not os.path.exists(target):
        return True
    if not os.path.exists(source):
        return False
    st1 = os.stat(source)
    st2 = os.stat(target)
#    _now = datetime.datetime.now()
    target_mtime = st2.st_mtime
    if st1.st_size != st2.st_size or \
        time.mktime(datetime.datetime.now().timetuple()) - target_mtime > 3600 * 5: # files copied over 5 hours ago
        return True
    return False


def map_uri(path, extra_mappings=None, ignoreError=False):
    path=path.strip('"').strip("'").strip('"').strip("'")
    if os.path.exists(path):
        return path

    mapping = {}
    with open(os.path.dirname(os.path.realpath(__file__)) + '/uri_mapping.json', 'r') as f:
       mapping = json.load(f)
    if 'exceptions' in mapping:
        for k in mapping['exceptions']:
            if path.startswith(k):
                path = mapping['exceptions'][k] + path[len(k):]
                break
    path = path.replace('\\', '/') # convert windows slash
    if extra_mappings:
        mapping['mappings']+=extra_mappings
    print(mapping)
    for entry in mapping['mappings']:
        print(entry['mount'])
        if path.startswith(entry['mount']):
            return path
        for value in entry['source']:
            print(value)
            if path.startswith(value):
                result = path.replace(value, entry['mount'])
                print(path + ' replaced with ' + result)

                if entry['remote']:
                    print('remote storage found.')
                    if not os.path.exists(result):
                        raise ValueError('source not found: ' + result)

                    new_dir = mapping['caching_path']
                    new_file = new_dir + '/' + os.path.basename(result)
                    if os.path.exists(new_file):
                        print('cache file exist: ' + new_file)
                        if is_file_being_copied_to(new_file):
                            print('file is being opened for write: ' + new_file)
                            count = 30 # 30 minutes timeout
                            while count > 0 and is_file_being_copied_to(new_file):
                                time.sleep(60)
                                count -= 1

                            if is_file_being_copied_to(new_file):
                                print('still locked after timeout. creating a new file in cache')
                                _splitext = os.path.splitext(os.path.basename(result))
                                if len(_splitext) < 2:
                                    raise ValueError('Invalid input file: ' + value)
                                new_file = new_dir + '/' + _splitext[0] + uuid.uuid4().hex + _splitext[1]
                        if is_file_stale(result, new_file):
                            print('file is stale: ' + new_file + ' - deleting...')
                            os.remove(new_file)
                        else:
                            print('cache file is good to use.')

                    if not os.path.exists(new_file):
                        print('copying ' + result + ' to ' + new_file)
                        subprocess.call(['cp', result, new_file])
                        #shutil.copyfile(result, new_file, follow_symlinks = True)
                    result = new_file
                print('source url: ' + result)
                return result
    if ignoreError:
        return path
    raise ValueError('invalid source path: ' + path)


def is_path(s):
    s1 = s.lstrip('"').lstrip("'").lstrip('"')
    if s1.startswith('/') or s1.startswith('\\\\'):
        return True
    if len(s1)>2 and s1[0].isalpha() and s1[1] == ':' and (s1[2] == '\\' or s1[2] == '/'):
        return True
    return False

