from __future__ import absolute_import
import base64, json, secrets, string, copy, socket, os, subprocess, uuid, requests, time, zipfile


truthy = [True, 'true', 1, '1', 't', 'y', 'yes']

def parseOptions(*args, default_options={}, loc_options={}):
    options = copy.deepcopy(default_options)
    for arg in args:
        if type(arg) is dict:
            options.update(arg)
        elif type(arg) is str:
            try:
                options.update(json.loads(base64decode(arg)))
            except:
                if '=' in arg:
                    kvp = arg.split('=')
                    options[kvp[0]] = kvp[1]
        else:
            print('Invalid arg: ' + str(arg))
    
    options.update(location_options(loc_options))
    return options

def parseOutput(output):
    result = str(output)
    try: result = output.decode('utf-8', errors='replace')
    except:
        try: result = output.decode('ascii', errors='replace')
        except: pass
    return result

def parseErr(err, hidden = []):
    ret = str(err)
    for h in hidden:
        ret = ret.replace(str(h),'***')
    return ret


def generatePassphrase():
    alphabet = string.ascii_letters + string.digits
    pw = ''.join(secrets.choice(alphabet) for i in range(16))
    return pw

def base64encode(message, encoding='ascii'):
    binary_content = message if isinstance(message, bytes) else str(message).encode(encoding)
    return base64.b64encode(binary_content).decode(encoding, errors='replace')

def base64decode(base64_message, encoding='ascii', return_bytes=False):
    binary_content = base64_message if isinstance(base64_message, bytes) else str(base64_message).encode(encoding)
    if return_bytes:
        return base64.b64decode(binary_content)
    return base64.b64decode(binary_content).decode(encoding, errors='replace')

def isbase64(s, encoding='ascii'):
    try:
        if isinstance(s, str):
            s_bytes = s.encode(encoding)
        elif isinstance(s, bytes):
            s_bytes = s
        else:
            return False
        return base64.b64encode(base64.b64decode(s_bytes)) == s_bytes
    except Exception:
        return False

def isUUID(id, version=4):
    try:
        uuid.UUID(id, version = version)
        return True
    except:
        print('Not valid:' + id)
    return False


def fixEmailsStr(emails, separator=','):
    return separator.join(fixEmailsArr(emails))

def fixEmailsArr(emails):
    if type(emails) is list:
        emails = ' '.join(emails)
    for c in ['"', "'"]:
        emails = emails.replace(c, '')
    for c in [',', ';', '|']:
        emails = emails.replace(c, ' ')
    return emails.split()

def getHostNameIP(): 
    try: 
        host_name = socket.gethostname() 
        host_ip = socket.gethostbyname(host_name) 
        print(f'{host_name} - {host_ip}')
        return host_name, host_ip
    except Exception as err: 
        print(err)
    return None, None

def cmd_check_output(cmd, cmd_env={}):
    try:
        output=subprocess.check_output(cmd, shell=type(cmd) == str, stderr=subprocess.STDOUT, env=cmd_env)
        return parseOutput(output)
    except subprocess.CalledProcessError as perr:
        print(perr)
        raise Exception(str(perr), perr.stdout, perr.stderr)
    except Exception as err:
        print(err)
        raise err


def location_options(loc_options):
    if not location_options: return {}
    try:
        _, hostip = getHostNameIP()
        for ip_prefix in loc_options:
            if hostip.startswith(ip_prefix):
                print(loc_options[ip_prefix])
                return loc_options[ip_prefix]
    except: pass
    return {}

# 
def path_detection(path: str, options = {}, base_url = 'http://celery-burbank1.pixelogicmedia.com:5560'):
    """
    Deprecated: Use QueueManager.path_detection instead
    """
    if not path:
        raise Exception('Empty path')
    
    if path.startswith('s3://'):
        from .s3_wrapper import S3Wrapper
        return S3Wrapper().path_detection(path, options)
    
    payload = {'path': path}
    payload.update(options)
    try:
        res = requests.get(base_url.rstrip('/')+'/detectpath', params=payload)
        res.raise_for_status()
    except requests.exceptions.RequestException as err:
        # try local
        try:
            print('Try local path detection')
            from .path_detection import PathDetection
            options['location'] = 'local'
            return PathDetection(path, {}, **options).DetectionResult()
        except Exception as err1:
            raise Exception(f'Path detection failed:\r\n{err}\r\n{err1}')
    return res.json()

def get_exist_path_detection(path: str, options = {}, base_url = 'http://celery-burbank1.pixelogicmedia.com:5560', number_of_retries = 3, select_first = False):
    """
    Deprecated: Use QueueManager.get_exist_path_detection instead
    """
    options['check_exist'] = True
    
    counter = 0
    loopcount = number_of_retries + 1
    err = []

    for i in range(loopcount):
        pinfos = path_detection(path, options, base_url)
        exist_paths = [p for p in pinfos if p.get('exist') == True]
        if len(exist_paths) == 1:
            return exist_paths[0]
        if len(exist_paths) > 1:
            mult = list(set([p['location'] for p in pinfos]))
            if len(mult) == 1 or (len(mult) > 1 and select_first):
                return exist_paths[0]
            raise Exception('Path exists on multiple location. Please choose proper location. ', mult)
        time.sleep(15)
        counter = counter + 1
        if counter >= loopcount:
            not_exist = [p for p in pinfos if p.get('exist') == False]
            if len(not_exist)>0:        
                err += ['Path not found.', path, [p['location'] for p in not_exist]]
            not_detect = [p for p in pinfos if p.get('exist') == None]
            if len(not_detect)>0:
                err += ['Cannot detect path. Please retry.', path, [p['location'] for p in not_detect]]    

    if err:
        raise Exception(err)
    
    raise Exception('Unknown error. Please retry, path is potentially not correctly formatted.', path)

def compress_files(files, zip_path = None):
    if not files:
        raise Exception('No files to compress')
    
    if not zip_path:
        zip_path = os.path.dirname(files[0]) + '.zip'

    with zipfile.ZipFile(zip_path, 'w') as zipf:
        for file in files:
            zipf.write(file)
    return zip_path

def compress_folder(folder_path, zip_path = None):
    if not zip_path:
        zip_path = folder_path + '.zip'
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, folder_path))
    return zip_path

def run_command(cmd, kwargs={}):
    try:
        cwd = kwargs.pop('cwd') if 'cwd' in kwargs else None
        env = kwargs.pop('env') if 'env' in kwargs else kwargs
        cur_env = dict(os.environ)
        cur_env.update(env)
        if len(cmd) == 1:
            output = subprocess.check_output(cmd[0], shell=True, stderr=subprocess.STDOUT, env=cur_env, cwd=cwd)
        else:
            output = subprocess.check_output(cmd, stderr=subprocess.STDOUT, env=cur_env)
        return f'{getHostNameIP()} / cmd: ' + ' '.join(cmd) + '\r\n' + parseOutput(output)
    except subprocess.CalledProcessError as perr:
        print(perr, perr.output)
        raise Exception(f'code:{perr.returncode} / err:{perr.output}')

    
### End of misc.py ###