from contextlib import contextmanager
import os, json, time, copy, subprocess, tempfile
from botocore.exceptions import ClientError
from multiprocessing.pool import ThreadPool, Pool

from .boto3_wrapper import Boto3Wrapper
from .logger import Logger

log = Logger('s3_wrapper')

default_options = {
    'assume_role': {
        'arn': '',
        'name': '',
        'account_number': '',
        'kwargs': {}, # DurationSeconds
    },

    # deprecated attributes
    # 'assume_role_arn': ''
}


## upload with retry
def upload_file(s3_reoursce, s3_bucket, full_path, path, s3_path, file_num=1):
    retries = 5
    success = False
    retry_interval = 60
    while retries > 0 and success == False:
        try:
            s3_reoursce.meta.client.upload_file(Bucket=s3_bucket,Key=s3_path + '/' + full_path[len(path)+1:], Filename=full_path)
            success = True
            break
        except Exception as e:
            log.exception(e)
        time.sleep(retry_interval)
        retries -= 1
    
    if not success:
        raise Exception(f'Failed to upload {full_path} to {s3_path}')
    log.info(f'finished upload: {full_path} to {s3_path} - file_num_{file_num}')

@contextmanager
def s3_mount(bucket_name):
    # requires s3fs and fusermount
    temp_dir = tempfile.mkdtemp()
    try:
        # Mount the S3 bucket to the temporary directory
        log.info(f"Mounting {bucket_name} to {temp_dir}")
        subprocess.check_call(['s3fs', bucket_name, temp_dir])
 
        yield temp_dir
 
    finally:
        try:
            # Unmount the S3 bucket
            log.info(f"Unmounting {temp_dir}")
            # subprocess.check_call(['fusermount', '-u', temp_dir])
            subprocess.check_call(['umount', '-l', temp_dir])
            os.rmdir(temp_dir)
        except Exception as err:
            log.exception(err)

@contextmanager
def s3_multiple_mounts(bucket_names):
    # requires s3fs and fusermount
    temp_dirs = {b:tempfile.mkdtemp() for b in bucket_names}
    try:
        for b in temp_dirs:
            # Mount the S3 bucket to the temporary directory
            log.info(f"Mounting {b} to {temp_dirs[b]}")
            subprocess.check_call(['s3fs', b, temp_dirs[b]])
 
        yield temp_dirs
 
    finally:
        # Unmount the S3 bucket
        for b in temp_dirs:
            try:
                temp_dir = temp_dirs[b]
                log.info(f"Unmounting {temp_dir}")
                subprocess.check_call(['fusermount', '-u', temp_dir])
                os.rmdir(temp_dir)
            except Exception as err:
                log.exception(err)

def s3_mount_path_from_s3_path(mount, s3_path):
    bucket = s3_path.split('s3://')[-1].split('/')[0]
    key = s3_path.split(f'{bucket}/', 1)[-1].strip('/')
    return os.path.join(mount, key)

def s3_mount_path_to_s3_path(path, bucket):
    s3_key = path.split(bucket+'/')[-1].strip('/')
    if os.path.exists(path) and os.path.isdir(path):
        s3_key = s3_key + '/'
    return s3_path_combine(bucket, s3_key)

def s3_path_split(s3_path):
    bucket = s3_path.split('s3://')[-1].split('/')[0]
    key = s3_path.split(f'{bucket}/', 1)[-1]
    return bucket, key

def s3_path_combine(s3_bucket, s3_key):
    return f"s3://{s3_bucket}/{s3_key}"
    

class S3Wrapper:
    def __init__(self, opts={}):
        self.options = copy.deepcopy(default_options)
        if opts: self.options.update(opts)
        self.boto3_wrapper = Boto3Wrapper(opts)
        
        self.s3_client = None
        self.s3_resource = None

        self.total_upload = 0
        self.finished_upload = 0

    def __get_s3_client(self):
        if not self.s3_client:
            self.s3_client = self.boto3_wrapper.get_client('s3')
        return self.s3_client
    
    def __get_s3_resource(self):
        if not self.s3_resource:
            self.s3_resource = self.boto3_wrapper.get_resource('s3')
        return self.s3_resource
        
    def s3_path_exists(self, bucket_name, key):
        try:
            self.__get_s3_client().head_object(Bucket=bucket_name, Key=key)
            return True
        except ClientError as e:
            # try list_objects_v2
            try:
                res = self.__get_s3_client().list_objects_v2(Bucket=bucket_name, Prefix=key, MaxKeys=1)
                return 'Contents' in res
            except ClientError as e1:
                log.debug(e1)
            log.debug(e)
            # If a client error is thrown, then check that it was a 404 error.
            # If it was a 404 error, then the object does not exist.
            error_code = int(e.response['Error']['Code'])
            if error_code == 404:
                return False
            else:
                raise

    def s3_path_exists_by_path(self, s3_path):
        return self.s3_path_exists(*s3_path_split(s3_path))
    
    def list_s3_files(self, bucket_name, prefix, toplevel=False):
        continuation_token = None
        objs = []
        while True:
            list_params = {
                'Bucket': bucket_name,
                'Prefix': prefix
            }
            if toplevel:
                list_params['Delimiter'] = '/'
            if continuation_token:
                list_params['ContinuationToken'] = continuation_token
            
            response = self.__get_s3_client().list_objects_v2(**list_params)
            
            if 'Contents' in response:
                # might have to check for .j2c with a loop
                objs += response['Contents']

            if 'CommonPrefixes' in response:
                objs += [{'Key': prefix['Prefix']} for prefix in response['CommonPrefixes']]
            
            # if there are more than 1000 objects in response
            if response.get('IsTruncated'): 
                continuation_token = response.get('NextContinuationToken')
            else:
                break
        
        return [ s3_path_combine(bucket_name, obj['Key']) for obj in objs if obj['Key'].rstrip('/') != prefix.rstrip('/')]
    
    def list_s3_files_by_path(self, s3_path, toplevel=False):
        return self.list_s3_files(*s3_path_split(s3_path), toplevel)

    # detect s3 return result matching on-prem response
    def path_detection(self, s3_path, options={}):
        check_exist = options.get('check_exist', False)
        listdir = options.get('listdir', False)
        if listdir:
            check_exist = True
        
        bucket, key = s3_path_split(s3_path)
        is_folder = key.endswith('/')
        is_exist = False
        if check_exist:
            if self.s3_path_exists(bucket, key.rstrip('/') + '/'):
                log.debug('is folder')
                is_folder = True
                is_exist = True
            elif self.s3_path_exists(bucket, key):
                log.debug('is file')
                is_folder = False
                is_exist = True
        if is_folder:
            key = key.rstrip('/') + '/'
        s3_full = s3_path_combine(bucket, key)
        result = {
                "exist": is_exist,
                "listdir": [ s.replace(s3_full, '') for s in self.list_s3_files(bucket, key, True) ] if is_folder and listdir else [],
                "location": "s3",
                "mnt": f"/mnt/{bucket}/",
                "mnt_full": f"/mnt/{bucket}/{key}",
                "originalpath": s3_path,
                "relativepath": key,
                "s3": f"s3://{bucket}/",
                "s3_full": s3_full,
                "type": "folder" if is_folder else "file",
                "unc": f"//{bucket}/",
                "unc_full": f"//{bucket}/{key}",
                "vidispine": "",
                "volumes": f"/Volumes/{bucket}/",
                "volumes_full": f"/Volumes/{bucket}/{key}"
            }
        return [ result ]

    def s3_file_size(self, bucket, key):
        response = self.__get_s3_client().head_object(Bucket=bucket, Key=key)
        size = response['ContentLength']
        return size
    
    def s3_file_size_by_path(self, s3_path):
        return self.s3_file_size(*s3_path_split(s3_path))

    def create_s3_folder_by_path(self, s3_path):
        self.create_s3_folder(*s3_path_split(s3_path))

    def create_s3_folder(self, bucket_name, key):
        key = key.strip('/') + '/'
        self.__get_s3_client().put_object(Bucket=bucket_name, Key=key)

    def create_s3_file(self, bucket_name, s3_key, content):
        self.__get_s3_client().Object(bucket_name, s3_key).put(Body=content)
        return s3_path_combine(bucket_name, s3_key)
    
    def create_s3_file_by_path(self, s3_path, content):
        bucket_name, s3_key = s3_path_split(s3_path)
        return self.create_s3_file(bucket_name, s3_key, content)

    def get_s3_file_content(self, bucket_name, s3_key, encoding='utf-8'):
        return self.__get_s3_client().Object(bucket_name, s3_key).get()['Body'].read().decode(encoding)

    def get_s3_file_content_by_path(self, s3_path, encoding='utf-8'):
        bucket_name, s3_key = s3_path_split(s3_path)
        return self.get_s3_file_content(bucket_name, s3_key, encoding)

    def upload_s3_files(self, path, s3_bucket, s3_path):
        """
        Upload a file or contents of a directory to a specific s3 directory
        Args:
            path: file/folder path
            s3_bucket: s3 bucket
            s3_path: path to destination s3 folder
        """
        s3_resource = self.__get_s3_resource()

        pool = ThreadPool(4)
        data = []

        if os.path.isfile(path):
            data.append((s3_resource, s3_bucket,path, os.path.dirname(path), s3_path))
        else:
            file_num = 1
            for subdir, dirs, files in os.walk(path):
                for file in files:
                    #print(file)
                    full_path = os.path.join(subdir, file)
                    data.append((s3_resource, s3_bucket, full_path, path, s3_path, file_num))
                    file_num += 1

        self.total_upload = len(data)
        log.info(f'total_upload: {self.total_upload}')
        pool.starmap(upload_file, data)
        pool.close()
        pool.join()

        return s3_bucket, os.path.join(s3_path, os.path.basename(path))
    
    def upload_s3_file_by_path(self, path, s3_full_path):
        return self.upload_s3_file(path, *s3_path_split(s3_full_path))

    def upload_s3_file(self, path, s3_bucket, s3_path):
        if s3_path.endswith('/'):
            s3_path = os.path.join(s3_path, os.path.basename(path))
        self.__get_s3_resource().meta.client.upload_file(Bucket=s3_bucket, Key=s3_path, Filename=path)
        return s3_path_combine(s3_bucket, s3_path)

    def upload_s3_dir_by_path(self, path, s3_full_path):
        bucket_name, prefix = s3_path_split(s3_full_path)
        return self.upload_s3_dir(path, bucket_name, prefix)

    def upload_s3_dir(self, path, s3_bucket, s3_path):
        s3_resource = self.__get_s3_resource()
        if os.path.isfile(path):
            key = os.path.join(s3_path, os.path.basename(path)).strip('/')
            s3_resource.meta.client.upload_file(Bucket=s3_bucket, Key=key, Filename=path)
        else:
            with ThreadPool(4) as pool:
                futures = []
                for subdir, dirs, files in os.walk(path):
                    for file in files:
                        filename = os.path.join(subdir, file)
                        key = os.path.join(s3_path, filename[len(path)+1:]).strip('/')
                        args = (s3_bucket, key, filename)
                        futures.append(pool.apply_async(lambda s3_bucket, key, filename: s3_resource.meta.client.upload_file(Bucket=s3_bucket,Key=key, Filename=filename), args))

                self.finished_upload = 0
                self.total_upload = len(futures)
                log.info(f'total_upload: {self.total_upload}')
                for future in futures:
                    future.get()
                    self.finished_upload += 1
                    log.info(f'finished upload: {self.finished_upload}/{self.total_upload}')

        return s3_bucket, os.path.join(s3_path, os.path.basename(path))

    ### deprecated, use download_s3 instead
    def download_s3_files(self, bucket_name, s3_path, local_dir=None):
        """
        Deprecated: Use download_s3_file / download_s3_dir
        """
        return self.download_s3_dir(bucket_name, s3_path, local_dir)

    def download_s3_file_by_path(self, s3_full_path, local_dir=None, local_path=None):
        bucket_name, prefix = s3_path_split(s3_full_path)
        return self.download_s3_file(bucket_name, prefix, local_dir, local_path)

    def download_s3_file(self, bucket_name, prefix, local_dir=None, local_path=None):
        if not local_path:
            local_path = prefix if not local_dir else os.path.join(local_dir, os.path.basename(prefix))
        local_dir = os.path.dirname(local_path)
        if not os.path.exists(local_dir):
            os.makedirs(local_dir)
        self.__get_s3_client().download_file(bucket_name, prefix, local_path)
        return local_path

    # alternate s3 download - use pagination to > 1000 files
    def download_s3_dir_by_path(self, s3_full_path, local_dir=None):
        bucket_name, prefix = s3_path_split(s3_full_path)
        return self.download_s3_dir(bucket_name, prefix, local_dir)

    def download_s3_dir(self, bucket_name, prefix, local_dir=None):
        prefix = prefix.strip('/') + '/' # make it is folder object
        s3_client = self.__get_s3_client()
        paginator = s3_client.get_paginator('list_objects_v2')
        downloaded_paths = []
        with ThreadPool(4) as pool:
            futures = []
            for result in paginator.paginate(Bucket=bucket_name, Prefix=prefix):
                for key in result.get('Contents', []):
                    key_path = key['Key'].split(prefix)[-1].lstrip('/')
                    if not key_path or key_path.endswith('/'):  # skip if key_path is not a file
                        continue
                    local_path = key['Key'] if local_dir is None else os.path.join(local_dir, key_path)
                    local_path_dir = os.path.dirname(local_path)
                    if not os.path.exists(local_path_dir):
                        os.makedirs(local_path_dir)
                    downloaded_paths.append(local_path)
                    futures.append(pool.apply_async(lambda bucket_name, key, local_path: s3_client.download_file(bucket_name, key, local_path), (bucket_name, key['Key'], local_path)))

            for future in futures:
                future.get()

        return downloaded_paths

    def get_presigned_s3_path(self, bucket_name, s3_path, expiration=3600):
        return self.__get_s3_client().generate_presigned_url(
            'get_object',
            Params={'Bucket': bucket_name, 'Key': s3_path},
            ExpiresIn=expiration
        )

    def get_presigned_s3_full_path(self, s3_full_path, expiration=3600):
        bucket_name, s3_path = s3_path_split(s3_full_path)
        return self.get_presigned_s3_path(bucket_name, s3_path, expiration)

    def get_s3_info(self, s3_path):
        s3_bucket_name, s3_key_path = s3_path_split(s3_path)
        bucket = self.__get_s3_client().Bucket(s3_bucket_name)
        s3_key_paths = [obj.key for obj in bucket.objects.filter(Prefix=s3_key_path)]
        return s3_key_paths

    def s3_copy(self, s3_src, s3_dst):
        src_bucket, src_key = s3_path_split(s3_src)
        copy_source = {
            'Bucket': src_bucket,
            'Key': src_key
        }
        dst_bucket, dst_key = s3_path_split(s3_dst)
        self.__get_s3_client().copy(copy_source, dst_bucket, dst_key)

    def get_bucket_region(self, bucket_name):
        location = self.__get_s3_client().get_bucket_location(Bucket=bucket_name)
        # For US East (N. Virginia) region, 'LocationConstraint' is None
        return location['LocationConstraint'] or 'us-east-1'


