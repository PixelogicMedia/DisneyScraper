import boto3, json, copy, os

default_options = {
    'assume_role': {
        'arn': '',
        'name': '',
        'account_number': '',
        'kwargs': {}, # DurationSeconds
    },
    'kwargs': {}, # extra boto3 session/client kwargs such as region_name, profile_name, etc.

    ## deprecated attributes
    # 'assume_role_arn': '',
    # 'assume_role_name': '',
    # 'assume_account_number': '',
}

class Boto3Wrapper:
    # to use assume role, you need to set assume_role_arn or assume_account_number and assume_role_name
    def __init__(self, opts={}):
        options = copy.deepcopy(default_options)
        options.update(opts)

        # get assume role
        assume_role = options.get('assume_role') or {}
        # back compatibility
        if not assume_role:
            assume_role = {
                'arn': options.get('assume_role_arn'),
                'name': options.get('assume_role_name'),
                'account_number': options.get('assume_account_number'),
            }

        self.assume_role_arn = assume_role.get('arn')
        self.assume_role_kwargs = assume_role.get('kwargs') or {}
        if not self.assume_role_arn:
            assume_account_number = assume_role.get('account_number')
            assume_role_name = assume_role.get('name')
            if assume_account_number and assume_role_name:
                self.assume_role_arn = f"arn:aws:iam::{assume_account_number}:role/{assume_role_name}"

        self.kwargs = options.get('kwargs') or {}

    def assume_role_cred(self):
        if not self.assume_role_arn:
            raise Exception("No assume role arn provided")
        
        sts_client = boto3.client('sts')
        role_name = self.assume_role_arn.split('/')[-1]
        role_session_name = f"AssumeRoleSession_{role_name}_{os.getpid()}"
        try:
            # force using sts regional
            # https://docs.aws.amazon.com/sdkref/latest/guide/feature-sts-regionalized-endpoints.html
            os.environ['AWS_STS_REGIONAL_ENDPOINTS'] = 'regional'
            assumed_role_object = sts_client.assume_role(
                RoleArn=self.assume_role_arn,
                RoleSessionName=role_session_name,
                **self.assume_role_kwargs
            )
        except Exception as e:
            print(f"[ERROR] Assume role [{self.assume_role_arn}] failed with AWS_STS_REGIONAL_ENDPOINTS=regional, trying AWS_STS_REGIONAL_ENDPOINTS=legacy")
            os.environ['AWS_STS_REGIONAL_ENDPOINTS'] = 'legacy'
            assumed_role_object = sts_client.assume_role(
                RoleArn=self.assume_role_arn,
                RoleSessionName=role_session_name,
                **self.assume_role_kwargs
            )

        print(f"[WARNING] Assumed Role [{self.assume_role_arn}]...")
        print(f"[WARNING] Assumed Role Expiration [{assumed_role_object['Credentials']['Expiration']}]...")
        return assumed_role_object['Credentials']
    
    def __self_update_assume_role_cred(self):
        if self.assume_role_arn:
            credentials = self.assume_role_cred()
            self.kwargs.update({
                'aws_access_key_id': credentials['AccessKeyId'],
                'aws_secret_access_key': credentials['SecretAccessKey'],
                'aws_session_token': credentials['SessionToken']
            })
    
    def get_session(self):
        self.__self_update_assume_role_cred()
        return boto3.Session(**self.kwargs)
    
    def get_client(self, client_name):
        self.__self_update_assume_role_cred()
        return boto3.client(client_name, **self.kwargs)

    def get_resource(self, service_name):
        self.__self_update_assume_role_cred()
        return boto3.resource(service_name, **self.kwargs)

    def call_state_machine(self, state_machine_arn, payload):
        sf = self.get_client('stepfunctions')
        if type(payload) in [dict, list]:
            payload = json.dumps(payload)
        res = sf.start_execution(
            stateMachineArn=state_machine_arn,
            input=payload
        )
        # parse datetime object to string
        try: 
            res['startDate'] = res['startDate'].isoformat()
            return res
        except:
            pass
        try:
            return res
        except:
            pass
        return str(res)
    
    # basic batch job submission
    # need improvement for more complex job submission
    def submit_batch_job(self, job_name, job_queue, job_definition, job_cmd=[], job_envs=[]):
        containerOverrides = {}
        if job_cmd:
            containerOverrides['command'] = job_cmd
        if job_envs:
            if job_envs is dict:
                job_envs = [ {"name": key, "value": value} for key, value in job_envs.items() ]
            containerOverrides['environment'] = job_envs
            
        client = self.get_client('batch')
        response = client.submit_job(
            jobName=job_name,
            jobQueue=job_queue,
            jobDefinition=job_definition,
            containerOverrides=containerOverrides
        )
        return response

### End of boto3_wrapper.py ###
