from __future__ import absolute_import
import copy, requests, os

try:
    # load default sso for celery
    from ..secrets.service_setup import om_sso_client_id, om_sso_client_secret
    os.environ['SSO_CLIENT_ID'] = om_sso_client_id
    os.environ['SSO_CLIENT_SECRET'] = om_sso_client_secret
except:
    pass

try:
    from .aws_secret import get_env_secret
    sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
except:
    sec = {}
    

__options = {
    'url': sec.get('sso_url') or os.getenv('SSO_URL') or 'https://sso.pixelogicmedia.com/auth/realms/phelix/protocol/openid-connect/token',
    'grant_type': sec.get('sso_grant_type') or os.getenv('SSO_GRANT_TYPE') or '', # password or client_credentials
    
    'username': sec.get('sso_username') or os.getenv('SSO_USERNAME') or '',
    'password': sec.get('sso_password') or os.getenv('SSO_PASSWORD') or '',
    'client_id': sec.get('sso_client_id') or os.getenv('SSO_CLIENT_ID') or '',
    'client_secret': sec.get('sso_client_secret') or os.getenv('SSO_CLIENT_SECRET') or '',
    'scope': sec.get('sso_scope') or os.getenv('SSO_SCOPE') or '',
}

def getSSOToken(opts = {}):
    options = copy.deepcopy(__options)
    options.update(opts)
    # print(opts)
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    if not options.get('grant_type'):
        options['grant_type'] = 'client_credentials' if options.get('client_id') else 'password'
    if options['grant_type'] == 'password':
        headers['Authorization'] =  f"Basic {options['username']}:{options['password']}"
        res = requests.post(options['url'], headers=headers)
    elif options['grant_type'] == 'client_credentials':
        data = {
            'grant_type': 'client_credentials',
            'client_id': options['client_id'],
            'client_secret': options['client_secret']
        }
        if options.get('scope'):
            data['scope'] = options['scope']
        #data = f"grant_type=client_credentials&client_id={options['client_id']}&client_secret={options['client_secret']}"
        res = requests.post(options['url'], headers=headers, data=data)
    else:
        raise Exception('invalid grant type: ' + options['grant_type'])
    if res.status_code == 200:
        return res.json()
    raise Exception(f"sso failed: code({res.status_code}) / {str(res.content)}")
