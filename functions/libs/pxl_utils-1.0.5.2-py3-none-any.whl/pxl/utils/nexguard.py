import requests
import xml.etree.ElementTree as ET
import uuid 
import socket, json, os

try:
    from ..secrets.nexguard_secret import secret
    baseUrl = secret['nexguard']['manager_url']
    username = secret['nexguard']['username']
    password = secret['nexguard']['password']
except:
    baseUrl = 'http://10.220.112.186/Manager.WebService/v2/'
    username = ''
    password = ''

headers = {'Content-Type': 'text/xml'}


def getElemText(elem):
   if elem is None:
       return ''
   else:
       if elem.text is None:
           return ''
       else:
           return elem.text

def createNexguardJob(titleID, custID, reptID, jobName, keyID = '61572651155456002'):
   content = '<externaljob>  <state>New</state>  <name></name>  <customer><id>61572651155456002</id></customer>  <recipient><id>11123</id></recipient>  <title><id></id></title>  <key><id>61572651155456002</id></key>  <reference></reference></externaljob>'
   root = ET.fromstring(content)
   root.find('name').text = jobName
   root.find('customer').find('id').text = custID
   root.find('recipient').find('id').text = reptID
   root.find('key').find('id').text = keyID
   root.find('title').find('id').text = titleID
   root.find('reference').text = str(uuid.uuid1())
   
   url = baseUrl + 'jobs/external'
   response = requests.post(url, auth=(username, password), data = ET.tostring(root), headers = headers)
   response.raise_for_status()
   return ET.fromstring(response.content)
# end of getWmidId

def updateNexguardJob(rootJob, source, destination):
   rootJob.find('state').text = 'Finished'
   rootJob.find('source').text = source
   rootJob.find('destination').text = destination
   rootJob.find('progress').text = '100'
   rootJob.find('plugin_name').text = 'ffmpeg'
   rootJob.find('plugin_version').text = '3.5'
   rootJob.find('plugin_wmsdk_version').text = '7.1.5'   
   rootJob.find('plugin_hostname').text = socket.gethostname()  
   
   url = rootJob.find('uri').text
   pos = url.find('jobs/external')
   if pos < 0:
       raise ValueError('invalid uri found when updateNexguardJob: ' + url)
   url = baseUrl + url[pos:]
   response = requests.post(url, auth=(username, password), data = ET.tostring(rootJob), headers = headers)
   response.raise_for_status()
# end of updateNexguardJob

def getTitleId(name, version = ''):
   url = baseUrl + 'titles?name='+name
   response = requests.get(url, auth=(username, password))
   response.raise_for_status()
   root = ET.fromstring(response.content)

   lowerName = name.lower().strip()
   lowerVersion = version.lower().strip()

   if len(lowerName) == 0 :
       raise ValueError('Title Name was not provided for Title ID request.') 

   for customer in root.iter('title') :
      if lowerName == getElemText(customer.find('name')).lower() \
       and lowerVersion == getElemText(customer.find('version')).lower() :
          return customer.find('id').text
   
   # create new customer
   content = '<title> <name></name>  <version></version> </title>'
   root = ET.fromstring(content)
   root.find('name').text = name.strip()
   root.find('version').text = version.strip()
   content = ET.tostring(root)
   response = requests.post(url, auth=(username, password), data = content, headers = headers)
   response.raise_for_status()
   jobXML = response.content
   root = ET.fromstring(jobXML)
   return root.find('id').text
# end of getTitleId

def getContactId(type, lastName, firstName = '', organization = ''):
   # create new customer
   if type == 'recipients':
       content = '<recipient>  <lastname></lastname>  <firstname></firstname>  <organization></organization> </recipient>'
       tag = 'recipient'
   elif type == 'customers':
       content = '<customer>  <lastname></lastname>  <firstname></firstname>  <organization></organization> </customer>'
       tag = 'customer'
   else:
       raise ValueError('Invalid contact type: ' + type + '. customers or recipents are expected.')

   url = baseUrl + type + "?lastname=" + lastName
   response = requests.get(url, auth=(username, password))
   response.raise_for_status()
   root = ET.fromstring(response.content)

   lowerOrg = organization.lower().strip()
   lowerFN = firstName.lower().strip()
   lowerLN = lastName.lower().strip()
   if len(lowerLN) == 0 :
       raise ValueError('Last Name was not provided for customer ID request.') 

   for customer in root.iter(tag) :
      if lowerOrg == getElemText(customer.find('organization')).lower() \
       and lowerFN == getElemText(customer.find('firstname')).lower() \
       and lowerLN == getElemText(customer.find('lastname')).lower() :
          return customer.find('id').text
   

   root = ET.fromstring(content)
   root.find('organization').text = organization.strip()
   root.find('firstname').text = firstName.strip()
   root.find('lastname').text = lastName.strip()
   content = ET.tostring(root)
   response = requests.post(url, auth=(username, password), data = content, headers = headers)
   response.raise_for_status()
   jobXML = response.content
   root = ET.fromstring(jobXML)
   return root.find('id').text
# end of getContactId

def nexguard(custom_org, custom_fn, custom_ln, rept_org, rept_fn, rept_ln, title_n, title_v, job_name='Pixelogic Transcode Job'):
    # get cursomer ID. If the requested curstomer does not exist, it will be created.
    cust_id = getContactId('customers', custom_ln, custom_fn, custom_org)
    # get recipient ID. If the requested recipient does not exist, it will be created.
    rept_id = getContactId('recipients', rept_ln, rept_fn, rept_org)
    # get recipient ID. If the requested recipient does not exist, it will be created.
    title_id = getTitleId(title_n, title_v)
    # get new wmid
    wmjob_root = createNexguardJob(title_id, cust_id, rept_id, job_name)
    return wmjob_root

def test():
    # get cursomer ID. If the requested curstomer does not exist, it will be created.
    cust_id = getContactId('customers', 'Wang', 'Ruopeng')
    print('customer id:', cust_id)

    # get recipient ID. If the requested recipient does not exist, it will be created.
    rept_id = getContactId('recipients', 'Wang', 'Ruopeng')
    print('recipient id:', rept_id)

    # get recipient ID. If the requested recipient does not exist, it will be created.
    title_id = getTitleId('Test Title', 'P1')
    print('title id:', title_id)

    # get new wmid
    wmjob_root = createNexguardJob(title_id, cust_id, 'ffmpeg test job 1')
    print('new wmid:', wmjob_root.find('wmid').text)

    # run ffmpeg to transcode

    # update nexguard title db
    updateNexguardJob(wmjob_root)



