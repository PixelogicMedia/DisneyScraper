# Call Partners API
# sso role: TBD
# docs: https://service-catalog.pixelogicmedia.com/catalog/default/api/partners-api/definition
# Dev url: https://partners-api-dev.pixelogicplayground.com/api/v1/
# Staging url: https://partners-api-staging.pixelogicmedia.us/api/v1/
# Production url: https://phelix.pixelogicmedia.com/services/partners-api/api/v1


import requests, copy, os, time, json
from urllib.parse import urlencode
from .sso import getSSOToken
from .misc import fixEmailsArr

sec={}
try:
    from ..secrets.service_setup import om_sso_client_id as client_id, om_sso_client_secret as client_secret, partners_base_url as base_url
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    client_id = sec.get('sso_client_id') or os.getenv('SSO_CLIENT_ID') or ''
    client_secret = sec.get('sso_client_secret') or os.getenv('SSO_CLIENT_SECRET') or ''
    base_url = sec.get('partners_base_url') or os.getenv('PARTNERS_BASE_URL') or ''

from .logger import Logger

log = Logger('partners-api')

default_options = {
    'base_url': base_url,
    
    'sso_opt': {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
    },

    'admin_emails': 'automation.service@pixelogicmedia.com',

    'location_map': {
        'burbank': 'Burbank',
        'culver': 'Culver',
        'motor': 'Culver',
        'uk': 'London',
        'london': 'London',
        'cairo': 'Cairo',
    },

    'polling_time': 5,
    'timeout': 3600,

}

class PartnersApi:
    
    def __init__(self, opts=None):
        self.options = copy.deepcopy(default_options)
        if opts: self.options.update(opts)
        self.__base_url = self.options['base_url']
        self.__access_token = ''
        self.__token_expiration = None
        self.__refresh_headers()
        # log.debug(self.__access_token)

    def __refresh_headers(self):
        if not self.__access_token or time.time() > self.__token_expiration:
            token_data = getSSOToken(self.options['sso_opt'])
            self.__token_expiration = time.time() + token_data['expires_in']
            self.__access_token = token_data['access_token']

        return {
            'Authorization': 'Bearer ' + self.__access_token
        }

    def __api_url(self, path, query_params='') -> str:
        if not path.startswith(self.__base_url):
            path = self.__base_url.strip('/') + '/' + path.lstrip('/')
        path = path.replace('/api/v1/api/v1/', '/api/v1/')
        
        if type(query_params) == dict:
            query_params = urlencode({k:v for k,v in query_params.items() if v})
        query_params = '' if not query_params else f"?{query_params.strip('?')}"

        return path.lstrip('/') + query_params
    
    def call_api(self, url, method='GET', data=None, query_params=None, headers={}):
        log.debug(f"Calling Partners API [{method}] {url} with data: {data} and query_params: {query_params}")
        if query_params or not url.startswith(self.__base_url):
            url = self.__api_url(url, query_params)
        headers.update(self.__refresh_headers())
        if type(data) in [dict, list] and 'Content-Type' not in headers:
            response = requests.request(method, self.__api_url(url), headers=headers, json=data)
        else:
            response = requests.request(method, self.__api_url(url), headers=headers, data=data)
        log.debug(f"Partners API response: {response.status_code} / {response.content}")
        response.raise_for_status()
        try: return response.json()
        except: return response.content

    def get_api(self, url, query_params=None, headers={}):
        return self.call_api(url, query_params=query_params, headers=headers)

    def post_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='POST', data=data, query_params=query_params, headers=headers)

    def put_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='PUT', data=data, query_params=query_params, headers=headers)

    # Jobs
    def check_partners_by_emails(self, emails):
        emails = fixEmailsArr(emails)
        payload = {
            "emails": emails
        }
        res = self.put_api('/phelix/userInfos', payload)
        res.raise_for_status()
        users_info = res.json()
        exist_emails = list(set([u['email'] for u in users_info['users'] if u.get('email')] + users_info['contactEmails']))
        non_exist_emails = [e for e in emails if e not in exist_emails ]
        return {
            'exist_emails': exist_emails,
            'non_exist_emails': non_exist_emails
        }


    
if __name__ == "__main__":
    os.environ['PARTNERS_BASE_URL'] = 'https://phelix.pixelogicmedia.com/services/partners-api/api/v1'
    pi = PartnersApi()
    payload = {
        "emails": [
            "thanh.ho@pixelogicmedia.com"
        ]
    }
    res = pi.put_api('/phelix/userInfos', data=payload)
    

    try: print(json.dumps(res))
    except: print(res)