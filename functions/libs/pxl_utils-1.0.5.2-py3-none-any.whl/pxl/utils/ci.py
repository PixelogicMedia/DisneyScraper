from requests.auth import HTTPBasicAuth
import datetime, time, json, os, requests
import concurrent.futures

from .logger import Logger
from .misc import fixEmailsStr, base64decode, base64encode

sec={}
try:
    from ..secrets.service_setup import ci_user, ci_pw
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    ci_user = sec.get('ci_user') or os.getenv('CI_USER') or ''
    ci_pw = sec.get('ci_pw') or os.getenv('CI_PW') or ''


logger = Logger('ci_setup')

def readFileInChunks(file_object, chunk_size):
    idx = 1
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break
        yield idx, data
        idx += 1

class CI:
    __max_upload_single_size = 150 * 1024 * 1024 # 150Mb
    __max_upload_multipart_size = 5 * 1024 * 1024 * 1024 * 1024 # 5Tb
    __chunk_size = 100 * 1024 * 1024 # 500Mb
    __max_num_of_parts = 10000
    __max_retries = 5
    __max_workers = 4
    
    options = {
        'pxl_url': 'https://pixelogic.cimediacloud.com',
        'api_url': 'https://api.cimediacloud.com',
        'io_url': 'https://io.cimediacloud.com',
        'auth': {'user': ci_user, 'pw': ci_pw},
        'client_id': '90ded1ac970b4ee9b5f8d72700b63454',
        'client_sec': 'b0e6bacfe87a42caa38c8c04e5baf882',
    }
    
    def __init__(self, opts = {}):
        self.token = ''
        if opts:
            self.options.update(opts)
        if not self.options.get('io_url') or not self.options.get('api_url') or not self.options.get('auth'):
            raise Exception('Invalid options')
        self.generateAccessToken()
        logger.info(self.token)

    def deliver(self, job):
        if not job:
            raise Exception('Blank job')
        if not os.path.isfile(job['file']):
            raise Exception('Invalid file (local)')
        if not job.get('wsid'):
            raise Exception('Invalid Ci workspace')
        if not job.get('folderpath') and not job.get('folderid'):
            raise Exception('Invalid Ci folderid or folderpath')
        logger.info(job)
        if not job.get('folderid'):
            folderpath = job.get('folderpath')
            job['folderid'] = self.getOrCreateFolderByPath(job['wsid'], job.get('rootfolderid'), folderpath)
        if not job.get('folderid'):
            raise Exception('Invalid Ci folder or cannot create folder')

        job['filename'] = os.path.basename(job['file'])
        filesize = os.path.getsize(job['file'])
        if filesize<=0:
            raise Exception('Invalid file (0 byte or no accessisble): ' + job['file'])
        logger.info('### Creating asset ...')
        logger.info(str(job))
        
        if filesize > self.__max_upload_multipart_size or int(filesize / self.__chunk_size) >= self.__max_num_of_parts:
            raise Exception(f"Asset reaches upload limit (file size: {filesize})")
        
        # init upload
        job['assetid'], part_count = self.initUploadMultipart(job['file'], self.__chunk_size, job['wsid'], job['folderid'], job.get('ingestConfiguration'))

        # uploading
        part_numbers = list(range(1, part_count+1))
        upload_parts = self.getUploadMultipartBatch(job['assetid'], part_numbers)['parts']
        upload_jobs = {part['partNumber']: part['uploadUrl'] for part in upload_parts}
        futures = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.__max_workers) as e:
            with open(job['file'], 'rb') as f:
                for idx, chunk in readFileInChunks(f, self.__chunk_size):
                    future = e.submit(self.uploadPart, upload_jobs[idx], chunk)
                    futures[future] = idx
        
        completed_part_numbers = []
        for future in concurrent.futures.as_completed(futures):
            part_num = futures[future]
            try:
                if not future.result():
                    raise Exception(f'uploading failed part: {part_num}')
                logger.info(f'uploading success part: {part_num}')
                completed_part_numbers.append(part_num)
                if len(completed_part_numbers) >= self.__max_workers:
                    logger.info(f'complete batch: {completed_part_numbers}')
                    self.completeUploadBatch(job['assetid'], completed_part_numbers)
                    completed_part_numbers = []
            except Exception as exc:
                logger.exception(exc)
                err = f"uploading failed for asset {job['assetid']} at part: {future}"
                self.deleteAsset(job['assetid'])
                raise Exception(f"uploading failed for asset {job['assetid']} at part: {future}")
        if completed_part_numbers:
            logger.info(f'complete batch: {completed_part_numbers}')
            self.completeUploadBatch(job['assetid'], completed_part_numbers)

        # complete
        time.sleep(5)
        if not self.completeUploadMultipart(job['assetid']):
            raise Exception('completing upload failed: asset - ' + job['assetid'])
        
        job['link'] = self.options['pxl_url'] + '/ci/#/workspaces/' + job['wsid'] + '/folders/' + job['folderid']
        job['preview_link'] = self.options['pxl_url'] + '/ci/#/workspaces?assets=' + job['assetid']
        job['status'] = 'success'
        return job

    def requestWorkSession(self, assetid, name, sender, recipients):
        #check asset available
        while True:
            time.sleep(15)
            asset = self.getAsset(assetid)
            logger.info(asset['status'])
            if asset['status'] == 'Complete':
                break
            if asset['status'] in ['Processing', 'Waiting']:
                continue
            raise Exception('invalid asset status: ' + asset['status'])
        return self.createWorkSession([assetid], name, fixEmailsStr(recipients).split(','))

    def requestMediaBoxForFolder(self, wsid, folderid, recipients):
        mediabox = self.checkMediaBoxForFolder(wsid, folderid)
        # create new media box
        if not mediabox:
            folder = self.getFolder(folderid)
            mediabox = self.createMediaBox(folder['name'],folder['name'], [], [folderid], recipients.replace(' ', ',').replace(';', ',').split(','), False, 100)
        if not mediabox:
            raise Exception('Error creating media box.')
        return mediabox['link']

    def generateAccessToken(self):
        citokenfile = 'ci.token.tmp'
        if os.path.isfile(citokenfile):
            try:
                with open(citokenfile, 'r') as f:
                    try: token = json.loads(base64decode(f.read()))
                    except: token = json.load(f)
                expiration = datetime.datetime.fromtimestamp(token['expiration'])
                if datetime.datetime.now() < expiration:
                    self.token =  'bearer ' + token['access_token']
                    return self.token
            except Exception as err:
                log.exception(err)
        # get new token
        url = self.options['api_url'] + '/oauth2/token'
        payload = {
            'client_id': self.options['client_id'],
            'client_secret': self.options['client_sec'],
            'grant_type': 'password'
        }
        res = requests.post(url, auth=HTTPBasicAuth(
            self.options['auth']['user'], self.options['auth']['pw']), json=payload)
        if res.status_code == 200:
            token = res.json()
            expiration = datetime.datetime.now(
            ) + datetime.timedelta(seconds=token['expires_in']/2)
            token['expiration'] = datetime.datetime.timestamp(expiration)
            with open(citokenfile, 'w') as f:
                try: f.write(base64encode(json.dumps(token)))
                except: json.dump(token, f)
            self.token = 'bearer ' + token['access_token']
            return self.token
        raise Exception('generate token failed: ' + str(res.status_code))

    # def createAsset(self, filename, filesize, wsid, folderid, ingest=None):
    #     url = self.options['api_url'] + '/assets'
    #     headers = {
    #         'Authorization': self.token
    #     }
    #     payload = {
    #         'name': filename,
    #         'size': filesize,
    #         'workspaceId': wsid,
    #         'folderId': folderid
    #     }
    #     logger.info(payload)
    #     if ingest:
    #         payload['ingestConfiguration'] = ingest
    #     res = requests.post(url, json=payload, headers=headers)
    #     if res.status_code == 200:
    #         return res.json()['assetId']
    #     raise Exception('create asset failed: ' + str(res.json()))

    def updateAsset(self, assetid, updateinfo):
        url = self.options['api_url'] + '/assets/' + assetid
        headers = {
            'Authorization': self.token
        }
        payload = updateinfo
        res = requests.put(url, json=payload, headers=headers)
        if res.status_code == 201 or res.status_code == 200:
            return res.json()
        raise Exception('create asset failed: ' + str(res.json()))

    def getAsset(self, assetid):
        url = self.options['api_url'] + '/assets/' + assetid
        headers = {
            'Authorization': self.token
        }
        res = requests.get(url, headers=headers)
        if res.status_code == 200:
            return res.json()
        raise Exception('get asset failed: ' + str(res.json()))

    def uploadSingle(self, file, wsid, folderid, ingest=None):
        # url = self.options['io_url'] + '/assets/' + assetid + '/upload'
        url = self.options['io_url'] + '/upload'
        files = {'filename': (file, open(file, 'rb').read())}
        headers = {'Authorization': self.token}
        payload = {
            'name': os.path.basename(file),
            'size': os.path.getsize(file),
            'workspaceId': wsid,
            'folderId': folderid
        }
        if ingest:
            payload['ingestConfiguration'] = ingest

        retries = 0
        err_msg = None
        while retries < self.__max_retries:
            retries += 1
            try:
                res = requests.post(url, files=files, json=payload, headers=headers)
                res.raise_for_status()
                return res.json()['assetId']
            except Exception as err:
                logger.error(str(err))
                err_msg = str(err)
            time.sleep(10)
        raise Exception('upload failed: ' + err_msg)

    def initUploadMultipart(self, file, upload_size, wsid, folderid, ingest=None):
        logger.info('Init multi part Ci uploading ...')
        # url = self.options['io_url'] + '/assets/'+assetid+'/upload/multipart'
        url = self.options['io_url'] + '/upload/multipart'
        headers = {'Authorization': self.token}
        payload = {
            'name': os.path.basename(file),
            'size': os.path.getsize(file),
            'workspaceId': wsid,
            'folderId': folderid,
            "UploadMethod": "DirectToCloud",
            "PartSize": upload_size
        }
        if ingest:
            payload['ingestConfiguration'] = ingest

        res = requests.post(url, json=payload, headers=headers)
        res.raise_for_status()
        data = res.json()
        return data['assetId'], data['partCount']

    def getUploadMultipartBatch(self, asset_id, part_numbers):
        logger.info(f'Get multi part batch ... {part_numbers}')
        url = self.options['io_url'] + f'/upload/multipart/{asset_id}/batch'
        headers = {'Authorization': self.token}
        res = requests.post(url, headers=headers, json={"partNumbers": part_numbers})
        res.raise_for_status()
        return res.json()

    def uploadPart(self, upload_url, file_chunk):
        logger.info(f'Start uploading part ... {upload_url}')
        # headers = {'Authorization': self.token}
        retries = 0
        while retries < self.__max_retries:
            retries += 1
            try:
                res = requests.put(upload_url, data=file_chunk)
                res.raise_for_status()
                return True
            except Exception as err:
                logger.error(str(err))
            time.sleep(10)
        return False
    
    def completeUploadBatch(self, asset_id, part_numbers):
        logger.info(f'Completing upload multipart batch ... {asset_id} / {part_numbers}')
        url = self.options['io_url'] + f'/upload/multipart/{asset_id}/batch/complete'
        headers = {'Authorization': self.token}
        parts = [{"partNumber": part_number} for part_number in part_numbers]
        res = requests.post(url, headers=headers, json={
            "parts": parts
        })
        res.raise_for_status()
        return res.json()

    def completeUploadMultipart(self, asset_id):
        logger.info(f'Completing upload multipart ... {asset_id}')
        url = self.options['io_url'] + f'/upload/multipart/{asset_id}/complete'
        headers = {'Authorization': self.token}
        res = requests.post(url, headers=headers)
        if res.status_code == 200:
            logger.info('completed upload multipart')
            return True
        err = f'code: {res.status_code} - err: {res.json()}'
        raise Exception('signal complete upload multipart failed: ' + err)

    def deleteAsset(self, assetid):
        logger.info('deleting asset ... ' + assetid)
        url = self.options['api_url'] + '/assets/'+assetid
        headers = {'Authorization': self.token}
        res = requests.delete(url, headers=headers)
        if res.status_code == 200:
            logger.info('deleted asset')
            return True
        err = f'code: {res.status_code} - err: {res.json()}'
        raise Exception('cannot delete asset: ' + err)

    def getOrCreateFolderByPath(self, wsid, rootfolderid, folderpath):
        if not rootfolderid:
            rootfolderid = self.getWorkspaceRootFolder(wsid)
        if not rootfolderid:
            raise Exception('cannot get root folder id for ws: ' + wsid)
        parentid = rootfolderid
        for foldername in folderpath.replace('\\', '/').split('/'):
            if not foldername:
                continue
            folderid = self.getFolderIdByName(parentid, foldername)
            if not folderid:
                folderid = self.createFolder(wsid, parentid, foldername)
            if not folderid:
                raise Exception('cannot get/create folder')
            parentid = folderid
        return parentid

    def getWorkspaceRootFolder(self, wsid):
        url = self.options['api_url'] + '/workspaces/'+wsid
        headers = {'Authorization': self.token}
        res = requests.get(url, headers=headers)
        if res.status_code == 200:
            folderid = res.json()['rootFolderId']
            logger.info('root folderid: ' + folderid)
            return folderid
        err = f'code: {res.status_code} - err: {res.json()}'
        raise Exception('cannot get root folder info: ' + err)

    def getFolderIdByName(self, parentid, foldername):
        url = self.options['api_url'] + '/folders/' + parentid + '/contents'
        headers = {'Authorization': self.token}
        offset = 0
        limit = 100
        while True:
            payload = {
                'offset': offset,
                'kind': 'folder',
                'limit': limit,
                'fields': 'parentId'
            }
            res = requests.get(url, params=payload, headers=headers)
            if res.status_code == 200:
                result = res.json()
                logger.info(result['offset'])
                logger.info(result['count'])
                for folder in result['items']:
                    logger.info(folder['name'])
                    if folder['name'] == foldername:
                        logger.info('found folderid: ' + folder['id'])
                        return folder['id']
                if result['count'] > offset + limit:
                    offset += limit
                else:
                    break
            else:
                raise Exception(f'code: {res.status_code} - err: {res.text}')
        logger.info('folder not found: ' + foldername)
        return None

    def getFolder(self, folderid):
        url = self.options['api_url'] + '/folders/' + folderid
        headers = {'Authorization': self.token}
        res = requests.get(url, headers=headers)
        if res.status_code == 200:
            return res.json()
        err = f'code: {res.status_code} - err: {res.json()}'
        raise Exception('cannot get folder: ' + err)

    def createFolder(self, wsid, parentid, foldername):
        url = self.options['api_url'] + '/folders/'
        headers = {'Authorization': self.token}
        payload = {
            'name': foldername,
            'workspaceId': wsid,
            'parentFolderId': parentid
        }
        res = requests.post(url, json=payload, headers=headers)
        if res.status_code == 200:
            folderid = res.json()['folderId']
            logger.info('created folderid: ' + folderid)
            return folderid
        err = f'code: {res.status_code} - err: {res.json()}'
        raise Exception('cannot create folder: ' + err)

    def createWorkSessionJson(self, job):
        return self.createWorkSession(job.get('title'),job.get('assetIds'),job.get('recipients'),job.get('appname'),job.get('dueDays'))

    def createWorkSession(self, title, assetIds, recipients, appname='VideoReview', dueDays=182):
        logger.info('creating work session ...')
        url = self.options['api_url'] + '/worksessions'
        headers = {'Authorization': self.token}
        if not assetIds: assetIds = []
        if not recipients:
            raise Exception('invalid recipients')
        payload = {
            'assetIds': assetIds,
            'appName': appname,
            'dueDate': str(datetime.datetime.now() + datetime.timedelta(days=dueDays)),
            'goal': '',
            'name': title,
            'users': recipients,
            'status': 'Active'
        }
        logger.info(payload)
        res = requests.post(url, json=payload, headers=headers)
        if res.status_code == 200:
            worksession = res.json()
            logger.info('created worksession: ' + worksession['link'])
            return worksession
        err = f'code: {res.status_code} - err: {res.json()}'
        raise Exception('cannot create work session: ' + err)

    def checkMediaBoxForFolder(self, wsid, folderid):
        logger.info('check mediabox ...')
        url = self.options['api_url'] + '/workspaces/'+wsid+'/mediaboxes'
        headers = {'Authorization': self.token}
        payload = {
            'orderBy':'expiresOn',
            'orderDirection': 'desc',
            'status':'active',
            'fields':'folders,assets,name,expiresOn,link',
            'offset': 0
        }
        mediabox = {}
        retry = 0
        while not mediabox and retry<5:
            logger.info(payload)
            res = requests.get(url, json=payload, headers=headers)
            if res.status_code == 200:
                result = res.json()
                for mbox in result['items']:
                    if len(mbox['folders']) == 1 and folderid in mbox['folders'] and len(mbox['assets']) == 0:
                        logger.info('found existing mediabox: ' + mbox['link'])
                        return mbox
                payload['offset'] += len(result['items'])
                if payload['offset'] >= result['count']:
                    break
            else:
                retry+=1
            time.sleep(2)
        
        logger.info('mediabox not found')
        return mediabox

    def createMediaBoxJson(self, job):
        return self.createMediaBox(job.get('name'),job.get('message'),job.get('assetIds'),job.get('folderIds'),job.get('recipients'),job.get('downloadable'), job.get('dueDays'))

    def createMediaBox(self, name, message, assetIds, folderIds, recipients, downloadable, dueDays=3):
        logger.info('creating mediabox ...')
        if not assetIds: assetIds = []
        if not folderIds: folderIds = []
        if not recipients:
            raise Exception('invalid recipients')
        url = self.options['api_url'] + '/mediaboxes'
        headers = {'Authorization': self.token}
        payload = {
                "name": name,
                "assetIds": assetIds,
                "folderIds": folderIds,
                "type": "Secure",
                "allowSourceDownload": downloadable,
                "recipients": recipients,
                "message": message,
                "expirationDays": dueDays,
                #"expirationDate": "",
                "sendNotifications": True,
                "notifyOnOpen": True,
                "notifyOnChange": True,
                "watermarking": {
                    "text": "{username}(IP: {ip-address})\r\n{datestamp}",
                    "opacity": 0.15,
                    "verticalPosition": 0.5
                }
            }
        logger.info(payload)
        res = requests.post(url, json=payload, headers=headers)
        if res.status_code == 200:
            mediabox = res.json()
            logger.info('created mediabox: ' + mediabox['link'])
            return mediabox
        err = f'code: {res.status_code} - err: {res.json()}'
        raise Exception('cannot create media box: ' + err)

    def createPlayback(self, name, assetId, streamtypes, expire=None):
        logger.info('creating playback stream ...')
        if not streamtypes:
            raise Exception('invalid streamtypes')
        url = self.options['api_url'] + '/assets/' + assetId + '/streams'
        headers = {'Authorization': self.token}
        if not expire:
            dt = datetime.date.today() + datetime.timedelta(days=3)
            expire = dt.isoformat()
        payload = {
            "streams": [{
                "name": name,
                "expirationDate": expire,
                "videoSources": []
            }]
        }
        for t in streamtypes:
            if t not in ['sd', '3g', 'sdplus', 'hd', '2k', '2kplus']:
                raise Exception('invalid stream type')
            payload['streams'][0]['videoSources'].append({
                "type": 'video-' + t,
                "displayName": name + ' ' + t
            })

        logger.info(payload)
        res = requests.post(url, json=payload, headers=headers)
        if res.status_code == 200:
            playback = res.json()
            logger.info('created playback: ' + name)
            return playback
        err = f'code: {res.status_code} - err: {res.json()}'
        raise Exception('cannot create playback: ' + err)

    def createJobs(self, name, assetId, streamtypes, expire=None):
        logger.info('creating playback stream ...')
        if not streamtypes:
            raise Exception('invalid streamtypes')
        url = self.options['api_url'] + '/assets/' + assetId + '/jobs'
        headers = {'Authorization': self.token}
        if not expire:
            dt = datetime.date.today() + datetime.timedelta(days=3)
            expire = dt.isoformat()
        payload = {
            "streams": [{
                "name": name,
                "expirationDate": expire,
                "videoSources": []
            }]
        }
        for t in streamtypes:
            if t not in ['sd', '3g', 'sdplus', 'hd', '2k', '2kplus']:
                raise Exception('invalid stream type')
            payload['streams'][0]['videoSources'].append({
                "type": 'video-' + t,
                "displayName": name + ' ' + t
            })

        logger.info(payload)
        res = requests.post(url, json=payload, headers=headers)
        if res.status_code == 200:
            playback = res.json()
            logger.info('created playback: ' + name)
            return playback
        err = f'code: {res.status_code} - err: {res.json()}'
        raise Exception('cannot create playback: ' + err)


### end ###


if __name__ == '__main__':
    try:
        DEBUG = True
        
        # job = {'file': '/Users/thanh.ho/Documents/Projects/_test_assets/meridian_30sec_120s_start_api_tho1.m4a', 'wsid': '2e9a9c0c0e3844e1a86ceecdb503b030', 'rootfolderid': '071cd62cd54d444796cf550939e16908', 'folderpath': 'QB-117115_00066708', 'folderid': '47273a5384e740d387ae3fca0932afb1', 'filename': 'test.mxf', 'assetid': 'ff41147833c446cab9a1f737edb6150f'}

        # job = {'file': '/mnt/PXL-MPFS01/MOT-DDM/02_iTunes_Projects/Warner Brothers/B/BEETLEJUICE BEETLEJUICE/Delivery/QC/QB-117115.itmsp_2024-10-09_09-24-32/WB_BEETLEJUICE_BEETLEJUICE_TH_ASL_HD_ASL_FEATURE_EN_51_EN_20_STEREO_FORCED_EN_16X9_185_1920X1080_2398_4KQU21000000TK_EN_CC_00066706.MP4', 'wsid': '2e9a9c0c0e3844e1a86ceecdb503b030', 'rootfolderid': '071cd62cd54d444796cf550939e16908', 'folderpath': 'QB-117115_00066708', 'folderid': '47273a5384e740d387ae3fca0932afb1', 'filename': 'test.mxf', 'assetid': 'ff41147833c446cab9a1f737edb6150f'}
        # res = CI({}).deliver(job)
        CI()
    except Exception as err:
        print(err)