from __future__ import absolute_import
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from email.utils import COMMASPACE, formatdate
import os, sys, re, io, zipfile

from .logger import Logger

class Email:
    __log = Logger('Email')
    __adminEmails = 'automation.service@pixelogicmedia.com'
    __fromemail = 'noreply@pixelogicmedia.com'
    __debug = False

    __max_attachment_size = 7 * 1024 * 1024

    def setDebug(self, val = None):
        if val:
            self.__debug = val
        else:
            self.__debug = True
    
    # def send(self, toemails, subject, content, attachment=None):
    #     for to in self.__parseEmails(toemails):
    #         self.__send1(to, subject, content, attachment)

    @staticmethod
    def __compress_attachment(filename, content):
        attachment_bytes = content if isinstance(content, bytes) else content.encode('utf-8')
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.writestr(filename, attachment_bytes)
        return buf.getvalue()

    def send(self, toemails, subject, content, attachment=None, ccemails=None):
        self.__log.info(toemails)
        self.__log.info(subject)
        self.__log.info(content)
        if not toemails:
            toemails = self.__adminEmails
        try:
            # Create the message
            msg = MIMEMultipart()
            msg['Subject'] = subject
            msg['To'] = self.__parseEmails(toemails)
            msg['From'] = self.__fromemail
            if ccemails:
                self.__log.info('### HAS CC EMAILS ###')
                msg['Cc'] = self.__parseEmails(ccemails)
            msg.attach(MIMEText(content, 'html'))
            if attachment:
                filename = ''
                attachment_content = None
                if isinstance(attachment, dict):
                    filename = attachment['filename']
                    attachment_content = str(attachment['content']).encode('utf-8') if not isinstance(attachment['content'], bytes) else attachment['content']
                elif isinstance(attachment, str):
                    if not os.path.isfile(attachment):
                        raise Exception('File not found ... ' + attachment)
                    filename = os.path.basename(attachment)
                    attachment_content = open(attachment, "rb").read()
                else:
                    raise Exception('Invalid attachment ... ' + str(attachment))
                p = MIMEBase('application', 'octet-stream')
                if len(attachment_content) > self.__max_attachment_size:
                    attachment_content = self.__compress_attachment(filename, attachment_content)
                    filename += '.zip'
                p.set_payload(attachment_content)
                encoders.encode_base64(p)
                p.add_header('Content-Disposition', "attachment; filename= %s" % filename) 
                msg.attach(p)
                
            if self.__debug:
                print ('[DEBUG] email sent:')
                print (msg)
            else:
                server = smtplib.SMTP('10.100.170.252', 25)
                # server = smtplib.SMTP('smtp.office365.com', 587)
                # server.starttls()
                # server.login('smtp@pixelogicmedia.com', 'D3faultpassword')
                result = server.send_message(msg)
                server.quit()
                
            self.__log.info('### Sent ###')
            return result
        except Exception as err:
            self.__log.error('### Sending Failed ###')
            self.__log.error(err)
            return {'err': str(err)}

    def send_info(self, toemails, subject, content, attachment):
        return self.send(toemails, '[PXL] ' + subject, content, attachment)

    def send_failure(self, toemails, subject, content, attachment):
        return self.send(toemails, '[FAILURE] ' + subject, content, attachment)

    def send_success(self, toemails, subject, content, attachment):
        return self.send(toemails, '[SUCCESS] ' + subject, content, attachment)

    def __parseEmails(self, emails):
        if isinstance(emails, list):
            return COMMASPACE.join(emails)
        result = []
        for em in re.split('[,;\\s]', emails):
            if em:
                result.append(em)
        return COMMASPACE.join(result)

def send_email_withcc(toemails, ccemails, subject, content, attachment=None):
    em = Email()
    return em.send(toemails, subject, content, attachment, ccemails)

def send_email(toemails, subject, content, attachment=None):
    em = Email()
    return em.send(toemails, subject, content, attachment)

def send_info_email(toemails, subject, content, attachment):
    em = Email()
    return em.send_info(toemails, subject, content, attachment)

def send_failure_email(toemails, subject, content, attachment):
    em = Email()
    return em.send_failure(toemails, subject, content, attachment)

def send_success_email(toemails, subject, content, attachment):
    em = Email()
    return em.send_success(toemails, subject, content, attachment)


if __name__ == '__main__':
    if sys.argv[1] != 'debug':
        print('For debug only')
        sys.exit(0)
    print('### Testing Email ###')
    toemails = 'thanh.ho@pixelogicmedia.com'
    send_email(toemails, 'test', 'test', {'filename': 'test.txt', 'content': 'test content'})

### end email ###
