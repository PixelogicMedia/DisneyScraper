"""
using s3_wrapper (support assume role) if possible, migrating to new class
"""

import boto3, os
from botocore.exceptions import ClientError
from multiprocessing import Pool
from multiprocessing.pool import ThreadPool
import argparse, json, time

from .boto3_wrapper import Boto3Wrapper
from .logger import Logger

log = Logger('aws_s3')
total_upload = 0
finished_upload = 0

def __s3_path_split(s3_path):
    bucket = s3_path.split('s3://')[-1].split('/')[0]
    key = s3_path.split(f'{bucket}/', 1)[-1]
    return bucket, key

def __s3_path_combine(s3_bucket, s3_key):
    return f"s3://{s3_bucket}/{s3_key}"

# detect s3 return result matching on-prem response
def path_detection(path, options = {}):
    bucket, key = __s3_path_split(path)
    is_folder = False
    is_exist = False
    if s3_path_exists(bucket, key.rstrip('/') + '/'):
        log.debug('is folder')
        is_folder = True
        is_exist = True
    elif s3_path_exists(bucket, key):
        log.debug('is file')
        is_folder = False
        is_exist = True
    if is_folder:
        key = key.rstrip('/') + '/'
    s3_full = f"s3://{bucket}/{key}"
    result = {
            "exist": is_exist,
            "listdir": [ s.replace(s3_full, '') for s in list_s3_files(bucket, key, True) ] if is_folder else [],
            "location": "s3",
            "mnt": f"/mnt/{bucket}/",
            "mnt_full": f"/mnt/{bucket}/{key}",
            "originalpath": path,
            "relativepath": key,
            "s3": f"s3://{bucket}/",
            "s3_full": s3_full,
            "type": "folder" if is_folder else "file",
            "unc": f"//{bucket}/",
            "unc_full": f"//{bucket}/{key}",
            "vidispine": "",
            "volumes": f"/Volumes/{bucket}/",
            "volumes_full": f"/Volumes/{bucket}/{key}"
        }
    return [ result ]

def s3_file_size_by_path(s3_path):
    return s3_file_size(*__s3_path_split(s3_path))

def s3_file_size(bucket, key):
    s3 = boto3.client('s3')
    response = s3.head_object(Bucket=bucket, Key=key)
    size = response['ContentLength']
    return size

def s3_path_exists_by_path(s3_path):
    return s3_path_exists(*__s3_path_split(s3_path))

def s3_path_exists(bucket_name, key):
    log.debug(bucket_name)
    log.debug(key)
    s3 = boto3.client('s3')
    try:
        res = s3.head_object(Bucket=bucket_name, Key=key)
        log.debug(res)
        return True
    except ClientError as e:
        log.debug(e)
        # If a client error is thrown, then check that it was a 404 error.
        # If it was a 404 error, then the object does not exist.
        error_code = int(e.response['Error']['Code'])
        if error_code == 404:
            return False
        else:
            raise

def create_s3_file(bucket_name, s3_key, content):
    s3 = boto3.resource('s3')
    s3.Object(bucket_name, s3_key).put(Body=content)
    return f"s3://{bucket_name}/{s3_key}"

def upload_s3_files(path, s3_bucket, s3_path):
    """
    Upload a file or contents of a directory to a specific s3 directory
    Args:
        path: file/folder path
        s3_bucket: s3 bucket
        s3_path: path to destination s3 folder
    """
    session = boto3.Session()
    s3 = session.resource('s3')

    pool = ThreadPool(4)
    data = []

    if os.path.isfile(path):
        #print(path)
        data.append((s3,s3_bucket,path, os.path.dirname(path), s3_path))
    else: 
        for subdir, dirs, files in os.walk(path):
            for file in files:
                #print(file)
                full_path = os.path.join(subdir, file)
                data.append((s3,s3_bucket, full_path, path, s3_path))
            
    global total_upload, finished_upload
    total_upload = len(data)
    log.info(f'total files: {total_upload}')
    finished_upload = 0
    pool.starmap(upload_file, data)
    pool.close()
    pool.join()

    return s3_bucket, os.path.join(s3_path, os.path.basename(path))

def upload_file(s3, s3_bucket,full_path, path, s3_path):
    global finished_upload
    retries = 5
    success = False
    retry_interval = 60
    while retries > 0 and success == False:
        try:
            s3.meta.client.upload_file(Bucket=s3_bucket,Key=s3_path + '/' + full_path[len(path)+1:], Filename=full_path)
            success = True
            break
        except Exception as e:
            log.exception(e)
        time.sleep(retry_interval)
        retries -= 1
    
    if not success:
        raise Exception(f'Failed to upload {full_path} to {s3_path}')
    finished_upload += 1
    log.info(f'finished upload: {full_path} to {s3_path} - {finished_upload}/{total_upload}')

def download_s3_files(bucket_name, s3_path, local_dir=None):
    """
    Download the contents of a folder directory
    Args:
        bucket_name: the name of the s3 bucket
        s3_path: the file/folder path in the s3 bucket
        local_dir: a relative or absolute directory path in the local file system
    """
    session = boto3.Session()
    s3 = session.resource('s3')
    bucket = s3.Bucket(bucket_name)

    pool = ThreadPool(4)
    data = []

    downloaded_paths = []

    for obj in bucket.objects.filter(Prefix=s3_path):
        #print(obj.key)
        relpath = os.path.relpath(obj.key, s3_path)
        if relpath == '.': relpath = os.path.basename(s3_path)
        else: relpath = os.path.dirname(relpath)
        target = obj.key if local_dir is None \
            else os.path.join(local_dir, relpath)
        #print(target)
        if not os.path.exists(os.path.dirname(target)):
            os.makedirs(os.path.dirname(target))
        if obj.key[-1] == '/':
            continue
        downloaded_paths.append(target)
        data.append((bucket, obj.key, target))

    pool.starmap(download_file, data)
    pool.close()
    pool.join()

    return downloaded_paths

def download_file(bucket, key, target):
    bucket.download_file(key, target)

def get_presigned_s3_path(bucket_name, s3_path, expiration=3600):
    """
    Generate a presigned URL for a file in the s3 bucket
    Args:
        bucket_name: the name of the s3 bucket
        s3_path: the file path in the s3 bucket
        expiration: the time in seconds for the presigned URL to expire
    """
    session = boto3.Session()
    s3 = session.client('s3')
    url = s3.generate_presigned_url('get_object',
                                    Params={'Bucket': bucket_name, 'Key': s3_path},
                                    ExpiresIn=expiration)
    return url

def get_presigned_s3_full_path(s3_full_path, expiration=3600):
    bucket_name = s3_full_path.split('s3://')[-1].split('/')[0]
    s3_path = s3_full_path.split('s3://')[-1].split('/', 1)[-1]
    return get_presigned_s3_path(bucket_name, s3_path, expiration)


def get_s3_info(s3_path):
    s3_bucket_name, s3_key_path = s3_path.split('://')[-1].split('/',1)
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(s3_bucket_name)
    s3_key_paths = [obj.key for obj in bucket.objects.filter(Prefix=s3_key_path)]
    return s3_key_paths

def list_s3_files_by_path(s3_path, toplevel=False):
    return list_s3_files(*__s3_path_split(s3_path), toplevel)

def list_s3_files(bucket_name, prefix, toplevel=False):
    s3 = boto3.client('s3')

    continuation_token = None
    objs = []
    while True:
        list_params = {
            'Bucket': bucket_name,
            'Prefix': prefix
        }
        if toplevel:
            list_params['Delimiter'] = '/'
        if continuation_token:
            list_params['ContinuationToken'] = continuation_token
        
        response = s3.list_objects_v2(**list_params)
        
        if 'Contents' in response:
            # might have to check for .j2c with a loop
            objs += response['Contents']

        if 'CommonPrefixes' in response:
            objs += [{'Key': prefix['Prefix']} for prefix in response['CommonPrefixes']]
        
        # if there are more than 1000 objects in response
        if response.get('IsTruncated'): 
            continuation_token = response.get('NextContinuationToken')
        else:
            break
    
    return [f"s3://{bucket_name}/{obj['Key']}" for obj in objs if obj['Key'].rstrip('/') != prefix]

def s3_copy(s3_src, s3_dst):
    s3 = boto3.client('s3')
    src_bucket, src_key = __s3_path_split(s3_src)
    copy_source = {
        'Bucket': src_bucket,
        'Key': src_key
    }
    dst_bucket, dst_key = __s3_path_split(s3_dst)
    s3.copy(copy_source, dst_bucket, dst_key)

def get_bucket_region(bucket_name):
    s3 = boto3.client('s3')
    location = s3.get_bucket_location(Bucket=bucket_name)
    # For US East (N. Virginia) region, 'LocationConstraint' is None
    return location['LocationConstraint'] or 'us-east-1'

### deprecated, use boto3_wrapper instead
def call_state_machine(state_machine_arn, payload):
    return Boto3Wrapper().call_state_machine(state_machine_arn, payload)




if __name__ == "__main__":
    
    # res = path_detection('s3://pixelogic-paramount-bulk-ingest-dev/TMNC_IntlD_185_LB_tl_xyz_tiff/1998x1080')
    # res = s3_path_exists_by_path('s3://pixelogic-paramount-bulk-ingest-dev/Argylle_TrlD_240_Txtlss_DCDM_tiff')    
    # log.info(json.dumps(res))
    
    res = path_detection('s3://pixelogic-localization/tmp')
    
    log.info(json.dumps(res))

