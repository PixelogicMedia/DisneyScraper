from __future__ import absolute_import
import os, json, shutil, time, sys
import lxml
import lxml.etree
import pymediainfo
from pathlib import Path

class MediaInfoWrapper:
    def getIsDropframe(self, input:str):
        if input is None:
            return False
        tcTrack = None
        ext = os.path.splitext(input)[-1].lower()
        if ext in ['.mov', '.mp4']:
            if os.path.exists(input):
                try:
                    media_info = pymediainfo.MediaInfo.parse(input)                          
                    item = list(filter(lambda x: x.track_type == 'Other' and x.type == 'Time code', media_info.tracks))
                    if(len(item) > 0):
                        tcTrack = item[0].time_code_of_first_frame
                except: pass
        if ext in ['.xml']:
            videofile = self.getVideoFromXML(input)
            if videofile and os.path.join(os.path.dirname(input), videofile):
                fullpath = os.path.join(os.path.dirname(input), videofile)
                if os.path.exists(fullpath):
                    try:
                        media_info = pymediainfo.MediaInfo.parse(fullpath)          
                        item = list(filter(lambda x: x.track_type == 'Other' and x.type == 'Time code', media_info.tracks))
                        if(len(item) > 0):
                            tcTrack = item[0].time_code_of_first_frame
                    except: pass     

        print(f"{input} tcTrack is {str(tcTrack)} returned value is {str(tcTrack and ';' in tcTrack)}")           
        return tcTrack and ';' in tcTrack

    def getVideoFromXML(self, input:str):
        parser = lxml.etree.XMLParser(ns_clean=True)
        tree = lxml.etree.parse(input, parser) 
        root = tree.getroot()    
        nsmap = root.nsmap
        for elem in root.findall(f'.//{{{nsmap[None]}}}SegmentList//{{{nsmap[None]}}}Segment//{{{nsmap[None]}}}SequenceList'):
                for sequence in elem:
                    if 'MainImageSequence' in sequence.tag:
                        for annotation in sequence.findall(f'.//{{{nsmap[None]}}}ResourceList//{{{nsmap[None]}}}Resource//{{{nsmap[None]}}}Annotation'):
                            return annotation.text
        return None


    def getFrameRate(self, input:str):
        if input is None:
            return True

        framerate = '23'
        if input.lower().endswith('.mov'):
            if os.path.exists(input):
                try:
                    media_info = pymediainfo.MediaInfo.parse(input)    
                    item = list(filter(lambda x: x.track_type == 'Video',  media_info.tracks))  
                    framerate = item[0].frame_rate.lower()
                except: pass                
        if input.lower().endswith('.xml'):
            videofile = self.getVideoFromXML(input)
            if videofile and os.path.join(os.path.dirname(input), videofile):
                fullpath = os.path.join(os.path.dirname(input), videofile)
                if os.path.exists(fullpath):
                    try:
                        media_info = pymediainfo.MediaInfo.parse(fullpath)          
                        item = list(filter(lambda x: x.track_type == 'Video',  media_info.tracks))  
                        framerate = item[0].frame_rate.lower()
                    except: pass 
        return framerate              

    def getIsFractionalFrameRate(self, input:str):
        framerate = self.getFrameRate(input)
        if '23' in framerate:
            return True
        if '29' in framerate:
            return True
        if '59' in framerate:
            return True
        return False
    
    def getColorSpaceOfAsset(input:str):
        ext = os.path.splitext(input)[-1].lower()
        if ext == '.mp4':
            return "RGB"
        if ext == '.mov':
            if os.path.exists(input):
                try:
                    media_info = pymediainfo.MediaInfo.parse(input)          
                    item = list(filter(lambda x: x.track_type == 'Video',  media_info.tracks))  
                    return item[0].color_primaries.lower()
                except: return "RGB"                
        if ext == '.xml':
            videofile = self.getVideoFromXML(input)
            if videofile and os.path.join(os.path.dirname(input), videofile):
                fullpath = os.path.join(os.path.dirname(input), videofile)
                if os.path.exists(fullpath):
                    try:
                        media_info = pymediainfo.MediaInfo.parse(fullpath)          
                        item = list(filter(lambda x: x.track_type == 'Video',  media_info.tracks))  
                        return item[0].color_primaries.lower()
                    except: return "RGB"                
        return None

    def isVideoAssetUncompressedMXF(videoasset: str):
        print(f'Checking if {videoasset} is uncompressed')

        try:
            media_info = pymediainfo.MediaInfo.parse(videoasset)      
            item = list(filter(lambda x: x.track_type == 'Video',  media_info.tracks))  
            print(str(item[0].codec_id))
            return item[0].codec_id == '0D010301020C0600-0401020203010614'
        except: return False                
        

    def getVideoAsset(assetname:str):
        ext = os.path.splitext(assetname)[-1].lower()
        if ext in ['.mov', '.mp4']:
            if os.path.exists(assetname):
                try:
                    media_info = pymediainfo.MediaInfo.parse(assetname)          
                    item = list(filter(lambda x: x.track_type == 'Video',  media_info.tracks))  
                    return assetname if len(item) > 0 else None
                except: pass                
        if ext == '.xml':
            videofile = self.getVideoFromXML(assetname)
            if videofile and os.path.join(os.path.dirname(assetname), videofile):
                fullpath = os.path.join(os.path.dirname(assetname), videofile)
                if os.path.exists(fullpath):
                    try:
                        media_info = pymediainfo.MediaInfo.parse(fullpath)          
                        item = list(filter(lambda x: x.track_type == 'Video',  media_info.tracks))  
                        return fullpath if len(item) > 0 else None
                    except: pass                
        return None