from __future__ import absolute_import

import requests, copy, os, time, time
from urllib.parse import urlencode

from .sso import getSSOToken

sec={}
try:
    from ..secrets.service_setup import om_sso_client_id as client_id, om_sso_client_secret as client_secret, vidispine_base_url as base_url
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    client_id = sec.get('sso_client_id') or os.getenv('SSO_CLIENT_ID') or ''
    client_secret = sec.get('sso_client_secret') or os.getenv('SSO_CLIENT_SECRET') or ''
    base_url = sec.get('vidispine_base_url') or os.getenv('VIDISPINE_BASE_URL') or ''

from .logger import Logger

log = Logger('vidispine')

default_options = {
    # https://vidispine-api.pixelogicmedia.com
    'base_url': base_url,
    
    'sso_opt': {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
    },

    'polling_time': 10,
    'timeout': 3600,

}

class VidispineWrapper:
    def __init__(self, opts=None):
        self.options = copy.deepcopy(default_options)
        if opts: self.options.update(opts)
        self.__base_url = self.options['base_url']
        self.__access_token = ''
        self.__token_expiration = None
        self.__refresh_headers()
    
    def __refresh_headers(self):
        if not self.__access_token or time.time() > self.__token_expiration:
            token_data = getSSOToken(self.options['sso_opt'])
            self.__token_expiration = time.time() + token_data['expires_in'] - 10
            self.__access_token = token_data['access_token']

        return {
            'Authorization': 'Bearer ' + self.__access_token,
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

    def __api_url(self, path, query_params=''):
        if not path.startswith(self.__base_url):
            path = self.__base_url.strip('/') + '/' + path.lstrip('/')
        path = path.replace('/API/API/', '/API/')
        
        if type(query_params) == dict:
            query_params = urlencode({k:v for k,v in query_params.items() if v})
        query_params = '' if not query_params else f"?{query_params.strip('?')}"

        return path.lstrip('/') + query_params

    # general API call

    def call_api(self, url, method='GET', data=None, query_params=None, headers={}):
        log.debug(f"Calling OM API [{method}] {url} with data: {data} and query_params: {query_params}")
        if query_params or not url.startswith(self.__base_url):
            url = self.__api_url(url, query_params)
        headers.update(self.__refresh_headers())
        if type(data) in [dict, list] and 'Content-Type' not in headers:
            response = requests.request(method, self.__api_url(url), headers=headers, json=data)
        else:
            response = requests.request(method, self.__api_url(url), headers=headers, data=data)
        log.debug(f"OM API response: {response.status_code} / {response.content}")
        response.raise_for_status()
        try: return response.json()
        except: return response.content

    def get_api(self, url, query_params=None, headers={}):
        return self.call_api(url, query_params=query_params, headers=headers)

    def post_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='POST', data=data, query_params=query_params, headers=headers)

    def put_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='PUT', data=data, query_params=query_params, headers=headers)
    

    def poll_vidispine(self, vx_job_id) -> dict:
        start_time = time.time()
        timeout = start_time + (self.options.get('timeout') or 300)
        retry = 20
        while True:
            result = self.get_api(f"/API/job/{vx_job_id}")
            status = result.get('status') or ''
            log.debug(f"Vidispine Job [{vx_job_id}] {status}.")
            if status in ['FINISHED']:
                return result
            if status in ['FAILED_TOTAL', 'ABORTED']:
                raise Exception(f"Vidispine Job [{vx_job_id}] {status}. {result}")
        
            if timeout < time.time():
                raise Exception(f"Vidispine Job [{vx_job_id}] timeout. {result}")
        
            time.sleep(self.options.get('polling_time') or 5)


