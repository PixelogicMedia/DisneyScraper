import requests, copy, re, os, time

from .logger import Logger
from .misc import getHostNameIP
from .qm import QueueManager

try:
    from ..secrets.service_setup import faspex_user, faspex_apikey
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    
    faspex_user = sec.get('faspex_user') or os.getenv('faspex_user') or ''
    faspex_apikey = sec.get('faspex_apikey') or os.getenv('faspex_apikey') or ''




DEBUG = False


logger = Logger('faspex')

def fixEmails(emails):
    tmp = re.split(',|;| ', emails)
    return ','.join(filter(None, tmp))

class Faspex:
    options = {
        'baseurl': 'https://orchestrator.pixelogicmedia.com',
        'workflow_id': '191',
        'auth': {'login': faspex_user, 'api_key': faspex_apikey},
        
        'timeout': 3600, 
    }

    def __init__(self, opts):
        if opts:
            self.options.update(opts)
        if not self.options.get('baseurl') or not self.options.get('auth'):
            raise Exception('Invalid options')
        _, ip = getHostNameIP()
        if ip.startswith('10.200.'):
            self.__location = 'Motor'
        elif ip.startswith('10.110.'):
            self.__location = 'London'
        else:
            self.__location = 'Burbank'

    def delivery(self, job):
        filepath = job.get('file')
        if not filepath:
            raise Exception('Invalid file')
        filepath = QueueManager().get_exist_path_detection(filepath)['mnt_full']
        if not os.path.isfile(filepath):
            raise Exception('File not found')
        if not job.get('link_emails') or not job.get('pw_emails'):
            raise Exception('Invalid emails')

        if not job.get('sender'):
            job['sender'] = 'orchteam@pixelogicmedia.com'

        #send request
        job['request'] = self.requestFaspex(filepath, job['sender'], job['link_emails'], job['pw_emails'], job['title'], job['note'])
        logger.info(job)
        id = str(job['request']['work_order']['id'])
        job['url'] = self.options['baseurl'] + '/work_orders/' + id
        logger.info(job)

        #check
        status = self.checkFaspexResult(id)
        logger.info('status: ' + status['work_order']['status'])
        job['result'] = status
        logger.info(job)

        if job['result']['work_order']['status'] != 'Complete':
            raise Exception(str(job))

        return job

    def requestFaspex(self, filepath, sender, link_emails, pw_emails, title, note):
        logger.info('Requesting Faspex Anywhere (Orch) for ... ' + filepath)
        params = copy.deepcopy(self.options['auth'])
        params['external_parameters[Files_to_send]'] = filepath
        params['external_parameters[Sender_User]'] = fixEmails(sender)
        params['external_parameters[Recipient_List]'] = fixEmails(link_emails)
        params['external_parameters[Title_of_Package]'] = title
        params['external_parameters[Note]'] = note
        params['external_parameters[Client_Emails]'] = fixEmails(pw_emails)
        params['external_parameters[faspexLocation]'] = self.__location
        logger.info(params)
        
        count = 5
        err = 'unknown'
        while count>0:
            res = requests.get(self.options['baseurl'] + '/api/initiate/' + self.options['workflow_id'] + '.json', params=params, verify=False)
            if res.status_code == 200:
                return res.json()
            err = f'code: {res.status_code} - {str(res)}'
            count-=1
            time.sleep(10)
        raise Exception(err)

    def checkFaspexResult(self, id):
        logger.info('Checking status for ... ' + id)
        params = copy.deepcopy(self.options['auth'])
        url = self.options['baseurl'] + '/api/work_order_status/' + id + '.json'
        timeout = time.time() + 3600
        result = {}
        while timeout > time.time():
            time.sleep(30)
            res = requests.get(url, params=params, verify=False)
            if res.status_code == 200:
                result = res.json() 
                if result['work_order']['status'] in ['Failed', 'Error', 'Complete']:
                    return result
        raise Exception('delivery timeout')



### end ###
'''
djob = {"title": "TEST new faspex", "sender": "orchteam@pixelogicmedia.com", "link_emails": "thanh.ho@pixelogicmedia.com", "pw_emails": "thanh.ho@pixelogicmedia.com", "file": "/mnt/localization/Temp/Thanh/tessdata.zip","note": "TEST new faspex" }

faspex = Faspex(faspex_opts)
delivery = faspex.delivery(djob)

print(str(delivery))
'''
