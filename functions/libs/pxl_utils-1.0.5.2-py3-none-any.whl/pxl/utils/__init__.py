package_name = 'pxl-utils'
version = '1.0.5.2'


## secret value priority:
# 1. user input value (or from celery secrets module)
# 2. secret value from env SECRET_NAME
# 3. env value
# 4. default value

### set env for SSO and API

## SSO
# SSO_URL
# SSO_CLIENT_ID
# SSO_CLIENT_SECRET
# SSO_SCOPE
# SSO_USERNAME 
# SSO_PASSWORD

# AM_BASE_URL
# OM_BASE_URL
# VIDISPINE_BASE_URL
# COREDB_BASE_URL
# OM_API_TOKEN or X-API-TOKEN