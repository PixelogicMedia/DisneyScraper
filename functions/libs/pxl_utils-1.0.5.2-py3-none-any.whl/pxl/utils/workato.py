# Call Workato API
# sso role: TBD
# docs: https://app.workato.com/
# Dev url: N/A
# Staging url: N/A
# Production url: https://phelix-wapi.pixelogicmedia.com



import requests, copy, os
from urllib.parse import urlencode

sec={}
try:
    from ..secrets.service_setup import workato_api_token, workato_base_url as base_url
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    workato_api_token = sec.get('workato_api_token') or os.getenv('WORKATO_API_TOKEN') or ''
    base_url = sec.get('workato_base_url') or os.getenv('WORKATO_BASE_URL') or ''

from .logger import Logger

log = Logger('workato')

default_options = {
    'base_url': base_url,
    'api_token': workato_api_token,
    
    'admin_emails': 'automation.service@pixelogicmedia.com',

    'polling_time': 5,
    'timeout': 3600,

}

class Workato:
    
    def __init__(self, opts=None):
        self.options = copy.deepcopy(default_options)
        if opts: self.options.update(opts)
        self.__base_url = self.options['base_url']
        self.__api_token = self.options['api_token']
        self.__auth_headers = {
            'API-token': self.__api_token
            # "Authorization": "Bearer " + self.__api_token
        }
    
    def __api_url(self, path, query_params='') -> str:
        if not path.startswith(self.__base_url):
            path = self.__base_url.strip('/') + '/' + path.lstrip('/')
        path = path.replace('/api/api/', '/api/')
        
        if type(query_params) == dict:
            query_params = urlencode({k:v for k,v in query_params.items() if v})
        query_params = '' if not query_params else f"?{query_params.strip('?')}"

        return path.lstrip('/') + query_params
    
    def call_api(self, url, method='GET', data=None, query_params=None, headers={}):
        log.debug(f"Calling Workato [{method}] {url} with data: {data} and query_params: {query_params}")
        if query_params or not url.startswith(self.__base_url):
            url = self.__api_url(url, query_params)
        headers.update(self.__auth_headers)
        if type(data) in [dict, list] and 'Content-Type' not in headers:
            response = requests.request(method, self.__api_url(url), headers=headers, json=data)
        else:
            response = requests.request(method, self.__api_url(url), headers=headers, data=data)
        log.debug(f"Workato response: {response.status_code} / {response.content}")
        response.raise_for_status()
        try: return response.json()
        except: return response.content

    def get_api(self, url, query_params=None, headers={}):
        return self.call_api(url, query_params=query_params, headers=headers)

    def post_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='POST', data=data, query_params=query_params, headers=headers)

    def put_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='PUT', data=data, query_params=query_params, headers=headers)
    
    # custom methods
    
if __name__ == "__main__":
    # https://phelix-wapi.pixelogicmedia.com/api/orchestrator/prod/134
    workato = Workato()
    # res = workato.post_api('api/orchestrator/prod/134', {}).json()
    # res = workato.get_api('test/status', {})
    res = workato.get_api('api/phelix-lite/system-status', {}).json()
    print(res)