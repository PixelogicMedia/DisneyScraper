# Call Queue Manager API
# sso role: TBD
# docs: https://service-catalog.pixelogicmedia.com/catalog/default/api/queue-manager-api/definition#/
# Dev url: N/A
# Staging url: https://phelix-staging.pixelogicmedia.us/services/queue-manager/api/v1
# Production url: https://phelix.pixelogicmedia.com/services/queue-manager/api/v1

import requests, copy, os, time, json
from urllib.parse import urlencode
from .sso import getSSOToken
from .misc import base64encode

sec={}
try:
    from ..secrets.service_setup import om_sso_client_id as client_id, om_sso_client_secret as client_secret, qm_base_url as base_url
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    client_id = sec.get('sso_client_id') or os.getenv('SSO_CLIENT_ID') or ''
    client_secret = sec.get('sso_client_secret') or os.getenv('SSO_CLIENT_SECRET') or ''
    base_url = sec.get('qm_base_url') or os.getenv('QM_BASE_URL') or ''

from .logger import Logger

log = Logger('queue-manager')

default_options = {
    'base_url': base_url,
    
    'sso_opt': {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
    },

    'admin_emails': 'automation.service@pixelogicmedia.com',

    'qm_location_map': {
        'burbank': 'Burbank',
        'culver': 'Culver',
        'motor': 'Culver',
        'uk': 'London',
        'london': 'London',
        'cairo': 'Cairo',
    },

    'locations': {
        'burbank': {
            'run_module_path': '/mnt/mediatool-cli-tools/services/pxl-service-libs/pxl-utils/pxl/run_module.py',
            'path_detection_path': '/mnt/mediatool-cli-tools/services/pxl-service-libs/pxl-utils/pxl/utils/path_detection.py',
        },
        'motor': {
            'run_module_path': '/mnt/mediatool-cli-tools/services/pxl-service-libs/pxl-utils/pxl/run_module.py',
            'path_detection_path': '/mnt/mediatool-cli-tools/services/pxl-service-libs/pxl-utils/pxl/utils/path_detection.py',
        },
        'london': {
            'run_module_path': '/mnt/mediatool-cli-tools/services/pxl-service-libs/pxl-utils/pxl/run_module.py',
            'path_detection_path': '/mnt/mediatool-cli-tools/services/pxl-service-libs/pxl-utils/pxl/utils/path_detection.py',
        },
        'cairo': {
            'run_module_path': '/mnt/mediatool-cli-tools/services/pxl-service-libs/pxl-utils/pxl/run_module.py',
            'path_detection_path': '/mnt/mediatool-cli-tools/services/pxl-service-libs/pxl-utils/pxl/utils/path_detection.py',
        }
    },


    'default_queue_group': 'mediatools-cmd',

    'polling_time': 5,
    'polling_timeout': 1800,

}

class QueueManager:
    """
    A class for interacting with the Queue Manager API.

    Args:
        opts (dict): Optional. Additional options to customize the behavior of the QueueManager instance.

    Attributes:
        options (dict): The options used by the QueueManager instance.
        __base_url (str): The base URL of the Queue Manager API.
        __access_token (str): The access token used for authentication.
        __token_expiration (float): The expiration time of the access token.

    Methods:
        __refresh_headers(): Refreshes the access token and returns the headers for API requests.
        __api_url(path, query_params=''): Constructs the full API URL with the given path and query parameters.
        call_api(url, method='GET', data=None, query_params=None, headers={}): Makes a generic API call to the Queue Manager API.
        get_api(url, query_params=None, headers={}): Makes a GET request to the specified API endpoint.
        post_api(url, data, query_params=None, headers={}): Makes a POST request to the specified API endpoint.
        put_api(url, data, query_params=None, headers={}): Makes a PUT request to the specified API endpoint.
        get_job(job_id): Retrieves information about a specific job.
        submit_job(name, job_template, queue=None, queue_group=None, parameters=None, location=None, extra={}): Submits a job to the Queue Manager API.
        check_job(job_id): Checks the status of a job until it completes or times out.
        submit_and_check_job(name, job_template, queue=None, queue_group=None, parameters=None, location=None, extra={}): Submits a job and checks its status.
        submit_and_check_generator(jobs): Submits a list of jobs and yields the results as they become available.
        __get_location(location): Returns the corresponding location value for a given location name.
        __get_job_result(job, keys=['results', 'output', 'result']): Extracts the job result from the job response.
        mediatools_cmd(cmd, opts={}, is_cmds=False, is_sync=False): Submits a mediatools command job and returns the result.
        mediatools_cmd_generator(jobs): Submits a list of mediatools command jobs and yields the results as they become available.
    """
    
    def __init__(self, opts=None):
        self.options = copy.deepcopy(default_options)
        if opts: self.options.update(opts)
        self.__base_url = self.options['base_url']
        self.__access_token = ''
        self.__token_expiration = None
        self.__refresh_headers()
        # log.debug(self.__access_token)

    def __refresh_headers(self):
        if not self.__access_token or time.time() > self.__token_expiration:
            token_data = getSSOToken(self.options['sso_opt'])
            self.__token_expiration = time.time() + token_data['expires_in']
            self.__access_token = token_data['access_token']

        return {
            'Authorization': 'Bearer ' + self.__access_token
        }

    def __api_url(self, path, query_params='') -> str:
        if not path.startswith(self.__base_url):
            path = self.__base_url.strip('/') + '/' + path.lstrip('/')
        path = path.replace('/api/v1/api/v1/', '/api/v1/')
        
        if type(query_params) == dict:
            query_params = urlencode({k:v for k,v in query_params.items() if v})
        query_params = '' if not query_params else f"?{query_params.strip('?')}"

        return path.lstrip('/') + query_params
    
    def call_api(self, url, method='GET', data=None, query_params=None, headers={}):
        log.debug(f"Calling Queue Manager [{method}: {url}] with data: {data} and query_params: {query_params}")
        if query_params or not url.startswith(self.__base_url):
            url = self.__api_url(url, query_params)
        headers.update(self.__refresh_headers())
        if type(data) in [dict, list] and 'Content-Type' not in headers:
            response = requests.request(method, self.__api_url(url), headers=headers, json=data)
        else:
            response = requests.request(method, self.__api_url(url), headers=headers, data=data)
        log.debug(f"Queue Manager response: {response.status_code} / {response.content}")
        response.raise_for_status()
        try: return response.json()
        except: return response.content

    def get_api(self, url, query_params=None, headers={}):
        return self.call_api(url, query_params=query_params, headers=headers)

    def post_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='POST', data=data, query_params=query_params, headers=headers)

    def put_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='PUT', data=data, query_params=query_params, headers=headers)
    
    # JOBS
    def get_job(self, job_id):
        return self.get_api(f'jobs/{job_id}')

    def submit_job(self, name, job_template, queue=None, queue_group=None, parameters=None, location=None, extra={}):
        """
        Submits a job to the Queue Manager API.
        Args:
            name (str): The name of the job.
            job_template (str): The name of the job template to use.
            queue (str): The name of the queue to use.
            queue_group (str): The name of the queue group to use.
            parameters (dict): The parameters to pass to the job.
            location (str): The location where the job should be executed.
            extra (dict): Additional options to pass to the job.
        Returns:
            dict: The response from the API.
        """
        payload = {
            "name": name,
            "jobTemplate": {
                "name": job_template,
            }
        }
        if not queue and not queue_group:
            queue_group = self.options['default_queue_group']
        if queue:
            payload['queue'] = {
                "name": queue
            }
        if queue_group:
            payload['queueGroup'] = {
                "name": queue_group
            }
            location = location or 'burbank' # location is require for group
        if parameters:
            payload["parameters"] = [ {"name": k, "value": v} for k,v in parameters.items() ] if isinstance(parameters, dict) else parameters
        if location:
            location = self.__get_location(location)
            payload['tags'] = [{
                "name": "location",
                "value": location
            }]

        # TODO: temporary logic for work-type until resources are supported
        # PARKER: Adding default to be heavy incase we get tasks without worktypes that would overload the system
        # -- in the event that someone chooses the light template we will assume its a light job, otherwise any new jobs will go to the heavy template
        work_type = extra.pop('work_type', 'light' if 'light' in job_template  else 'heavy' )        
        if work_type:
            tags = payload.get('tags', [])
            tags.append({
                "name": "work-type",
                "value": work_type
            })
            payload['tags'] = tags

        if extra:
            payload.update(extra)
        return self.post_api('jobs', payload)
    
    def check_job(self, job_id, return_on_failure=False):
        """
        Checks the status of a job until it completes or times out.
        Args:
            job_id (str): The ID of the job to check.
            return_on_failure (bool): If True, return job result even if job failed.
        Returns:
            dict: The response from the API.
        """
        time_out = time.time() + self.options['polling_timeout']
        while time_out > time.time():
            try:
                job = self.get_job(job_id)
                status = job['status']
                name = job['name']
                log.debug(f"Checking job [{job_id}:{name}] status: {status}")
                # SUBMITTED, STARTED, SUCCEEDED, FAILED, CANCELED, TIMED_OUT
                if status in ['SUCCEEDED']:
                    return job
                if status in ['FAILED', 'CANCELED', 'TIMED_OUT']:
                    if return_on_failure:
                        return job
                    raise Exception(f"Job {name}:{status}.\n{job.get('failureMessage') or job}")

                time.sleep(self.options['polling_time'])
                time_out = time.time() + self.options['polling_timeout']
            except requests.HTTPError as err:
                log.exception(err)
        raise Exception(f"Job {name} timed out.\n {job}")
    
    def submit_and_check_job(self, name, job_template, queue=None, queue_group=None, parameters=None, location=None, extra={}, return_on_failure=False):
        """
        Submits a job and checks its status.
        """
        job = self.submit_job(name, job_template, queue, queue_group, parameters, location, extra)
        return self.check_job(job['id'], return_on_failure)
        
    def submit_and_check_generator(self, jobs, return_on_failure=False):
        for job in jobs:
            job.update(self.submit_job(**job))
        for job in jobs:
            job.update(self.check_job(job['id'], return_on_failure))
            yield job

    def __get_location(self, location):
        return self.options['qm_location_map'].get(location.lower()) or 'Burbank'
    
    @staticmethod
    def __get_job_result(job, keys=['results', 'output', 'result']):
        outputs = job.get('outputs', [])
        for item in outputs:
            if item.get('name') in keys:
                val = item.get('value')
                if isinstance(val, str):
                    try: return json.loads(val)
                    except: pass
                return val
        raise Exception('Job result not found', job)
    
    # cmd support - replacement for celery_call submit_and_check CMD
    # opts will have env, cwd, location, etc.
    # Naming convention for QM submissions:
    # **NOTE** job_name = {service name}_{record id or task id}_(om request id or celery request id)
    def mediatools_cmd(self, cmd, opts = {}, is_cmds = False, is_sync = False):
        work_type = opts.pop('work_type', '') or 'light'
        job_template = f'mediatools-cmd-{work_type}'
        if is_sync:
            # force using job tempalte/work-type for sync job
            job_template = 'mediatools-cmd-sync'
            work_type = 'light'
        job_name = opts.pop('job_name', f'{job_template}-{time.strftime("%Y%m%d%H%M%S", time.localtime())}')
        location = opts.pop('location', '')
        extra = opts.pop('extra', {})
        if 'work_type' not in extra:
            extra['work_type'] = work_type
        
        payload = {'cmds': cmd} if is_cmds else {'cmd': cmd}
        payload.update(opts)

        if is_sync:
            res = self.submit_job(job_name, job_template, parameters = {'payload': base64encode(json.dumps(payload))}, location = location, extra=extra)
            if res.get('status') != 'SUCCEEDED':
                raise Exception('mediatools_cmd failed', res.get('failureMessage') or res)
        else:
            res = self.submit_and_check_job(job_name, job_template, parameters={'payload': base64encode(json.dumps(payload))}, location=location, extra=extra)
        return self.__get_job_result(res)
    
    def mediatools_cmd_generator(self, jobs, return_on_failure=False):
        """
        Submits a list of mediatools command jobs and yields the results as they become available.
        return_on_failure: if True, return job result even if job failed
        """
        job_time = time.strftime("%Y%m%d%H%M%S", time.localtime())

        for job in jobs:
            work_type = job.pop('work_type', 'light')
            job_template = f'mediatools-cmd-{work_type}'
            job_name = job.pop('job_name', f'{job_template}-{job_time}')
            location = job.pop('location', '')
            extra = job.pop('extra', {})
            if 'work_type' not in extra:
                extra['work_type'] = work_type
            
            res = self.submit_job(job_name, job_template, parameters = {'payload': base64encode(json.dumps(job))}, location = location, extra=extra)
            job['id'] = res['id']
            # job.update(res)
        for job in jobs:
            res = self.check_job(job['id'], return_on_failure)
            job.update(res)
            output = self.__get_job_result(res)
            if isinstance(output, str):
                try: output = json.loads(output)
                except: pass
            if isinstance(output, dict):
                job.update(output)
            else:
                job['output'] = output
            yield job
        
    
    # Path Detection support
    def path_detection(self, path: str, options = {}):
        if not path:
            raise Exception('Empty path')
        
        if path.startswith('s3://'):
            try:
                # try to detect using s3 wrapper, otherwise fallback to QM
                from .s3_wrapper import S3Wrapper
                return S3Wrapper().path_detection(path, options)
            except Exception as err:
                log.exception(err)

        location = options.get('location') or 'burbank' # celery location

        sub_payload = {
            'path': path,
            'kwargs': options
        }
        if options:
            sub_payload['kwargs'] = options
        payload = {
            'payload': base64encode(json.dumps(sub_payload)),
            'start_output_sign': '<OUTPUT>',
            'end_output_sign': '</OUTPUT>',
            'run_command_path': self.options['locations'][location]['path_detection_path']
        }
        job_time = time.strftime("%Y%m%d%H%M%S", time.localtime())
        res = self.submit_job(f'pd-{path[-100:]}-{job_time}', 'mediatools-cmd-sync', parameters = payload, location=location)

        if res.get('status') != 'SUCCEEDED':
            raise Exception('Path detection failed', res.get('failureMessage') or res)
        return self.__get_job_result(res)

    def get_exist_path_detection(self, path: str, options = {}, number_of_retries = 3, select_first = False):
        options['check_exist'] = True
        
        counter = 0
        loopcount = number_of_retries + 1
        err = []

        for i in range(loopcount):
            pinfos = self.path_detection(path, options)
            exist_paths = [p for p in pinfos if p.get('exist') == True]
            if len(exist_paths) == 1:
                return exist_paths[0]
            if len(exist_paths) > 1:
                mult = list(set([p['location'] for p in pinfos]))
                if len(mult) == 1 or (len(mult) > 1 and select_first):
                    return exist_paths[0]
                raise Exception('Path exists on multiple location. Please choose proper location. ', mult)
            time.sleep(15)
            counter = counter + 1
            if counter >= loopcount:
                not_exist = [p for p in pinfos if p.get('exist') == False]
                if len(not_exist)>0:        
                    err += ['Path not found.', path, [p['location'] for p in not_exist]]
                not_detect = [p for p in pinfos if p.get('exist') == None]
                if len(not_detect)>0:
                    err += ['Cannot detect path. Please retry.', path, [p['location'] for p in not_detect]]    

        if err:
            raise Exception(err)
        
        raise Exception('Unknown error. Please retry, path is potentially not correctly formatted.', path)
    
    def call_module(self, module_name, function, kwargs={}, opts={}, location='burbank', work_type='light'):
        """
        Calls a module with the specified function and arguments.

        Args:
            module_name (str): The name of the module to call.
            function (str): The name of the function to execute within the module.
            kwargs (dict, optional): Keyword arguments to pass to the function. Defaults to an empty dictionary.
            opts (dict, optional): Additional options to pass to the module. Defaults to an empty dictionary.
            location (str, optional): The location where the module should be executed. Defaults to 'burbank'.
            work_type (str, optional): The type of work to be performed. Defaults to 'light'.

        Returns:
            object: The result of the executed function.

        Raises:
            Exception: If the call to the module fails.
        """
        sub_payload = {
            'class_name': module_name,
            'class_kwargs': opts,
            'function': function,
            'function_kwargs': kwargs
        }
        payload = {
            'payload': base64encode(json.dumps(sub_payload)),
            'start_output_sign': '<OUTPUT>',
            'end_output_sign': '</OUTPUT>',
            'run_command_path': self.options['locations'][location]['run_module_path']
        }

        job_time = time.strftime("%Y%m%d%H%M%S", time.localtime())
        res = self.submit_and_check_job(f'{module_name}-{function}-{job_time}', f'mediatools-cmd-{work_type}', parameters=payload, location=location, extra= {'work_type': work_type})

        if res.get('status') != 'SUCCEEDED':
            raise Exception(f'call {module_name} failed', res.get('failureMessage') or res)

        return self.__get_job_result(res)
    
    # QB API support
    def call_qbapi(self, tbl: str, utoken: str, atoken: str, host: str = 'radius60.quickbase.com', function = 'query', kwargs = {}, location = 'burbank'):
        sub_payload = {
            'class_name': 'qbapi',
            'class_kwargs': {
                'tbl': tbl,
                'utoken': utoken,
                'atoken': atoken,
            },
            'function': function,
            'function_kwargs': kwargs
        }
        payload = {
            'payload': base64encode(json.dumps(sub_payload)),
            'start_output_sign': '<OUTPUT>',
            'end_output_sign': '</OUTPUT>',
            'run_command_path': self.options['locations'][location]['run_module_path']
        }

        job_time = time.strftime("%Y%m%d%H%M%S", time.localtime())
        res = self.submit_job(f'qbapi-{tbl}-{function}-{job_time}', 'mediatools-cmd-sync', parameters = payload, location=location)

        if res.get('status') != 'SUCCEEDED':
            raise Exception('call_qbapi failed', res.get('failureMessage') or res)
        return self.__get_job_result(res)

    # Transfer support
    def call_faspexcmd(self, job, opts = {}, location = 'burbank'):
        sub_payload = {
            'class_name': 'FaspexCmd',
            'class_kwargs': {"opts": opts},
            'function': 'delivery',
            'function_kwargs': {
                'job': job
            }
        }
        payload = {
            'payload': base64encode(json.dumps(sub_payload)),
            'start_output_sign': '<OUTPUT>',
            'end_output_sign': '</OUTPUT>',
            'run_command_path': self.options['locations'][location]['run_module_path']
        }

        job_time = time.strftime("%Y%m%d%H%M%S", time.localtime())
        try: name = job.get('file') or job.get('files')[0]
        except: name = 'unkown'
        res = self.submit_and_check_job(f'faspexcmd-{name[-100:]}-{job_time}', 'mediatools-cmd-transfer', parameters = payload, location=location, extra= {'work_type': 'transfer'})

        if res.get('status') != 'SUCCEEDED':
            raise Exception('call_faspexcmd failed', res.get('failureMessage') or res)

        outputs = res.get('outputs', [])
        results = []
        for item in outputs:
            if item.get('name') in ['results', 'output', 'result']:
                val = item.get('value')
                if isinstance(val, str):
                    return json.loads(val)
                else:
                    return val
            
        if not results:
            raise Exception('call_faspexcmd failed', res)

    def call_faspex_download(self, job, opts = {}, location = 'burbank'):
        sub_payload = {
            'class_name': 'FaspexCmdDownload',
            'class_kwargs': {"opts": opts},
            'function': 'download',
            'function_kwargs': {
                'job': job
            }
        }
        payload = {
            'payload': base64encode(json.dumps(sub_payload)),
            'start_output_sign': '<OUTPUT>',
            'end_output_sign': '</OUTPUT>',
            'run_command_path': self.options['locations'][location]['run_module_path']
        }

        job_time = time.strftime("%Y%m%d%H%M%S", time.localtime())
        try: name = job.get('package_url')
        except: name = 'unkown'
        res = self.submit_and_check_job(f'faspex_download-{name[-100:]}-{job_time}', 'mediatools-cmd-transfer', parameters = payload, location=location, extra= {'work_type': 'transfer'})

        if res.get('status') != 'SUCCEEDED':
            raise Exception('call_faspex_download failed', res.get('failureMessage') or res)

        return self.__get_job_result(res)

    def call_s3wrapper(self, function, kwargs={}, opts = {}, location = 'burbank'):
        return self.call_module('S3Wrapper', function, kwargs, opts, location)
    
    def call_sharepoint(self, function, kwargs={}, opts = {}, location = 'burbank'):
        return self.call_module('SharepointTransfer', function, kwargs, opts, location)

    def call_ci(self, function, kwargs={}, opts = {}, location = 'burbank'):
        return self.call_module('CI', function, kwargs, opts, location)

if __name__ == "__main__":
    qm = QueueManager()
    # res = qm.submit_and_check_job('test-job', 'PROD Path Detection', 'Path Detection', parameters = {'path': '/mnt/localization/Tools/_tmp/tho'})

    job_template = 'mediatools-cmd-light'
    job_name = f'{job_template}_test'
    queue = 'mediatools-cmd-burbank-light'
    queue_group = 'mediatools-cmd'
    parameters = {
        'payload': json.dumps({
            'cmd': ['ls', '/mnt/localization/Tools/_tmp/tho']
        })
    }
    res = qm.submit_and_check_job(job_name, job_template, None, queue_group, parameters, 'Curver')

    try: print(json.dumps(res))
    except: print(res)