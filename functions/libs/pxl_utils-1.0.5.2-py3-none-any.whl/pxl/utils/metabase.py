from __future__ import absolute_import
import requests, json


class Metabase:
    __options = {
        'url': 'https://metabase.pixelogicmedia.com/api',
        'X-API-KEY': '',
    }

    def __init__(self, opts):
        self.__options.update(opts)
    

    def askQuestion(self, qid, payload):
        headers = {
            'Content-Type': 'application/json',
            'x-api-key': self.__options['X-API-KEY']
        }
        url = self.__options['url'] + f'/card/{qid}/query/json'        
        parameters = {
            'format_rows': False,
            'parameters': payload,
            'pivot_results': False
        }

        res = requests.post(url, headers=headers, json=parameters)        
        print(res.content)
        res.raise_for_status()        
        return res.json()
    

