# Send notifications to users via email using Notification Service API
# sso role: can-send-notification
# docs: https://service-catalog.pixelogicmedia.com/catalog/default/api/notification-service-api/definition#
# Dev url: N/A
# Staging url: https://phelix-staging.pixelogicmedia.us/services/notification-service/api/v1
# Production url: https://phelix.pixelogicmedia.com/services/notification-service/api/v1/


import requests, copy, re, os, mimetypes, time
from urllib.parse import urlencode
from .sso import getSSOToken
from .misc import base64encode, isbase64

sec={}
try:
    from ..secrets.service_setup import om_sso_client_id as client_id, om_sso_client_secret as client_secret, notification_base_url as base_url
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    client_id = sec.get('sso_client_id') or os.getenv('SSO_CLIENT_ID') or ''
    client_secret = sec.get('sso_client_secret') or os.getenv('SSO_CLIENT_SECRET') or ''
    base_url = sec.get('notification_base_url') or os.getenv('NOTIFICATION_BASE_URL') or ''

from .logger import Logger

log = Logger('notification')

default_options = {
    'base_url': base_url,
    
    'sso_opt': {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
    },

    'admin_emails': 'automation.service@pixelogicmedia.com',

    'polling_time': 5,
    'timeout': 300,

}

class NotificationService:
    
    def __init__(self, opts=None):
        self.options = copy.deepcopy(default_options)
        if opts: self.options.update(opts)
        self.__base_url = self.options['base_url']
        self.__access_token = ''
        self.__token_expiration = None
        self.__refresh_headers()

    def __refresh_headers(self):
        if not self.__access_token or time.time() > self.__token_expiration:
            token_data = getSSOToken(self.options['sso_opt'])
            self.__token_expiration = time.time() + token_data['expires_in']
            self.__access_token = token_data['access_token']

        return {
            'Authorization': 'Bearer ' + self.__access_token
        }

    def __api_url(self, path, query_params='') -> str:
        if not path.startswith(self.__base_url):
            path = self.__base_url.strip('/') + '/' + path.lstrip('/')
        path = path.replace('/api/v1/api/v1/', '/api/v1/')
        
        if type(query_params) == dict:
            query_params = urlencode({k:v for k,v in query_params.items() if v})
        query_params = '' if not query_params else f"?{query_params.strip('?')}"

        return path.lstrip('/') + query_params
    
    def call_api(self, url, method='GET', data=None, query_params=None, headers={}):
        log.debug(f"Calling Notification Service [{method}] {url} with data: {data} and query_params: {query_params}")
        if query_params or not url.startswith(self.__base_url):
            url = self.__api_url(url, query_params)
        headers.update(self.__refresh_headers())
        if type(data) in [dict, list] and 'Content-Type' not in headers:
            response = requests.request(method, self.__api_url(url), headers=headers, json=data)
        else:
            response = requests.request(method, self.__api_url(url), headers=headers, data=data)
        log.debug(f"Notification Service response: {response.status_code} / {response.content}")
        response.raise_for_status()
        try: return response.json()
        except: return response.content

    def get_api(self, url, query_params=None, headers={}):
        return self.call_api(url, query_params=query_params, headers=headers)

    def post_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='POST', data=data, query_params=query_params, headers=headers)

    def put_api(self, url, data, query_params=None, headers={}):
        return self.call_api(url, method='PUT', data=data, query_params=query_params, headers=headers)
    
    def __parseEmails(self, emails) -> list:
        if not emails:
            emails = [self.options['admin_emails']]
        if not isinstance(emails, list):
            # return emails
            result = []
            for em in re.split('[,;\\s]', emails):
                if em:
                    result.append(em)
            emails = result
        # TODO: remove this check when DevOps support external emails.
        non_pxl = [em for em in emails if em.split('@')[-1] != 'pixelogicmedia.com']
        if non_pxl:
            log.warnings(f"NON PXL emails found. It might not be sent by the service. [{non_pxl}]")
        
        return emails

    def __buid_notification_data(self, recipients, subject, body, attachments, kwargs = {}) -> dict:
        payload = {
            "notificationTemplate": {
                "name": kwargs.get('template_name', 'Dynamic Body')
            },
            "notificationChannel": {
                "name": kwargs.get('channel_name', 'Email')
            },
            "recipients": [{"type": "EMAIL", "email": r, "recipientType": "TO" } for r in self.__parseEmails(recipients)],
            "context": {
                "body": body,
                "subject": subject
            },
            "attachments": []
        }
        if kwargs.get('cc'):
            payload['recipients'] += [{"type": "EMAIL", "email": r, "recipientType": "CC" } for r in self.__parseEmails(kwargs.get('cc'))]
        if kwargs.get('bcc'):
            payload['recipients'] += [{"type": "EMAIL", "email": r, "recipientType": "BCC" } for r in self.__parseEmails(kwargs.get('bcc'))]
            
        if attachments:
            if not isinstance(attachments, list):
                attachments = [attachments]
            for att in attachments:
                if isinstance(att, str):
                    if os.path.isfile(att):
                        file_name = os.path.basename(att)
                        content_type, _ = mimetypes.guess_type(file_name)
                        if content_type is None:
                            # text/plain, text/html, application/octet-stream
                            content_type = 'application/octet-stream'
                        payload['attachments'].append({
                            "content": base64encode(open(att, 'rb').read()),
                            "type": content_type,
                            "filename": file_name
                        })
                    else:
                        is_html = '</' in att and '>' in att
                        payload['attachments'].append({
                            "content": base64encode(att),
                            "type": 'text/html' if is_html else 'text/plain',
                            "filename": 'attachment' + ('.html' if is_html else '.txt')
                        })
                elif isinstance(att, dict):
                    if 'content' not in att or 'filename' not in att and 'type' not in att:
                        raise Exception('Missing fields in attachment: content|filename|type ... ' + str(att))
                    if not isbase64(att['content']):
                        att['content'] = base64encode(att['content'])
                    log.debug(att['content'])
                    payload['attachments'].append(att)
                else:
                    raise Exception('Invalid attachment ... ' + str(att))
        return payload

    def send_notification(self, recipients, subject, body, attachments=None, kwargs = {}):
        log.debug(f'Sending notification to {recipients} with subject: {subject}')
        payload = self.__buid_notification_data(recipients, subject, body, attachments, kwargs)
        log.debug(payload)
        return self.call_api(
            'notifications',
            method='POST',
            data=payload
        )
    
    def get_notifications(self):
        return self.call_api('notifications')
    
    def get_notification_templates(self):
        return self.call_api('notification-templates')