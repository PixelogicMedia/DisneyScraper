import json, os, sys, boto3, base64, socket, re as regex, datetime, time, copy, requests, stat, subprocess

from botocore.exceptions import ClientError

package_name = 'pxl-path-detection'
version = '1.6.0.0'

app_name = 'path_detection'
DEBUG = False

try:
    # import from pxl specialized services
    from .logger import Logger
except:
    try:
        # import from local path
        sys.path.append(os.path.dirname(os.path.realpath(__file__)))
        from logger import Logger
    except:
        try:
            # import from pxl-utils libs
            from pxl.utils.logger import Logger
        except:
            print('Cannot import pxl logging ...')

try: log = Logger(app_name)
except:
    print('Use system logging ...')
    import logging
    logging.basicConfig(
        level=logging.INFO,  # Set the log level to INFO
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',  # Define the log format
        handlers=[logging.StreamHandler(sys.stdout)]  # Output to console
    )
    log = logging.getLogger(app_name)


# supports
def _base64encode(message, encoding='ascii'):
    binary_content = message if isinstance(message, bytes) else str(message).encode(encoding)
    return base64.b64encode(binary_content).decode(encoding, errors='replace')


def _base64decode(base64_message, encoding='ascii'):
    binary_content = base64_message if isinstance(base64_message, bytes) else str(base64_message).encode(encoding)
    return base64.b64decode(binary_content).decode(encoding, errors='replace')

def __parse_json_args(args):
    try:
        if type(args) is str:
            return json.loads(args)
        return args
    except Exception as err:
        log.error(f'Cannot parse json args {args}')
        log.exception(err)
    return {}

def __parse_b64_args(args):
    try:
        return __parse_json_args(_base64decode(args))
    except Exception as err:
        log.error(f'Cannot parse b64 json args {args}')
        log.exception(err)
    return {}


# aws secret manager
def get_secret(secret_name, region_name=None):
    try:
        from .aws_secret import get_secret as local_get_secret
        return local_get_secret(secret_name, region_name)
    except:
        try:
            from pxl.utils.aws_secret import get_secret as pxl_get_secret
            return pxl_get_secret(secret_name, region_name)
        except:
            log.error('Cannot import aws_secret ...')

    region_name = region_name or os.getenv('AWS_REGION')
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
    )

    get_secret_value_response = client.get_secret_value(
        SecretId=secret_name
    )        
    if 'SecretString' in get_secret_value_response:
        secret = get_secret_value_response['SecretString']
        return json.loads(secret)
    else:
        return json.loads(base64.b64decode(get_secret_value_response['SecretBinary']))

        
# s3 support (from s3_wrapper)
def s3_path_split(s3_path):
    bucket = s3_path.split('s3://')[-1].split('/')[0]
    key = s3_path.split(f'{bucket}/', 1)[-1]
    return bucket, key

def s3_path_combine(s3_bucket, s3_key):
    return f"s3://{s3_bucket}/{s3_key}"

def s3_path_exists(bucket_name, key):
    s3_client = boto3.client('s3')
    try:
        s3_client.head_object(Bucket=bucket_name, Key=key)
        return True
    except ClientError as e:
        # try list_objects_v2
        try:
            res = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=key, MaxKeys=1)
            return 'Contents' in res
        except ClientError as e1:
            log.debug(e1)
        log.debug(e)
        # If a client error is thrown, then check that it was a 404 error.
        # If it was a 404 error, then the object does not exist.
        error_code = int(e.response['Error']['Code'])
        if error_code == 404:
            return False
        else:
            raise

def s3_path_exists_by_path(s3_path):
    return s3_path_exists(*s3_path_split(s3_path))

def list_s3_files(bucket_name, prefix, toplevel=False):
    continuation_token = None
    objs = []
    while True:
        list_params = {
            'Bucket': bucket_name,
            'Prefix': prefix
        }
        if toplevel:
            list_params['Delimiter'] = '/'
        if continuation_token:
            list_params['ContinuationToken'] = continuation_token
        
        response = boto3.client('s3').list_objects_v2(**list_params)
        
        if 'Contents' in response:
            # might have to check for .j2c with a loop
            objs += response['Contents']

        if 'CommonPrefixes' in response:
            objs += [{'Key': prefix['Prefix']} for prefix in response['CommonPrefixes']]
        
        # if there are more than 1000 objects in response
        if response.get('IsTruncated'): 
            continuation_token = response.get('NextContinuationToken')
        else:
            break
    
    return [ s3_path_combine(bucket_name, obj['Key']) for obj in objs if obj['Key'].rstrip('/') != prefix.rstrip('/')]

def list_s3_files_by_path(s3_path, toplevel=False):
    return list_s3_files(*s3_path_split(s3_path), toplevel)


def deep_update(dict1, dict2):
    for key, value in dict2.items():
        if isinstance(value, dict):
            dict1[key] = deep_update(dict1.get(key, {}), value)
        else:
            dict1[key] = value
    return dict1


class PathDetection:
    __default_config_path = os.path.dirname(os.path.realpath(__file__)) + '/path_detection.json'
    __config_paths = [
        '/mnt/mediatool-cli-tools/Tools/configs/path_detection.json',
        '/mnt/localization/Tools/configs/path_detection.json',
        '/Volumes/prodstor/_ddm/Tools/configs/path_detection.json',
        '/mnt/pxl-vault02/_tmp/configs/path_detection.json',
        # '/mnt/pixelogic-proxy-/Tools/configs/path_detection.json',
    ]
    
    __config = {
        "mappings": {
            "unknown": {
                "location": "unknown",
                "mnt": "",
                "unc": "",
                "volumes": "",
                "s3": "",
                "letter": "",
                "vidispine": "",
                "signs": [],
                "maps": []
            }
        }
    }

    __truthy = ['true', '1', 'yes', 'on', 'enable', 'enabled', True, 1]

    def __init__(self, path: str = None, extra_mappings: dict = {}, **kwargs):
        if path == None:
            self.__loadConfig(self.__default_config_path)
            for cp in self.__config_paths + kwargs.get('config_paths', []):
                self.__loadConfig(cp)        
            return
        
        self.__results = []
        self.__path = path.strip().strip('"').strip("'").strip('"').strip("'").replace('\\', '/')
        self.__extra_mappings = extra_mappings
        self.__opts = {}
        for k,v in kwargs.items():
            self.__opts[k] = v
        if self.__path.lower().startswith('s3://'):
            self.__opts['location'] = 's3'
        else:
            location = str(self.__opts.get('location')).lower()
            if location in 'none':
                self.__opts['location'] = ''
            elif location in ['culver city', 'motor']:
                self.__opts['location'] = 'motor'
            elif location in ['uk', 'london']:
                self.__opts['location'] = 'london'
            else:
                self.__opts['location'] = location
        
        self.__opts['listsubdir'] = str(self.__opts.get('listsubdir') or self.__opts.get('list_sub_dir')).lower() in self.__truthy
        self.__opts['listdir'] = self.__opts['listsubdir'] or str(self.__opts.get('listdir') or self.__opts.get('list_dir')).lower() in self.__truthy
        self.__opts['check_exist'] = self.__opts['listdir'] or str(self.__opts.get('check_exist') or self.__opts.get('checkexist')).lower() in self.__truthy
        self.__opts['list_unknown'] = str(self.__opts.get('list_unknown') or self.__opts.get('listunknown')).lower() in self.__truthy
        
        # load configs
        for cp in self.__config_paths:
            self.__loadConfig(cp)
        self.__loadConfig(self.__default_config_path)

        for cp in self.__opts.get('config_paths', []):
            log.debug(f"loading custom config ... {cp}")
            self.__loadConfig(cp)
        # load config from secret
        secret_name = self.__opts.get('secret_name') or os.getenv('SECRET_NAME') or ''
        if secret_name:
            log.debug(f"loading secrets ... {secret_name}")
            sec = get_secret(secret_name)
            self.__loadConfig(sec.get('path_detection'))
        config_from_env = os.getenv('PATH_DETECTION_CONFIG')
        if config_from_env:
            log.debug(f"loading env config ... {config_from_env}")
            self.__loadConfig(config_from_env)
    
    def Ping(self):
        errors = []
        for loc in self.__config['path-detection-urls']:
            for _ in range(5):
                try:
                    res = requests.head(self.__config['path-detection-urls'][loc], timeout=(1, 3))
                    res.raise_for_status()
                    return []
                except Exception as re:
                    log.exception(re)
            errors.append(f'{loc}:{self.__config["path-detection-urls"][loc]} could not be checked, had an error')
        return errors

    def __loadConfig(self, cp):
        if not cp: return
        try:
            config = None
            if type(cp) is str:
                if cp.strip()[0] in ['{', '[']:
                    config = json.loads(cp)
                elif os.path.isfile(cp) and os.path.exists(cp):
                    with open(cp, 'r') as f:
                        config = json.load(f)
            elif type(cp) is dict:
                config = cp
            if not config: return
            
            log.debug(f"config read for ... {cp}")
            config['mappings'].update(self.__extra_mappings)
            self.__config = deep_update(self.__config, config)
            # update name for mappings
            for m in self.__config['mappings']:
                self.__config['mappings'][m]['name'] = m
            log.debug(f"loading ... {cp}")
        except Exception as err:
            log.error(f'Cannot load config {cp}')
            log.error(f'type: {type(cp)}')
            log.exception(err)

    def __detectMount(self):
        try:
            config = self.__config
            path = self.__path
            log.debug(f"checking path ... {str(path)}")

            if not path: return
            if 'exceptions' in config:
                for k in config['exceptions']:
                    v = config['exceptions'][k]
                    if not path.startswith(k) and path.startswith(v):
                        path = k + path[len(v):]
                        break

            for mount in config['mappings']:
                for m in config['mappings'][mount]['maps']:
                    if path.lower().startswith(m.lower()) and (not self.__opts.get('location') or self.__opts.get('location') == config['mappings'][mount]['location']):
                        self.__addResult(config['mappings'][mount], path[len(m):])
                        break
            
            for mount in config['mappings']:
                signs = config['mappings'][mount]['signs']
                signs += [f"{s.rstrip('/')}_{config['mappings'][mount]['location']}/" for s in signs]                
                for sign in signs:
                    parts = regex.split(sign, path, 1, flags=regex.IGNORECASE)
                    if len(parts) == 2 and (not self.__opts.get('location') or self.__opts.get('location') == config['mappings'][mount]['location']):
                        self.__addResult(config['mappings'][mount], parts[-1])
                        break
                
            #if local
            if len(self.__results) == 0 and (os.path.exists(path) or os.path.exists(os.path.dirname(path))):
                log.info('check local ... ')
                self.__addLocalResult()
            if len(self.__results) == 0 and path.startswith('s3://'):
                log.info('check if s3 ... ')
                self.__addS3Result()
        except Exception as err:
            log.error('looking mapping failed: ' + str(err))
            log.exception(err)
        
        host_loc = self.__hostLocation()
        
        for m in self.__results:
            log.debug(f"checking ... {m}")
            try:
                p = m['mnt_full']
                if host_loc == m['location'] or m['location'] == 'local':
                    m['exist'] = os.path.exists(p)
                    if m['exist']:
                        m['type'] = 'folder' if os.path.isdir(p) else 'file'
                        m['stat'] = PathDetection.__stat2json(p, self.__opts.get('real_folder_size') or False)
                        if self.__opts.get('listdir') == True and m['type'] == 'folder':
                            m['listdir'] = os.listdir(p)
                            if self.__opts.get('listsubdir') == True:
                                listsubdir = []
                                for root, dirs, files in os.walk(path):
                                    rel = os.path.relpath(root, path)
                                    for dir in dirs:
                                        if rel != '.': listsubdir.append(os.path.join(rel, dir) + '/' )
                                        else: listsubdir.append(dir + '/')
                                    for file in files:
                                        if rel != '.': listsubdir.append(os.path.join(rel, file))
                                        else: listsubdir.append(file)
                                m['listsubdir'] = listsubdir
                        if os.path.islink(p):
                            m['symlink'] = True
                            m['realpath'] = os.path.realpath(p)
                elif self.__opts.get('check_exist') == True:
                    
                    if m['location'] == 's3':
                        try:
                            p = m['s3_full']
                            m['exist'] = False
                            m['type'] = 'unknown'
                            log.info(f'check s3 path {p} exist at local')
                            if s3_path_exists_by_path(p.rstrip('/') + '/'):
                                log.debug('is folder')
                                m['type'] = 'folder'
                                m['exist'] = True
                            elif s3_path_exists_by_path(p):
                                log.debug('is file')
                                m['type'] = 'file'
                                m['exist'] = True
                            m['listdir'] = list_s3_files_by_path(p, True)
                        except Exception as s3err:
                            log.exception(s3err)
                            m['err'] = str(s3err)
                    else:
                        check_location = m['location']
                        # use ssh to check
                        try:
                            ssh_payload = {
                                'path': p,
                                'kwargs': copy.deepcopy(self.__opts)
                            }
                            ssh_payload['kwargs']['location'] = check_location
                            ssh_payload['kwargs']['check_exist'] = False
                            ssh_machine = config.get('ssh-machines', {}).get(check_location) or {}
                            if not ssh_machine:
                                raise Exception(f'No ssh machine info for {check_location}. Try to use urls/service ...')
                            log.info(f"check using ssh to {ssh_machine}")
                            ssh_cmd = ['python3', ssh_machine['pd-path'], '--base64', _base64encode(json.dumps(ssh_payload))]
                            cmd = subprocess.list2cmdline(['ssh', ssh_machine['macchine-name'], subprocess.list2cmdline(ssh_cmd)])
                            ssh_output = subprocess.check_output(cmd, stderr=subprocess.STDOUT, shell=True)
                            log.info(f"ssh_output: {ssh_output}")
                            for mr in json.loads(str(ssh_output).split('<OUTPUT>')[-1].split('</OUTPUT>')[0]):
                                if mr['location'] not in [check_location, 'local'] or mr['mnt_full'] != m['mnt_full']:
                                    continue
                                m.update(mr)
                                m['location'] = check_location
                                m['err']=''
                                break
                        except Exception as qmerr:
                            log.exception(qmerr)
                            
                            remote_url = config.get('path-detection-urls', {}).get(check_location)
                            if remote_url:
                                payload = copy.deepcopy(self.__opts)
                                payload['location'] = check_location
                                payload['check_exist'] = False
                                payload['path'] = p
                                retries = 1
                                while retries < 6:
                                    try:
                                        log.info(f'check({retries}) path {p} exist at: {check_location} / {remote_url}')
                                        res = requests.get(remote_url.rstrip('/') + '/detectpath', params=payload, timeout=(5, 15))
                                        res.raise_for_status()
                                        for mr in res.json():
                                            if mr['location'] not in [check_location, 'local'] or mr['mnt_full'] != m['mnt_full']:
                                                continue
                                            m.update(mr)
                                            m['location'] = check_location
                                            m['err']=''
                                            retries = 6
                                            break
                                    except Exception as re:
                                        log.exception(re)
                                        m['err'] = str(re)
                                    time.sleep(2)
                                    retries += 1
            except Exception as err:
                log.exception(err)            

        if self.__opts.get('check_exist') == True:
            groups = {}
            toremove = []
            for m in self.__results:
                if (m.get('exist') or False):
                    if not (m['location'] in groups):
                        groups[m['location']] = m
                    else:
                        toremove.append(m)
            for item in toremove:
                self.__results.remove(item)
                
        if len(self.__results) == 0 and self.__opts.get('list_unknown') == True:
            log.info("adding unknown result")
            self.__addUnkownResult()


        log.info(self.__results)
    
    def __addUnkownResult(self):
        self.__results.append({
            "location": 'unknown',
            "exist": False,
            "mnt":"",
            "unc": "",
            "volumes": "",
            "s3": "",
            "vidispine": "",
            "relativepath":"",
            "originalpath": self.__path,
            "volumes_full": "",
            "s3_full":"",
        })

    def __addLocalResult(self):
        self.__results.append({
            "location": 'local',
            "mnt": "",
            "unc": "",
            "volumes": "",
            "s3": "",
            "vidispine": "",
            "relativepath": self.__path,
            "originalpath": self.__path,
            "mnt_full": os.path.abspath(self.__path),
            "unc_full": os.path.abspath(self.__path),
            "volumes_full": os.path.abspath(self.__path),
            "s3_full": os.path.abspath(self.__path)
        })

    def __addS3Result(self):
        s3_bucket_name, s3_key_path = self.__path.split('://')[-1].split('/',1)
        mnt = f"/mnt/{s3_bucket_name}/"
        unc = f"//{s3_bucket_name}/"
        volumes = f"/Volumes/{s3_bucket_name}/"
        self.__results.append({
            "location": 's3',
            "mnt": mnt,
            "unc": unc,
            "volumes": volumes,
            "s3": s3_bucket_name,
            "vidispine": "",
            "relativepath": self.__path,
            "originalpath": self.__path,
            "mnt_full": os.path.join(mnt, s3_key_path),
            "unc_full": os.path.join(volumes, s3_key_path),
            "volumes_full": os.path.join(volumes, s3_key_path),
            "s3_full": self.__path
        })

    def __addResult(self, mount: dict, relative_path:str):
        relative_path = relative_path.strip('/')
        if len([r for r in self.__results if r['location'] == mount['location'] and r['mnt'] == mount['mnt']]) == 0:
            name = mount['name']
            mnt = mount.get('mnt') or f"/mnt/{name}/"
            unc = mount.get('unc') or f"//{name}/"
            volumes = mount.get('volumes') or f"/Volumes/{name}/"
            s3 = mount.get('s3') or f"s3://{name}/"
            vidispine = mount.get('vidispine') or ''
            r0 = {
                "location": mount['location'],
                "mnt": mnt,
                "unc": unc,
                "volumes": volumes,
                "s3": s3,
                "vidispine": vidispine,
                "relativepath": relative_path,
                "originalpath": self.__path,
                "mnt_full": os.path.join(mnt, relative_path),
                "unc_full": os.path.join(unc, relative_path),
                "volumes_full": os.path.join(volumes, relative_path),
                "s3_full": os.path.join(s3, relative_path)
            }
            self.__results.append(r0)
    
    def DetectionResult(self):
        self.__detectMount()
        return self.__results

    @staticmethod
    def __hostLocation(): 
        host, ip = PathDetection.__getHostNameIP()
        host = host.upper()
        if ip.startswith('10.100.') or 'BUR-P' in host:
            return 'burbank'
        if ip.startswith('10.110.') or 'LON-P' in host:
            return 'london'
        if ip.startswith('10.200.') or 'LA-P' in host or 'MOT-P' in host:
            return 'motor'
        if ip.startswith('10.130.') or 'CAI-P' in host:
            return 'cairo'
        if ip.startswith('172.16.') or 'DMZ' in host:
            return 'dmz'
        if ip.startswith('10.220.') or 'AWS' in host or ip.startswith('18.219.'):
            return 's3'
        if ip.startswith('127.0.0.1') or 'LOCALHOST' in host:
            return 'local'

    @staticmethod
    def __getHostNameIP(): 
        try: 
            host_name = socket.gethostname() 
            host_ip = socket.gethostbyname(host_name) 
            log.info(f'{host_name} - {host_ip}')
            return host_name, host_ip
        except Exception as err: 
            log.exception(err)
        return '', ''

    @staticmethod
    def __stat2json(p, real_folder_size = False):
        s = os.stat(p)
        sz = s.st_size
        if real_folder_size and os.path.isdir(p):
            try: sz = int(subprocess.check_output(['du', '-sk', p]).decode().split()[0])*1024
            except: pass
        r = {
            'mode': stat.filemode(s.st_mode),
            'hardlinks': s.st_nlink,
            'size': sz,
            'last_access': str(datetime.datetime.fromtimestamp(s.st_atime)),
            'modified': str(datetime.datetime.fromtimestamp(s.st_mtime)),
            'created': str(datetime.datetime.fromtimestamp(s.st_ctime)),
        }
        log.debug(f"stat ... {r}")
        return r


if __name__ == '__main__':
    log.info(f"{app_name} v{version} ...")
    
    import argparse

    parser = argparse.ArgumentParser(description=app_name)
    parser.add_argument('--debug', '-d', action='store_true', default=False, help='Debug flag')
    parser.add_argument('--base64', type=__parse_b64_args, default={}, help='base64 encoded payload')
    parser.add_argument('--payload', type=__parse_json_args, default={}, help='json string payload')

    parser.add_argument('--path', '-p', default='', help='path to detect')
    parser.add_argument('--extra_mappings', '-m', type=__parse_json_args, default={}, help='extra_mappings')
    parser.add_argument('--kwargs', '-k', type=__parse_json_args, default={}, help='kwargs')
    
    args = parser.parse_args()
    opts = vars(args)
    opts.update(opts.get('base64') or {})
    opts.update(opts.get('payload') or {})
    log.info(f"opts: {opts}")
    DEBUG = opts.get('debug') or False
    log.info(f"Debug mode: {DEBUG}")

    extra_mappings = opts.get('extra_mappings', {}) or {}
    kwargs = opts.get('kwargs', {}) or {}
    
    res = PathDetection(opts.get('path'), extra_mappings, **kwargs).DetectionResult()

    log.info(f"<OUTPUT>{json.dumps(res)}</OUTPUT>")

    # sudo python3 /mnt/localization/Tools/celery/pxl_services_specialized/apps/utils/path_detection_qm.py -p /mnt/lon-qfs01/_Celery/Tools -k '{"list_dir": true}'
    

