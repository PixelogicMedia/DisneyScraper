from __future__ import absolute_import

import requests, copy, json, time, re, boto3, os
from urllib.parse import urlencode
from time import sleep
from .sso import getSSOToken
from .qm import QueueManager

sec={}
try:
    from ..secrets.service_setup import om_sso_client_id as client_id, om_sso_client_secret as client_secret, am_base_url as base_url
except:
    try:
        from .aws_secret import get_env_secret
        sec = get_env_secret(os.getenv('MEDIATOOLS_SECRET_NAME'))
    except:
        sec = {}
    client_id = sec.get('sso_client_id') or os.getenv('SSO_CLIENT_ID') or ''
    client_secret = sec.get('sso_client_secret') or os.getenv('SSO_CLIENT_SECRET') or ''
    base_url = sec.get('am_base_url') or os.getenv('AM_BASE_URL') or ''

from .logger import Logger

log = Logger('am')

default_options = {
    # https://mam-api.pixelogicmedia.com/api/v1
    'base_url': base_url,
    
    'sso_opt': {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
    },

    'polling_time': 5,
    'timeout': 300,

}

class AMWrapper:
    def __init__(self, opts=None):
        self.options = copy.deepcopy(default_options)
        if opts: self.options.update(opts)
        self.__base_url = self.options['base_url']
        self.__access_token = ''
        self.__token_expiration = None
        self.__refresh_headers()

    def __refresh_headers(self):
        if not self.__access_token or time.time() > self.__token_expiration:
            token_data = getSSOToken(self.options['sso_opt'])
            self.__token_expiration = time.time() + token_data['expires_in'] - 10
            self.__access_token = token_data['access_token']

        return {
            'Authorization': 'Bearer ' + self.__access_token
        }

    def __api_url(self, path, query_params=''):
        if not path.startswith(self.__base_url):
            path = self.__base_url.strip('/') + '/' + path.lstrip('/')
        path = path.replace('/api/v1/api/v1/', '/api/v1/')
        
        if type(query_params) == dict:
            query_params = urlencode({k:v for k,v in query_params.items() if v})
        query_params = '' if not query_params else f"?{query_params.strip('?')}"

        return path.lstrip('/') + query_params
        
    def call_am_api(self, url, method='GET', data=None, query_params=None, headers={}):
        log.debug(f"Calling AM API [{method}] {url} with data: {data} and query_params: {query_params}")
        if query_params or not url.startswith(self.__base_url):
            url = self.__api_url(url, query_params)
        headers.update(self.__refresh_headers())
        if type(data) in [dict, list] and 'Content-Type' not in headers:
            response = requests.request(method, self.__api_url(url), headers=headers, json=data)
        else:
            response = requests.request(method, self.__api_url(url), headers=headers, data=data)
        log.debug(f"AM API response: {response.status_code} / {response.content}")
        response.raise_for_status()
        try: return response.json()
        except: return response.content
    
    # general AM API call
    def get_am_api(self, url, query_params=None, headers={}):
        return self.call_am_api(url, query_params=query_params, headers=headers)

    def post_am_api(self, url, data, query_params=None, headers={}):
        return self.call_am_api(url, method='POST', data=data, query_params=query_params, headers=headers)

    def put_am_api(self, url, data, query_params=None, headers={}):
        return self.call_am_api(url, method='PUT', data=data, query_params=query_params, headers=headers)
    
    # AM API calls
    def get_cpl_reels(self, dcp_am_id):
        log.debug(f"Getting Asset [{dcp_am_id}] DCP Reels details.")
        return self.get_am_api(f'/item/{dcp_am_id}/cpl/reels')

    def get_technical_details(self, am_id='', om_id='', om_version_id=''):
        query_params = {
            "amAssetId": am_id,
            "omAssetId": om_id,
            "omAssetVersionId": om_version_id
        }
        log.debug(f"Getting Asset [{query_params}] technical details.")
        return self.get_am_api('/item/technical-details', query_params)
        
    def get_technical_details_from_om_id(self, om_id, om_version_id=''):
        return self.get_technical_details(om_id=om_id, om_version_id=om_version_id)
    
    def get_related_items(self, am_id='', om_id='', om_version_id='', proxy_types=[], include_relations=False):
        # /api/v1/item/relatedItems
        query_params = {
            "amAssetId": am_id,
            "omAssetId": om_id,
            "omAssetVersionId": om_version_id,
            "proxyTypes": proxy_types,
            "includeRelations": include_relations
        }
        log.debug(f"Getting Asset [{query_params}] relatedItems.")
        return self.get_am_api('/item/relatedItems', query_params)
        
    def get_relations(self, am_id='', om_id='', om_version_id=''):
        query_params = {
            "amItemId": am_id,
            "omAssetId": om_id,
            "omAssetVersionId": om_version_id
        }
        log.debug(f"Getting Asset [{query_params}] relations.")
        return self.get_am_api('/item/relations', query_params)
        
    ## DCP should be source, Target should be prores, relationship metadata shouyld be proxyAssetType: MASTERREF type should be IS_PROXY_OF_DCP_PROXY
    def add_relation(self, am_id='', target_am_id='', relation_type='', relationship_metadata=[]):
        params = {
            "itemId": am_id,
            "targetItemId": target_am_id,
            "relationType": relation_type
        }
        payload = {
            "relationMetadata": relationship_metadata
        }
        log.debug(f"Adding Asset relation. {payload}")
        return self.post_am_api(f"/item/{am_id}/relation", data=payload, query_params=params)
        

    def get_relations_by_om(self, om_id, om_version_id):
        return self.get_relations(om_id=om_id, om_version_id=om_version_id)
    
    def get_relation_am_id_by_type(self, relation_type: str, am_id='', om_id='', om_version_id=''):
        relations = self.get_relations(am_id, om_id, om_version_id).get('directRelations') or []
        relations = filter(lambda x: any(y['key'] == 'type' and y['value'].lower() == relation_type.lower() for y in x.get('values')), relations)
        for r in relations:
            if (am_id and r['direction']['source']['id'] == am_id) or (om_id and r['direction']['source']['omAssetId'] == om_id):
                return r['direction']['target']
            elif (am_id and r['direction']['target']['id'] == am_id) or (om_id and r['direction']['target']['omAssetId'] == om_id):
                return r['direction']['source']
        return None
    
    # def checkout_asset(self, targetPath: str, am_id: str):
    #     log.debug(f"Pulling Asset {am_id} to => {targetPath}")
    #     response = requests.put(self.__api_url(f"/api/v1/moas/checkout/{am_id}", {"path": targetPath}), headers=self.__headers)
    #     if response.status_code == 200:
    #         return response.json()
    #     raise Exception(f'Pulling Assets [{am_id}] failed with status code {response.status_code} / {response.content}')

    def bulk_checkout_asset(self, targetStorageId: str, targetPath: str, useAmName: bool, appenAmItemId: bool, am_ids: list, polling=False, polling_children=False):
        log.debug(f"Pulling Asset {json.dumps(am_ids)} to => {targetPath}")
        data = {
            "targetStorageId": targetStorageId,
            "targetPath": targetPath,
            "useAmName": useAmName,
            "appendAmItemId": appenAmItemId,
            "items": am_ids
        }
        result = self.put_am_api("/moas/bulk/checkout", data)
        if not polling: return result

        jobId = result['jobId']
        children_jobs = []
        
        polling_time = default_options.get('polling_time') or 10
        timeout = default_options.get('timeout') or 300
        start = time.time()
        while True:
            res = self.get_bulk_import_status(jobId)
            log.info("status: " + res["status"])
            if res['status'] == "SUCCEEDED":
                if not polling_children:
                    sleep(10) # wait for AM asset available
                    return { "status": "checkout-successful" }
                else:
                    children_jobs = {cj['jobId']:cj['status'] for cj in res['bulkCheckoutResponseDto']['jobs']}
                    break
            elif not res['status'] == "IN_PROGRESS":
                raise Exception("Checkout of Asset failed", res)
            if start + timeout < time.time():
                raise Exception(f"Checkout of Asset failed (timeout: {timeout}s)")
            time.sleep(polling_time)
        for jobId in children_jobs:
            if children_jobs[jobId] == 'IN_PROGRESS':
                children_jobs[jobId] = self.get_job_status(jobId)

        start = time.time()
        timeout = timeout * len(am_ids) * 2
        while True:
            for jobId in children_jobs:
                if children_jobs[jobId] == 'IN_PROGRESS':
                    children_jobs[jobId] = self.get_job_status(jobId)
            if all(children_jobs[j] != 'SUCCEEDED' for j in children_jobs):
                sleep(10) # wait for AM asset available
                return { "status": "checkout-successful" }
            elif any(children_jobs[j] != 'IN_PROGRESS' for j in children_jobs):
                raise Exception("Checkout of Asset failed", children_jobs)
            if start + timeout < time.time():
                raise Exception(f"Checkout of Asset failed (timeout: {timeout}s)")
            time.sleep(polling_time)

    def get_job_status(self, jobid: str):
        log.debug(f"Getting Job Status {jobid}")
        return self.get_am_api(f"/job/{jobid}")

    def bulk_move_asset(self, storageId: str, targetPath: str, useAmName: bool, appenAmItemId: bool, am_ids: list, polling=True, polling_children=True):
        log.debug(f"Pulling Asset {json.dumps(am_ids)} to => {targetPath}")
        data = {
            "storageId": storageId,
            "targetPath": targetPath,
            "useAmName": useAmName,
            "appendAmItemId": appenAmItemId,
            "items": am_ids
        }
        result = self.put_am_api("/moas/bulk/move", data)
        if not polling: return result

        jobId = result['prepareBulkCheckoutJobResponse']['jobId']
        children_jobs = []
        
        polling_time = default_options.get('polling_time') or 10
        timeout = default_options.get('timeout') or 300
        start = time.time()

        while True:
            res = self.get_bulk_import_status(jobId)
            log.info("status: " + res["status"])
            if res['status'] == "SUCCEEDED":
                if not polling_children:
                    return { "status": "checkout-successful" }
                else:
                    children_jobs = {cj['jobId']:cj['status'] for cj in res['bulkCheckoutResponseDto']['jobs']}
                    break
            elif not res['status'] == "IN_PROGRESS":
                raise Exception("Checkout of Asset failed", res)
            if start + timeout < time.time():
                raise Exception(f"Checkout of Asset failed (timeout: {timeout}s)")
            time.sleep(polling_time)
        for jobId in children_jobs:
            if children_jobs[jobId] == 'IN_PROGRESS':
                children_jobs[jobId] = self.get_job_status(jobId)

        start = time.time()
        timeout = timeout * len(am_ids) * 2
        while True:
            for jobId in children_jobs:
                if children_jobs[jobId] == 'IN_PROGRESS':
                    children_jobs[jobId] = self.get_job_status(jobId)
            if all(children_jobs[j] != 'SUCCEEDED' for j in children_jobs):
                return { "status": "checkout-successful" }
            elif any(children_jobs[j] != 'IN_PROGRESS' for j in children_jobs):
                raise Exception("Checkout of Asset failed", children_jobs)
            if start + timeout < time.time():
                raise Exception(f"Checkout of Asset failed (timeout: {timeout}s)")
            time.sleep(polling_time)
        
    def get_bulk_import_status(self, jobid: str):
        log.debug(f"Getting Job Status {jobid}")
        return self.get_am_api(f"/moas/bulk/checkout-job/{jobid}")

    def get_storages(self):
        log.debug(f"Gathering storage info")
        return self.get_am_api(f"/storage")
    
    def get_storage_by_name(self, storage_name):
        storages = self.get_storages()
        return ([s for s in storages if s['name'] == storage_name] or [{}])[0]

    def get_storage_filesystem(self, storageid):
        log.debug(f"Gathering storage info")
        return self.get_am_api(f"/storage/{storageid}/filesystem")

    def get_storage_vxid_and_vidispine_path(self, path : str, location: str) -> [str, str]:
        stor = self.get_storages()
        if location.lower() == 'motor':
            location = 'culver'
        location = location.lower()

        lowerpath = path.lower()
        def check_if_match(name: str) -> bool: 
            name = name.lower().replace('pxl-', '')
            nonlocal lowerpath
            if f'/{name}/' in lowerpath:
                return True
            if f'/pxl-{name}/' in lowerpath:
                return True
            if f'/lon-{name}/' in lowerpath:
                return True
            return False

        stor = list(filter(lambda x: x['site']['name'].lower() == location and check_if_match(x['name']) , stor))
        if len(stor) == 0:
            raise Exception(f"Could not find any matching AM registered storages for path {path}")
        # log.info(stor)
        if len(stor) == 1:
            vxid = stor[0]['id']
            name = stor[0]['name'].lower().replace('pxl-', '')
            return vxid, re.split(f'{name}/', path, flags=re.IGNORECASE, maxsplit=1)[-1]
            # # storageRoot = self.get_storage_filesystem(vxid)['storageRootPath']
            # namelen = len(name) + 2
            # # if f'/{name}/' not in lowerpath:
            # idxpath = lowerpath.index(f'/{name}/')
            # if idxpath < 0:
            #     idxpath = lowerpath.index(f'/pxl-{name}/')
            #     namelen = namelen + 4
            
            # return vxid, f'{path[(idxpath + namelen):]}'
            # # return vxid, f'{storageRoot}{path[(idxpath + namelen):]}'

        raise Exception(f"Found too many matching storages for {path}")


    def get_existing_asset_paths_from_technical_details(self, technical_details, location= '', is_moas = False, storage_type = 'on_prem', retry_path_detection_attempts=0):
        loc_key = 'moasLocations' if is_moas else 'locations'

        location = location.lower() if location else ''
        celery_loc = location
        if celery_loc == 'motor':
            location = 'culver'
        
        assetLocations = technical_details.get('generalData', {}).get(loc_key, [])
        if assetLocations and location:
            assetLocations = list(filter(lambda l: l["storageLocation"].lower() == location, assetLocations))
        # get on_prem path only / TODO: add option to filter type/location
        if assetLocations and storage_type:
            assetLocations = list(filter(lambda l: l["storageType"].lower() == storage_type, assetLocations))
        
        assetLocations_confirmed = []
        if assetLocations:
            for assetLocation in assetLocations:
                try:
                    s_type = assetLocation["storageType"].lower()
                    loc = ('s3://' if s_type == 's3' else '/') + assetLocation['storageName'].strip('/') + '/' + assetLocation['path'].lstrip('/')
                    
                    if s_type == 's3':
                        path_options = {}
                    else:
                        path_options = {
                            'location': 'motor' if assetLocation['storageLocation'].lower() == 'culver' else assetLocation["storageLocation"].lower()
                        }
                        if celery_loc:
                            path_options['location'] = celery_loc

                    log.info("Checking " + loc + " with " + json.dumps(path_options))
                    QueueManager().get_exist_path_detection(loc, options=path_options, number_of_retries=retry_path_detection_attempts)
                    assetLocations_confirmed.append(assetLocation)
                except Exception as err: 
                    log.info(err)
                    pass
        return assetLocations_confirmed


    def get_asset_path_from_technical_details(self, technical_details, location= '', is_moas = False, storage_type = 'on_prem', return_storage_payload=False, retry_path_detection_attempts=0):
        loc_key = 'moasLocations' if is_moas else 'locations'

        location = location.lower() if location else ''
        celery_loc = location
        if celery_loc == 'motor':
            location = 'culver'
        
        assetLocations = technical_details.get('generalData', {}).get(loc_key, [])
        if assetLocations and location:
            assetLocations = list(filter(lambda l: l["storageLocation"].lower() == location, assetLocations))
        # get on_prem path only / TODO: add option to filter type/location
        if assetLocations and storage_type:
            assetLocations = list(filter(lambda l: l["storageType"].lower() == storage_type, assetLocations))
        
        if assetLocations:
            for assetLocation in assetLocations:
                try:
                    s_type = assetLocation["storageType"].lower()
                    loc = ('s3://' if s_type == 's3' else '/') + assetLocation['storageName'].strip('/') + '/' + assetLocation['path'].lstrip('/')
                    
                    if s_type == 's3':
                        path_options = {}
                    else:
                        path_options = {
                            'location': 'motor' if assetLocation['storageName'].lower() == 'culver' else assetLocation["storageLocation"].lower()
                        }
                        if celery_loc:
                            path_options['location'] = celery_loc

                    info = QueueManager().get_exist_path_detection(loc, options=path_options, number_of_retries=retry_path_detection_attempts)
                    loc = info['mnt_full']
                    if return_storage_payload:
                        return loc, assetLocation
                    return loc
                except: pass

        if location:
            raise Exception(f'There is no valid asset path for Asset [{technical_details["generalData"]["id"]}] in location [{location}], please make sure assets are properly checked out')    
        raise Exception(f'There is no valid asset path for Asset [{technical_details["generalData"]["id"]}], please make sure assets are properly checked out')                
    
    def get_asset_path(self, am_id='', om_id='', om_version_id='', location= '', is_moas = False, storage_type = 'on_prem', return_storage_payload=False, retry_path_detection_attempts=0):
        technical_details = self.get_technical_details(am_id, om_id, om_version_id)
        return self.get_asset_path_from_technical_details(technical_details, location, is_moas, storage_type, return_storage_payload, retry_path_detection_attempts) 

    def get_moas_paths(self, am_id='', om_id='', om_version_id='', location= '', storage_type = 'on_prem', return_storage_payload=False, retry_path_detection_attempts=0):
        return self.get_asset_path(am_id, om_id, om_version_id, location, True, storage_type, return_storage_payload, retry_path_detection_attempts)
        
    def get_sidecars(self, am_id='', om_id='', om_version_id=''):
        query_params = {
            "amAssetId": am_id,
            "omAssetId": om_id,
            "omAssetVersionId": om_version_id
        }
        log.debug(f"Getting Asset sidecars. {query_params}")
        return self.get_am_api('/item/sidecars', query_params)
    
    def add_sidecar(self, am_id='', om_id='', om_version_id='', sidecar_type='other', s3_uri='', extras= {}):
        payload = {
            # "amAssetId": "string",
            # "omAssetId": 0,
            # "omAssetVersionId": 0,
            "type": "string",
            # "s3Uri": "string",
            "systemOwner": "AM",
            "userEmail": "automation.service@pixelogicmedia.com",
            # "trackType": "string",
            # "trackIndex": 0
        }
        if am_id: payload['amAssetId'] = am_id
        if om_id: payload['omAssetId'] = int(om_id)
        if om_version_id: payload['omAssetVersionId'] = int(om_version_id)
        if sidecar_type: payload['type'] = sidecar_type
        if s3_uri: payload['s3Uri'] = s3_uri

        payload.update(extras)
        
        log.debug(f"Adding Asset sidecars. {payload}")

        if not payload['amAssetId'] and not payload['omAssetId']:
            raise Exception("Missing AM ID or OM ID")
        if not payload['s3Uri']:
            raise Exception("Missing s3 uri")

        s3_bucket = s3_uri.split('s3://')[-1].split('/')[0]
        s3_sidecar_bucket = 'pixelogic-am-storage-production'
        if s3_bucket != s3_sidecar_bucket:
            # copy to correct bucket
            s3_key = s3_uri.split(s3_bucket)[-1].lstrip('/')
            s3 = boto3.client('s3')
            copy_source = {
                'Bucket': s3_bucket,
                'Key': s3_key
            }
            s3.copy(copy_source, s3_sidecar_bucket, s3_key)
            payload['s3Uri'] = f"s3://{s3_sidecar_bucket}/{s3_key}"

        result = self.post_am_api('/item/sidecars', payload)
        
        log.debug(f"Added Asset [{payload}] sidecars succeeded. -> {result}")
        return {
            'status': 'success'
        }
    
    # ingest steps:
    # 1. ingest -> am_job_id
    # 2. poll ingest -> vidispine job id: vx-id
    # 3. poll vidispine job -> am_id (vidispine module)
    # 4. get title/alpha id (if nt provided) (om module)
    # 5. fulfill am
    def ingest(self, ingest_path, ingest_type, query_params = {}):
        # https://mam-api.pixelogicmedia.com/swagger-ui/index.html#/Ingestion/genericIngest
        if ingest_path.startswith('s3://'):
            relativepath = ingest_path.split('s3://')[-1].split('/', 1)[-1]
            vidispine = self.get_storage_by_name(ingest_path.split('s3://')[-1].split('/')[0]).get('id') or ''
            location = 's3'
            ingest_type = ingest_type or ('folder' if relativepath.endswith('/') else 'file')
        else:
            fp_info = QueueManager().get_exist_path_detection(ingest_path)
            relativepath = fp_info.get('relativepath') or ''
            vidispine = fp_info.get('vidispine') or ''
            location = fp_info.get('location') or ''
            ingest_type = ingest_type or fp_info['type']

        if ingest_type == 'folder':
            ingest_type = 'blob_folder'
        payload = {
            # "bulkTagsList": [
            #     "string"
            # ],
            "itemsList": [
                {
                # "systemOwner": "AM",
                # "tags": "string",
                "type": ingest_type, # kdm, kdm_folder, dcp_folder, imf_folder, imp_folder, xml_ttf_folder, file, mxf, file_sequence, xml_png_folder, bundle_folder, blob_folder, protools_folder
                "path": relativepath,
                # "ingestData": {
                #     "dataType": "string"
                # },
                # "systemGenerated": True
                }
            ]
        }
        try:
            if not vidispine or len(vidispine) == 0:
                vidispine, relativepath = self.get_storage_vxid_and_vidispine_path(ingest_path, location)
        except:
            pass
        final_query_params = {
            "referrer": "celery",
            "storageId": vidispine,
            # "autoDetect": True,
            # "autoFulfill": False,
            # "autoFulfillmentRule": ""
        }

        if query_params:
            final_query_params.update(query_params)

        result = self.post_am_api("/generic/ingest", payload, final_query_params)

        log.debug(f"Ingest Asset [{payload}] -> {result}.")
        
        return self.poll_ingest(result['jobId'])
        
    def ingest_s3(self, s3_path, ingest_type, check_status = False, query_params = {}):
        # https://mam-api.pixelogicmedia.com/swagger-ui/index.html#/Ingestion/s3Ingest
        bucket_name = s3_path.split('//')[-1].split('/')[0]
        payload = {
            # "bulkTagsList": [
            #     "string"
            # ],
            "itemsList": [
                {
                # "systemOwner": "AM",
                # "tags": "string",
                "type": ingest_type, # kdm, kdm_folder, dcp_folder, imf_folder, imp_folder, xml_ttf_folder, file, mxf, file_sequence, xml_png_folder, bundle_folder, blob_folder, protools_folder
                "path": s3_path.split(bucket_name, 1)[-1].lstrip('/'),
                # "ingestData": {
                #     "dataType": "string"
                # },
                # "systemGenerated": True
                }
            ]
        }

        final_query_params = {
            "referrer": "celery",
            "storageId": self.get_storage_by_name(bucket_name).get('id'),
            # "storageName": bucket_name
            # "placeholderIngest": False
        }
        if query_params:
            final_query_params.update(query_params)

        ingest_job = self.post_am_api("/generic/ingest/s3", payload, final_query_params)
        log.debug(f"Ingest S3 Job [{s3_path}] {ingest_job}.")

        if check_status and ingest_job.get('importJobs'):
            for job in ingest_job['importJobs']:
                job.update(self.poll_ingest(job['jobId']))
        return ingest_job

    def poll_ingest(self, am_job_id):
        start_time = time.time()
        timeout = start_time + (self.options.get('timeout') or 300)
        while True:
            result = self.get_am_api(f"/generic/ingest/prepareImportJob/{am_job_id}")
            status = result.get('status') or ''
            log.debug(f"Ingest Job [{am_job_id}] {status}.")
            if status in ['SUCCEEDED']:
                return result
            if status in ['FAILED']:
                raise Exception(f"Ingest Job [{am_job_id}] failed. {result}")
        
            if timeout < time.time():
                raise Exception(f"Ingest Job [{am_job_id}] timeout. {result}")
            
            time.sleep(self.options.get('polling_time') or 5)

    def fulfill(self, am_id, om_id, om_version_id, alpha_id, title_id):
        payload = [{
            "alphaId": alpha_id,
            "mamAssetId": am_id,
            "omAssetId": om_id,
            "omAssetVersionId": om_version_id,
            "titleId": title_id      
        }]
        log.debug(f"Fulfilling Asset [{payload}]")
        return self.put_am_api("/items/fulfill", payload)



