import requests, time, json, random, base64

__pending_timeout = 3600 * 12

def submit_and_check_multi(jobs: list, retry=True, session=None):
    return list(submit_and_check_multi_generator(jobs, retry, session))

def submit_and_check_multi_generator(jobs: list, retry=True, session=None):
    for j in jobs:
        j['result'] = submit(url=j['url'], data=j['data'], retry=retry, session=session)
        j['taskid'] = j['result'].get('task-id')
    for j in jobs:
        if j.get('taskid'):
            result_url = j['url'].split('/async-apply/')[0] + '/result/' + j['taskid']
            j['result'].update(check_result_info(url=result_url, session=session))
            yield j

def submit_and_check(url, data, retry=True, session=None, heartbeatTimeout=-1, return_all_states=False, sleep=15):
    result = submit(url=url, data=data, retry=retry, session=session)
    taskid = result.get('task-id')
    if taskid:
        result_url = url.split('/async-apply/')[0] + '/result/' + taskid
        result.update(check_result_info(url=result_url, session=session, heartbeatTimeout=heartbeatTimeout, return_all_states=return_all_states, sleep=sleep))
    state = result.get('state')
    if not return_all_states and state not in ['SUCCESS']:
        if state == 'REVOKED':
            raise Exception('User cancelled.')
        raise Exception(state, result.get('worker'), taskid, result.get('result'), result.get('exception'))
    return result

def submit(url, data, retry=True, session=None):
    retries = 5 if retry else 1
    err_code = 'unknown'
    while retries>0:
        if session:
            res = session.post(url, json=data, timeout=(5,10))
        else:
            res = requests.post(url, json=data, timeout=(5,10))
        if res.status_code == 200:
            return res.json()
        err_code = str(res.status_code)
        retries -= 1
    return {'state': 'FAILURE', 'exception': f'Failed to submit to celery: {url} / code: {err_code}'}

def check(info_url, timeouts=300, sleep=5, session=None, heartbeatTimeout = -1):
    start = time.time()
    updatestart = True
    original_start = start
    err_503 = 0
    timeout_count = 0    
    start_pending = 0
    while start + timeouts > time.time() and (heartbeatTimeout <= 0 or (original_start + heartbeatTimeout > time.time() or updatestart)):
        res = None
        err = None
        try:
            if session:
                res = session.get(info_url, timeout=(5,10))
            else:
                res = requests.get(info_url, timeout=(5,10))
        except requests.exceptions.Timeout as rerr:
            err = rerr
            res = None
        print(str(res))
        if res != None and res.ok:
            timeout_count = 0
            err_503 = 0

            result = res.json()
            print(str(result))
            if result['state'] in ['FAILURE', 'REVOKED', 'SUCCESS']:
                return result

            if updatestart and result['state'] == 'STARTED':
                if heartbeatTimeout > 0:
                    updatestart = False
                    original_start = time.time()

            if result['state'] != 'PENDING':
                start_pending = 0
            else:                
                if start_pending == 0:
                    start_pending = time.time()
                elif start_pending + __pending_timeout < time.time():
                    return revoke(info_url, timeouts, sleep, session)
                    # return {'state': 'FAILURE', 'exception': 'timeout (no status)'}
            start = time.time()
        elif res != None and res.status_code == 503:
            err_503 += 1
            if err_503 >5:
                return {'state': 'FAILURE', 'exception': '503'}
        elif res != None and res.status_code == 404:
            err_503 += 1
            if err_503 >5:
                return {'state': 'FAILURE', 'exception': '404'}
        elif res == None and err != None:
            timeout_count += 1
            if timeout_count > 10:
                return revoke(info_url, timeouts, sleep, session)
                # return {'state': 'FAILURE', 'exception': str(err)}
        time.sleep(random.uniform(sleep, sleep + 1))

    if heartbeatTimeout > 0:
        return revoke(info_url, timeouts, sleep, session)
    
    return {'state': 'FAILURE', 'exception': 'timeout (no status)'}

def check_result_info(url, timeouts=120, sleep=15, session=None, heartbeatTimeout = -1, return_all_states=False):
    r_url = url.replace('/info/', '/result/')
    i_url = url.replace('/result/', '/info/')
    print(r_url)
    print(i_url)
    result = check(info_url=i_url, timeouts=timeouts, sleep=sleep, session=session, heartbeatTimeout=heartbeatTimeout)
    if return_all_states or result['state'] == 'SUCCESS':
        try:
            if session:
                res = session.get(r_url, timeout=(5,10))
            else:
                res = requests.get(r_url, timeout=(5,10))
            result.update(res.json())
            if not return_all_states:
                result['state'] = 'SUCCESS'
        except: pass
    try: result['result'] = json.loads(result['result'])
    except: pass
    return result

def revoke(result_info_url, timeouts, sleep, session=None):
    try:
        revoke_url = result_info_url.replace('/info/', '/revoke/').replace('/result/', '/revoke/') + "?terminate=true"
        print(f"Attempting to revoke: {revoke_url}")
        start = time.time()
        while start + timeouts > time.time():
            try:
                if session:
                    res = session.post(revoke_url, timeout=(5,10))
                else:
                    res = requests.post(revoke_url, timeout=(5,10))
                print(str(res))
                if res.ok:
                    return {'state': 'FAILURE', 'exception': 'timeout no heartbeat'}
                time.sleep(sleep)
            except Exception as err:
                return {'state': 'FAILURE', 'exception': f'timeout {str(err)}'}
    except Exception as err0:
        # trying revoke without blocking logic
        print(str(err))
    return {'state': 'FAILURE', 'exception': f'timeout trying to revoke'}

def revoke_by_task_id(api_url, task_id, timeouts, sleep, session=None):
    revoke_url = api_url.split('/api/')[0] + f"/api/task/revoke/{task_id}?terminate=true"
    return revoke(revoke_url, timeouts, sleep, session)

def call_qbapi(qbapi_url, task_name, qb_tbl, utoken, atoken, args):
    qbapi_args = {
        'task': task_name,
        'qb_tbl': qb_tbl,
        'utoken': utoken,
        'atoken': atoken, 
        'args': args
    }
    args_encoded = base64.b64encode(json.dumps(qbapi_args).encode('ascii')).decode('ascii')
    result = submit_and_check(qbapi_url, {"args": [ args_encoded ]})
    if result.get('state') not in ['SUCCESS']:
        raise Exception('call qbapi failed.', result.get('result'), result.get('exception'))
    return result.get('result')