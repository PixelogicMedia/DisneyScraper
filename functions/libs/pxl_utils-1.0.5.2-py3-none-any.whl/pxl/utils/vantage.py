import copy, requests, time

from .logger import Logger
from .qm import QueueManager

log = Logger('vantage_support')

option = {
    #'vantage_url': 'http://10.100.110.26:8676/Rest',
    'vantage_url': 'http://10.100.110.24:8676/Rest',
    'vantage_urls': ['http://bur-p-mch-vtg01:8676/Rest', 'http://bur-p-mch-vtg02:8676/Rest'],

    
    'vantage_mapping': {
        'W:\\': ['/mnt/PXL-FS01/', '/Volumes/PXL-FS01/'],
        'X:\\': ['/mnt/PXL-FS02/', '/Volumes/PXL-FS02/'],
        'Y:\\': ['/mnt/PXL-FS03/', '/Volumes/PXL-FS03/'],
        'Z:\\': ['/mnt/PXL-FS04/', '/Volumes/PXL-FS04/'],
        'T:\\': ['/mnt/PXL-QFS01/', '/Volumes/PXL-QFS01/', '/Volumes/pxl-qfs01/'],
        'U:\\': ['/mnt/PXL-QFS02/', '/Volumes/PXL-QFS02/', '/Volumes/pxl-qfs02/'],
        'C:\\Volumes\\Localization\\': ['/mnt/localization/', '/mnt/Localization/', '/Volumes/localization/', '/Volumes/Localization/'],
        'C:\\Volumes\\PXL-PFS00\\': ['/mnt/PXL-PFS00/', '/mnt/pxl-pfs00/', '/mmfs1/pxl-pfs00/', '/Volumes/PXL-PFS00/', '/Volumes/pxl-pfs00/'],
        'C:\\Volumes\\PXL-PFS01\\': ['/mnt/PXL-PFS01/', '/mnt/pxl-pfs01/', '/mmfs1/pxl-pfs01/', '/Volumes/PXL-PFS01/', '/Volumes/pxl-pfs01/', '/mnt/BurPixit/', '/Volumes/BurPixit/'],
        'C:\\Volumes\\PXL-PFS02\\': ['/mnt/PXL-PFS02/', '/mnt/pxl-pfs02/', '/mmfs1/pxl-pfs02/', '/Volumes/PXL-PFS02/', '/Volumes/pxl-pfs02/', '/mnt/BurPixit/', '/Volumes/BurPixit2/'],
        'C:\\Volumes\\RADIUM\\': ['/mnt/RADIUM/', '/mnt/radium/', '/Volumes/RADIUM/', '/Volumes/radium/']
    },

    'vantage_mapping_unc': {
        'W:\\': '\\\\10.100.130.30\\PXL-FS01\\',
        'X:\\': '\\\\10.100.130.30\\PXL-FS02\\',
        'Y:\\': '\\\\10.100.130.30\\PXL-FS03\\',
        'Z:\\': '\\\\10.100.130.30\\PXL-FS04\\',
        'T:\\': '\\\\10.100.200.202\\pxl-qfs01\\',
        'U:\\': '\\\\10.100.200.202\\pxl-qfs02\\',
        'C:\\Volumes\\Localization\\': '\\\\bur-pixit\\localization\\',
        'C:\\Volumes\\PXL-PFS00\\': '\\\\bur-pixit\\PXL-PFS00\\',
        'C:\\Volumes\\PXL-PFS01\\': '\\\\bur-pixit\\PXL-PFS01\\',
        'C:\\Volumes\\PXL-PFS02\\': '\\\\bur-pixit\\PXL-PFS02\\',
        'C:\\Volumes\\RADIUM\\': '\\\\prod\\PMLAISIX1\\RADIUM\\'
    },


    'timeout': 14400,
    'check_sleep': 30
}


# vantage api support
def remapPathVantage(path, mapping = None, unc=False):
    new_path = QueueManager().get_exist_path_detection(path)['mnt_full']
    log.info(new_path)
    vantage_mapping = copy.deepcopy(option['vantage_mapping'])
    if unc:
        vantage_mapping_unc = {}
        for k in vantage_mapping:
            vantage_mapping_unc[option['vantage_mapping_unc'][k]] = vantage_mapping[k]
        vantage_mapping = vantage_mapping_unc
    if mapping: vantage_mapping.update(mapping)
    for k in vantage_mapping:
        for v in vantage_mapping[k]:
            if new_path.startswith(v):
                new_path = new_path.replace(v, k, 1).replace('/','\\')
                return new_path
    return path

def submitAndCheck(workflow_id, kvp, job_inputs=None, vantage_url=None, unc=False):
    id = submit(workflow_id, kvp, job_inputs, vantage_url, unc)
    return check(id, vantage_url)

def submit(workflow_id, kvp, job_inputs=None, vantage_url=None, unc=False):
    if not job_inputs:
        job_inputs = getJobInputs(workflow_id, vantage_url)
    sjob = fillJobInputs(job_inputs, kvp, unc)    
    return __submit(workflow_id, sjob, vantage_url)

# def getAndSubmit(workflow_id, kvp, vantage_url=None):
#     ijob = getJobInputs(workflow_id, vantage_url)
#     sjob = fillJobInputs(ijob, kvp)
#     return submit(workflow_id, sjob, vantage_url)

def getJobInputs(workflow_id, vantage_url=None):
    url = (vantage_url or option['vantage_url']) + '/Workflows/' + workflow_id + '/JobInputs'
    return requests.get(url).json()

def fillJobInputs(job_inputs, kvp, unc=False):
    job_inputs['JobName'] = kvp.get('JobName') or kvp.get('jobname')
    default_media = [m for m in job_inputs['Medias'] if m['Name'] == 'Original']
    if not default_media:
        default_media = job_inputs['Medias']
    default_media[0]['Files'] = [remapPathVantage(f, None, unc) for f in kvp['Files']]

    other_medias = {k[len('Medias_'):]:kvp[k] for k in kvp if k.startswith('Medias_')}
    for var in job_inputs['Medias']:
        varname = var['Name']
        if other_medias.get(varname) == None: continue
        value = other_medias[varname]
        var['Files'] = [remapPathVantage(f, None, unc) for f in value]
        
    for var in job_inputs['Variables']:
        varname = var['Name']
        if kvp.get(varname) == None: continue
        value = kvp[varname]
        if type(value) is str and (value.startswith('/mnt') or value.startswith('/Volumes')):
            value = remapPathVantage(value, None, unc)
        var['Value'] = value
    log.info(job_inputs)
    return job_inputs

def __submit(workflow_id, filled_job, vantage_url=None):
    log.info(filled_job)
    retry = 5
    err = ''
    url = (vantage_url or option['vantage_url']) + '/Workflows/' + workflow_id + '/Submit'
    while retry>0:
        res = requests.post(url, json=filled_job)
        if res.status_code == 200:
            id = res.json()['JobIdentifier']
            if id != '00000000-0000-0000-0000-000000000000':
                return id
            else:
                err += 'submitting fail: ' + id
        else:
            err += f'code: {res.status_code} - err: {res.content}\r\n'
        retry -= 1
        time.sleep(5)
    raise Exception('cannot submit to vantage: ' + err)

def check(job_id, vantage_url = None):
    start = time.time()
    timeout = option['timeout']
    check_url = (vantage_url or option['vantage_url']) + '/Jobs/' + job_id
    status = 'Submitted'
    outputs = None
    while start + timeout > time.time():
        time.sleep(option['check_sleep'])
        try:
            res = requests.get(check_url)
            if res.status_code == 200:
                status = parseVantageStatus(res.json()['Job']['State'])
            else:
                raise Exception(f'jobid: {id} - code: {res.status_code} - err: {res.content}')
        except Exception as err:
            log.error(str(err))
            pass
        if status == 'Complete':
            try:
                outputs = requests.get(check_url+'/outputs').json()
            except: pass
            break
        elif status == 'Failed':
            res1 = requests.get(check_url + '/ErrorMessage')
            raise Exception(res1.json()['JobErrorMessage'])
        elif status == 'Stopped by User':
            raise Exception('Stopped by User', res.content)
        elif status == 'Waiting':
            start = time.time()
        log.info(f"vid:{job_id} - status:{status}")
        yield {'job_id':job_id, 'status': status}
    log.info(outputs)
    if status not in ['Complete', 'Failed']:
        raise Exception('Timeout or Unkown: ' + status)
    yield {'job_id':job_id, 'status': status, 'outputs': outputs}

def parseVantageStatus(state):
    statuses = {
        0: "In Progress",
        4: "Failed",
        5: "Complete",
        6: "Waiting",
        7: "Stopped by User",
        8: "Waiting to Retry"
    }
    if state in statuses:
        return statuses[state]
    return 'Unknown'
