import argparse, json, base64, subprocess, os, socket, sys, importlib.util

app_name = 'run_command'
version = '1.0.0'
DEBUG = False

# python3 -m pxl.run_command --cmd 'ls -l' --env 'PATH=/usr/local/bin:/usr/bin:/bin' --cwd '/tmp' --output '/tmp/output.txt'
# try to import pxl/apps from all locations
try:
    __extra_syspaths__ = [
        os.path.dirname(os.path.realpath(__file__)),
        '/mnt/mediatool-cli-tools/services/pxl-service-libs/pxl-utils', # default pxl-utils all sites
        '/mnt/mediatool-cli-tools/services/pxl_services_specialized', # default pxl_services_specialized all sites
        '/mnt/mediatool-cli-tools/services/pxl_services_general', # default pxl_services_general all sites
        
        '/mnt/aws-pixelprint-code/aws-specialized-services/pxl-service-libs/pxl-utils', # aws pxl-utils
        '/mnt/aws-pixelprint-code/aws-specialized-services/pxl_services_specialized', # aws pxl_services_specialized
    ]
    sys.path.extend(__extra_syspaths__)
    print(f"added system paths [{__extra_syspaths__}] ...")
    if not importlib.util.find_spec('pxl') and importlib.util.find_spec('apps'):
        import apps
        sys.modules['pxl'] = apps
        del sys.modules['apps']
        print('Imported apps as pxl')
except Exception as err:
    print("Import pxl/apps error", err)

try:
    from pxl.utils.logger import Logger
    log = Logger(app_name)
except:
    print('Use system logging ...')
    import logging
    logging.basicConfig(
        level=logging.INFO,  # Set the log level to INFO
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',  # Define the log format
        handlers=[logging.StreamHandler(sys.stdout)]  # Output to console
    )
    log = logging.getLogger(app_name)


def __getHostNameIP(): 
    try: 
        host_name = socket.gethostname() 
        host_ip = socket.gethostbyname(host_name) 
        log.debug(f'{host_name} - {host_ip}')
        return host_name, host_ip
    except Exception as err: 
        log.exception(err)
    return None, None

def __parseOutput(output):
    result = str(output)
    try: result = output.decode('utf-8', errors='replace')
    except:
        try: result = output.decode('ascii', errors='replace')
        except: pass
    return result

def __run_command(cmd, kwargs={}):
    try:
        cwd = kwargs.pop('cwd') if 'cwd' in kwargs else None
        env = kwargs.pop('env') if 'env' in kwargs else None
        cur_env = dict(os.environ)
        if env:
            cur_env.update(env)
        if len(cmd) == 1:
            output = subprocess.check_output(cmd[0], shell=True, stderr=subprocess.STDOUT, env=cur_env, cwd=cwd)
        else:
            output = subprocess.check_output(cmd, stderr=subprocess.STDOUT, env=cur_env)
        return __parseOutput(output)
    except subprocess.CalledProcessError as perr:
        log.exception(perr)
        raise Exception(f'code:{perr.returncode} / err:{perr.output}')

def parse_json_args(args):
    try:
        if type(args) is str:
            return json.loads(args)
        return args
    except Exception as err:
        log.exception(err)
        log.warn(f'Cannot parse json args {args}')
    return {}

def __base64decode(base64_message, encoding='ascii'):
    binary_content = base64_message if isinstance(base64_message, bytes) else str(base64_message).encode(encoding)
    return base64.b64decode(binary_content).decode(encoding, errors='replace')

def parse_b64_args(args):
    try:
        return parse_json_args(__base64decode(args))
    except Exception as err:
        log.exception(err)
        log.warn(f'Cannot parse b64 json args {args}')
    return {}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=f'MediaTools - {app_name} v{version}')
    parser.add_argument('--debug', '-d', action='store_true', default=False, help='Debug flag')
    parser.add_argument('--base64', type=parse_b64_args, default={}, help='base64 encoded payload')
    parser.add_argument('--payload', type=parse_json_args, default={}, help='json string payload')

    parser.add_argument('--cmd', '-c', nargs='+', type=str, help='command to run')
    parser.add_argument('--cmds', type=parse_json_args, help='multiple commands to run. String format of list of commands, Ex: [["ls", "/tmp"], ["mkdir", "-p", "/tmp/abc"]]')
    parser.add_argument('--env', '-e', nargs='+', type=str, help='environment variables: key1=value1 key2=value2')
    parser.add_argument('--cwd', type=str, help='current directory')

    args = parser.parse_args()
    opts = vars(args)
    opts.update(opts.get('base64') or {})
    opts.update(opts.get('payload') or {})
    DEBUG = opts.get('debug') or False
    if DEBUG:
        log.setLevel(logging.DEBUG)
        log.debug(f"Debug mode: {DEBUG}")
        log.debug(f"opts: {opts}")

    start_output_sign = "<RUN_COMMAND_OUTPUT>"
    end_output_sign = "</RUN_COMMAND_OUTPUT>"

    if not opts.get('cmd') and not opts.get('cmds'):
        raise Exception("No command provided")
    
    env = opts.get('env') or None
    if env:
        if isinstance(env, list):
            env = dict([x.split('=') for x in env])
        elif isinstance(env, str):
            env = dict([x.split('=') for x in env.split()])
        elif not isinstance(env, dict):
            raise Exception("Invalid env")
    opts['env'] = env
    opts['cwd'] = opts.get('cwd') or None
    console_path = opts.get('output') or ''

    cmds = opts.get('cmds') or []
    if opts.get('cmd'):
        cmds.append(opts['cmd'])

    outputs = [ __run_command(cmd, {'cwd': opts['cwd'], 'env': opts['env']}) for cmd in cmds ]
    output = "\r\n".join(outputs)
    if console_path:
        try:
            os.makedirs(os.path.dirname(console_path), exist_ok=True)
            with open(console_path, 'w') as f:
                f.write(output)
        except Exception as err:
            log.exception(err)
            log.warn(f"Cannot write to {console_path}")

    log.info(f"{str(__getHostNameIP())} / cmd(s) {cmds} / {start_output_sign}{output}{end_output_sign}")
    
    