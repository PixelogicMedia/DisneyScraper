import sys, importlib.util, os, json, argparse

app_name = 'run_module'
DEBUG = False

# python3 -m pxl.run_module --class_name apps.utils.qbapi.qbapi --class_kwargs '{"config": "config1"}' --function uploadXML --function_kwargs '{"xml": "xml1"}'
# try to import pxl/apps from all locations
try:
    __extra_syspaths__ = [
        os.path.dirname(os.path.realpath(__file__)),
        '/mnt/mediatool-cli-tools/services/pxl-service-libs/pxl-utils', # default pxl-utils all sites
        '/mnt/mediatool-cli-tools/services/pxl_services_specialized', # default pxl_services_specialized all sites
        '/mnt/mediatool-cli-tools/services/pxl_services_general', # default pxl_services_general all sites
        
        '/mnt/aws-pixelprint-code/aws-specialized-services/pxl-service-libs/pxl-utils', # aws pxl-utils
        '/mnt/aws-pixelprint-code/aws-specialized-services/pxl_services_specialized', # aws pxl_services_specialized
    ]
    sys.path.extend(__extra_syspaths__)
    print(f"added system paths [{__extra_syspaths__}] ...")
    if not importlib.util.find_spec('pxl') and importlib.util.find_spec('apps'):
        import apps
        sys.modules['pxl'] = apps
        del sys.modules['apps']
        print('Imported apps as pxl')
except Exception as err:
    print("Import pxl/apps error", err)

from pxl.utils.logger import Logger
from pxl.utils.misc import base64decode
from pxl.utils.qbapi import qbapi
from pxl.utils.s3_wrapper import S3Wrapper
from pxl.utils.ci import CI
from pxl.utils.faspex import Faspex
from pxl.utils.faspex_cmd import FaspexCmd, FaspexCmdDownload
from pxl.utils.sharepoint import SharepointTransfer

try: log = Logger(app_name)
except:
    print('Use system logging ...')
    import logging
    logging.basicConfig(
        level=logging.INFO,  # Set the log level to INFO
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',  # Define the log format
        handlers=[logging.StreamHandler(sys.stdout)]  # Output to console
    )
    log = logging.getLogger(app_name)

def create_instance(class_name, *args, **kwargs):
    if class_name in globals():
        return globals()[class_name](*args, **kwargs)
    elif class_name in locals():
         return locals()[class_name](*args, **kwargs)
    else:
        raise NameError(f"Class '{class_name}' not found")
    
def run(opts):
    log.info(f"Start ... {opts}")
    try:
        log.info("Running ...")

        class_name = opts.get('class_name') or ''
        class_kwargs = opts.get('class_kwargs') or {}
        func = opts.get('function') or opts.get('func') or ''
        func_kwargs = opts.get('function_kwargs') or opts.get('func_kwargs') or {}
        if not class_name or not func:
            raise Exception("No class / function provided")

        instance = create_instance(class_name, **class_kwargs)
        if not hasattr(instance, func):
            raise AttributeError(f"Function '{func}' not found in '{class_name}'")
        
        func = getattr(instance, func)
        result = func(**func_kwargs)
        log.info(f"Function result: {result}")
        return result

    except Exception as err:
        log.error(err)
        raise


def parse_json_args(args):
    try:
        if type(args) is str:
            return json.loads(args)
        return args
    except Exception as err:
        print(f'Cannot parse json args {args}', err)
    return {}

def parse_b64_args(args):
    try:
        return parse_json_args(base64decode(args))
    except Exception as err:
        print(f'Cannot parse b64 json args {args}', err)
    return {}

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Run pxl module')
    parser.add_argument('--debug', '-d', action='store_true', default=False, help='Debug flag')
    parser.add_argument('--base64', type=parse_b64_args, default={}, help='base64 encoded payload')
    parser.add_argument('--payload', type=parse_json_args, default={}, help='json string payload')

    parser.add_argument('--class_name', '-c', default='', help='pxl class name, ex: apps.utils.qbapi.qbapi')
    parser.add_argument('--class_kwargs', '-k', type=parse_json_args, default={}, help='kwargs')

    parser.add_argument('--function', '-f', default='', help='class function, ex: uploadXML')
    parser.add_argument('--function_kwargs', type=parse_json_args, default={}, help='kwargs')
    
    args = parser.parse_args()
    opts = vars(args)
    opts.update(opts.get('base64') or {})
    opts.update(opts.get('payload') or {})
    log.info(f"opts: {opts}")
    DEBUG = opts.get('debug') or False
    log.info(f"Debug mode: {DEBUG}")

    res = run(opts)
    
    log.info(f"<OUTPUT>{json.dumps(res)}</OUTPUT>")